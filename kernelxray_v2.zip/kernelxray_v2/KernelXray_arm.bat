@echo off
chcp 65001 >nul
rem Захват в играх с EA AntiCheat (Battlefield 6). Запускать при ПОЛНОСТЬЮ закрытой игре.
rem KernelXray.exe сам попросит права администратора.
cd /d "%~dp0"
tasklist /FI "IMAGENAME eq bf6.exe" 2>nul | find /I "bf6.exe" >nul && (
  echo Battlefield 6 запущен. Закрой игру полностью и запусти этот файл снова.
  pause
  exit /b 1
)
set "DUR=30"
set /p "DUR=Длительность захвата в секундах [Enter = 30]: "
KernelXray.exe --arm -d %DUR% %*
