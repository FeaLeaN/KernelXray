# KernelXray 2.5

Диагностика системных задержек Windows. За окно захвата снимает трассу ядра (DPC и прерывания по драйверам),
тайминги кадров и системные счётчики, плюс проверяет 21 область конфигурации: от частоты памяти и монитора
до энергосбережения USB и распределения прерываний по ядрам. На выходе HTML-отчёт с находками, оценкой
0–1000 и профиль `xray_profile.kcore` со списком id исправлений.

## Что нужно

- Windows 10/11 x64, права администратора
- Python 3.10+ и `pip install -r requirements.txt` (только pywin32)
- **xperf**: Windows Performance Toolkit из Windows ADK (в установщике ADK достаточно отметить WPT)
- **PresentMon 2.x** (MIT, github.com/GameTechDev/PresentMon): положить `PresentMon-2.x-x64.exe` в `tools/`

Утилиты ищутся в таком порядке: `tools/` рядом с программой, затем PATH, затем стандартная папка WPT.
Без xperf или PresentMon соответствующие пробы помечаются как невыполненные, остальное работает.

## Запуск

Программа всегда работает в режиме `--arm`: запускай её **до игры**, окно захвата фиксированное, 30 с.

```
KernelXray_X.Y.Z.exe                            # обычный запуск: сессии ETW, потом игра, в бою F9
python -m kernelxray                            # то же из исходников
python -m kernelxray -p r5apex                  # подсказка, какой процесс считать игрой (необязательно)
python -m kernelxray --deep                     # + переключения контекста (трасса заметно тяжелее)
python -m kernelxray --only ETW_TRACER,ETW_SONAR --keep-raw
python -m kernelxray --no-snapshots             # только захват, без проверки конфигурации
python -m kernelxray --anonymize                # без имени пользователя и ПК в отчёте, telemetry.json и логе
python -m kernelxray --list
```

Старые ключи `--arm`, `-d`, `--delay`, `--frames-etl` принимаются, но ничего не меняют.

Порядок работы:

1. Быстрые проверки конфигурации (WMI, реестр, API электропитания). Они идут до захвата и не попадают в трассу.
2. Создаются сессии ETW: NT Kernel Logger (кольцевой файл) и пустая сессия кадров. Снимается список модулей ядра.
3. Сообщение «Сессии ETW созданы» — запускай игру и заходи в бой. Там нажми F9 (или Enter в окне KernelXray).
4. Сигнал, окно захвата 30 с. Делай то, на что жалуешься: играй, двигай мышью.
5. Анализ, итоги в консоли, отчёт. Второй сигнал — отчёт готов.

Игру заранее указывать не нужно: кадры пишутся для всех процессов, а игра выбирается по самим кадрам
(браузеры, мессенджеры, лаунчеры и оверлеи отбрасываются). Рабочий стол (`dwm.exe`) показывается отдельно.

Запускать можно только один KernelXray за раз. Если NT Kernel Logger занят другой программой
(LatencyMon, Process Monitor, WPR), KernelXray предупредит, что оборвёт её запись.

### Почему до игры

После запуска EA AntiCheat Windows отказывает в создании новых ETW-сессий (access denied, 0x5)
(github.com/GameTechDev/PresentMon/issues/573), а включать провайдеры в уже созданной сессии можно.
Поэтому сессии создаются заранее. Если Battlefield 6 или EA AntiCheat уже запущены, KernelXray попросит
закрыть игру.

Трасса ядра пишется в кольцевой файл (последние ~96 МБ) и потом обрезается по окну захвата. Если до F9
прошло несколько минут, кольцо перезаписывает начало трассы, где лежит список загруженных драйверов, а
остановить логгер под античитом не дают (списка в конце тоже нет). Поэтому KernelXray сам снимает список
модулей ядра с адресами (до игры и после окна) и восстанавливает по нему имена драйверов у DPC/ISR
(`core/kmodules.py`). Без остановки логгера у тихих ядер теряются последние секунды окна: это отмечено
в отчёте, в блоке Capture integrity.

### Кадры

Кадры всегда пишутся в файл .etl (своя сессия, созданная до игры) и после захвата разбираются PresentMon
(`--etl_file`). Так обходится и античит, и сбой PresentMon в реальном времени, когда он теряет все события
(github.com/GameTechDev/PresentMon/issues/423). Провайдеры кадров включаются с урезанными keywords
(файл примерно втрое меньше); `--frames-full` включает их целиком — для сверки, если кадров вдруг стало
меньше. Список провайдеров можно заменить файлом `tools/presentmon_etl_providers.txt`
(эталон — `Tools\start_etl_collection.cmd` в репозитории PresentMon).
Проверить PresentMon отдельно от KernelXray: `test_frames.bat` (сборка кладёт его рядом с exe),
запускать от администратора.

## Результаты

| Файл | Что это |
|---|---|
| `kernel_xray_report.html` | отчёт в стиле 1.x (радар подсистем, Thread Warzone, окна столкновений и т.д.), открывается офлайн |
| `telemetry.json` | все пробы (`probe / success / error / duration_ms / raw_metrics_json`), находки и оверхед |
| `xray_profile.kcore` | base64(JSON): `spi_score`, `target_fixes`, `hardware` — формат старой версии |
| `etw_dpcisr.txt` | сырой вывод `xperf -a dpcisr` |
| `present_mon_raw_data.csv`, `perfmon_raw_data.csv` | сырые данные кадров и счётчиков |
| `present_mon_console.log` | сообщения PresentMon (ошибки, потерянные события) |
| `kernel_xray.log` | лог |
| `xray_kernel.etl`, `etw_events.txt` | только с `--keep-raw`; .etl открывается в WPA |

## Пробы

Снапшоты: CPU_TOPOLOGY, HARDWARE_INFO, HARDWARE_MISCONFIG, BIOS_FIRMWARE, SYSTEM_CORE, TIMER_RESOLUTION,
MEMORY_MANAGEMENT, PROCESSES, OS_CONFIG, OS_ENTROPY, SERVICES_BLOAT, DRIVER_MANIFEST, GPU_ANALYSIS,
GPU_SCHEDULER, AUDIO_DPC, INPUT_ELITE, USB_POWER, CORE_COLLISION, NETWORK_ELITE,
STORAGE_ELITE, STORAGE_GUIDE.

Захват: PERFMON_ELITE (PDH), PRESENT_MON, ETW_TRACER (xperf + dpcisr), ETW_SONAR (поэвентный разбор той же
трассы: точные максимумы, самые длинные события, худшие миллисекунды по ядрам).

## Оценка и исправления

Правила лежат в `kernelxray/analysis/rules.py`. Каждая находка ссылается на измеренное значение.
Штраф по умолчанию: critical 150, warning 60, info 15; оценка = 1000 минус сумма. У отдельных находок
штраф свой: включённый игровой режим — предупреждение, −30. Пункты, которые на задержки не влияют
(HVCI, Win32PrioritySeparation, ускорение мыши), показываются в отчёте без штрафа.

Самый длинный DPC (без ntoskrnl.exe и драйверов, у которых за захват не больше 100 DPC): до 250 мкс — норма,
больше 250 и меньше 500 мкс — предупреждение (−60), от 500 мкс — критично (−150).

В кадрах отдельно считается сторонний вывод в процессе игры (present без цепочки буферов игры: всплывающее
окно или уведомление оверлея). Кадры игры, которые он растянул, отмечены на графике.

Если по какому-то пункту данные прочитать не удалось, это отдельная находка «Часть проверок не выполнена»:
отсутствие находки не выдаётся за «всё в порядке».

KernelXray ничего в системе не меняет. У части находок есть id известного исправления: в отчёте это
помечено «есть известное исправление», а сами id попадают в `target_fixes` профиля `xray_profile.kcore`.
Настройки безопасности (VBS/HVCI, Spectre, Defender) только описываются, id исправления у них нет.

## Сборка exe

```
build_pyinstaller_onedir.bat   # PyInstaller: dist\KernelXray_X.Y.Z\KernelXray_X.Y.Z.exe + dist\KernelXray_X.Y.Z.zip
build_nuitka_msvc.bat          # Nuitka + MSVC: из exe не восстанавливаются исходники, нужны VS Build Tools
```

Каждая сборка поднимает последнюю цифру версии в `kernelxray/__init__.py` (2.5.5 → 2.5.6), и эта версия
попадает в имя папки, exe и архива, в свойства exe и в лог. Если сборка не удалась, версия возвращается.
Вручную: `python build_version.py current | bump | set 2.6.0`. Прошлые сборки в `dist\` не удаляются.
Папка `tools/` (PresentMon, при желании xperf) копируется рядом с exe автоматически.

## Разработка

- Быстрая проба: наследник `SnapshotProbe`, метод `collect(ctx) -> dict`, таймаут `timeout_s`.
- Проба с окном захвата: наследник `CaptureProbe`, методы `prepare / start / stop / analyze`.
- Регистрация: `kernelxray/probes/__init__.py`. Windows-хелперы (реестр, WMI, powercfg, PCI): `core/win.py`.

Тесты работают без Windows (парсеры, правила, отчёт на эталонных файлах):

```
pip install -r requirements-dev.txt
python -m pytest tests
```
