@echo off
chcp 65001 >nul
setlocal
rem Сборка KernelXray через Nuitka компилятором MSVC в виде папки (standalone).
rem MSVC по умолчанию генерирует код под любой x64-процессор, без AVX2/AVX-512.
rem Нужны Visual Studio Build Tools с компонентом
rem "Разработка классических приложений на C++":
rem https://visualstudio.microsoft.com/visual-cpp-build-tools/
rem Каждая сборка поднимает версию (2.5.5 -> 2.5.6), как и сборка PyInstaller:
rem   dist\KernelXray_2.5.6\KernelXray_2.5.6.exe  и  dist\KernelXray_2.5.6.zip

cd /d "%~dp0"
python -m pip install -r requirements.txt nuitka || goto :fail_nover

set "KX_OLD="
for /f "delims=" %%v in ('python build_version.py current') do set "KX_OLD=%%v"
if not defined KX_OLD goto :fail_nover
set "KX_VER="
for /f "delims=" %%v in ('python build_version.py bump') do set "KX_VER=%%v"
if not defined KX_VER goto :fail_nover
set "KX_NAME=KernelXray_%KX_VER%"
echo Версия: %KX_OLD% -^> %KX_VER%

if exist dist\run.dist rmdir /S /Q dist\run.dist
if exist dist\run.build rmdir /S /Q dist\run.build
if exist "dist\%KX_NAME%" rmdir /S /Q "dist\%KX_NAME%"
if exist "dist\%KX_NAME%.zip" del /Q "dist\%KX_NAME%.zip"

python -m nuitka --standalone --msvc=latest --windows-uac-admin --assume-yes-for-downloads ^
  --windows-console-mode=force ^
  --include-package=kernelxray --include-package-data=kernelxray ^
  --output-filename=%KX_NAME%.exe --output-dir=dist ^
  --windows-company-name=FeaLeaN --windows-product-name=KernelXray --windows-product-version=%KX_VER% --windows-file-version=%KX_VER% ^
  run.py || goto :fail

rem Переименовываем run.dist в папку с версией в имени
move dist\run.dist "dist\%KX_NAME%" >nul || goto :fail
if exist dist\run.build rmdir /S /Q dist\run.build

if exist tools xcopy /E /I /Y tools "dist\%KX_NAME%\tools" >nul
if exist test_frames.bat copy /Y test_frames.bat "dist\%KX_NAME%\" >nul

powershell -NoProfile -Command "Compress-Archive -Path 'dist\%KX_NAME%' -DestinationPath 'dist\%KX_NAME%.zip' -Force" || goto :fail

echo.
echo Готово, версия %KX_VER%:
echo   папка  dist\%KX_NAME%\  (запускать dist\%KX_NAME%\%KX_NAME%.exe)
echo   архив  dist\%KX_NAME%.zip  (его и отправлять другим)
exit /b 0

:fail
python build_version.py set %KX_OLD% >nul
echo.
echo Сборка не удалась, смотри сообщения выше. Версия возвращена к %KX_OLD%.
echo Если Nuitka пишет, что не нашёл MSVC: установи Visual Studio Build Tools (ссылка в начале файла).
exit /b 1

:fail_nover
echo.
echo Сборка не удалась, смотри сообщения выше.
exit /b 1
