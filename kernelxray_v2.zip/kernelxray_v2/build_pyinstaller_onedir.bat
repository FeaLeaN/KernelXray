@echo off
chcp 65001 >nul
setlocal
rem Сборка KernelXray через PyInstaller в виде папки (без onefile).
rem Использует официальные сборки Python, поэтому работает на любом x64-процессоре.
rem Каждая сборка поднимает версию (2.5.5 -> 2.5.6) в kernelxray\__init__.py, и версия попадает в имена:
rem   dist\KernelXray_2.5.6\KernelXray_2.5.6.exe  и  dist\KernelXray_2.5.6.zip
rem Если сборка не удалась, версия возвращается обратно.

cd /d "%~dp0"
python -m pip install -r requirements.txt pyinstaller || goto :fail_nover

set "KX_OLD="
for /f "delims=" %%v in ('python build_version.py current') do set "KX_OLD=%%v"
if not defined KX_OLD goto :fail_nover
set "KX_VER="
for /f "delims=" %%v in ('python build_version.py bump') do set "KX_VER=%%v"
if not defined KX_VER goto :fail_nover
set "KX_NAME=KernelXray_%KX_VER%"
set "KX_RES=%TEMP%\kernelxray_version_info.txt"
echo Версия: %KX_OLD% -^> %KX_VER%

if exist build rmdir /S /Q build
if exist "dist\%KX_NAME%" rmdir /S /Q "dist\%KX_NAME%"
if exist "dist\%KX_NAME%.zip" del /Q "dist\%KX_NAME%.zip"
python build_version.py resource "%KX_RES%" || goto :fail

rem Файл .spec кладётся в build\, чтобы в корне проекта не копились KernelXray_X.Y.Z.spec
python -m PyInstaller --noconfirm --clean --onedir --uac-admin --console ^
  --name %KX_NAME% --distpath dist --specpath build --version-file "%KX_RES%" ^
  --hidden-import win32timezone ^
  --collect-submodules kernelxray ^
  --collect-data kernelxray ^
  "%CD%\run.py" || goto :fail

if exist tools xcopy /E /I /Y tools "dist\%KX_NAME%\tools" >nul
if exist test_frames.bat copy /Y test_frames.bat "dist\%KX_NAME%\" >nul

rem В архиве лежит сама папка с версией в имени: распаковка не смешает её с прошлыми версиями
powershell -NoProfile -Command "Compress-Archive -Path 'dist\%KX_NAME%' -DestinationPath 'dist\%KX_NAME%.zip' -Force" || goto :fail
if exist "%KX_RES%" del /Q "%KX_RES%"

echo.
echo Готово, версия %KX_VER%:
echo   папка  dist\%KX_NAME%\  (запускать dist\%KX_NAME%\%KX_NAME%.exe)
echo   архив  dist\%KX_NAME%.zip  (его и отправлять другим)
exit /b 0

:fail
python build_version.py set %KX_OLD% >nul
echo.
echo Сборка не удалась, смотри сообщения выше. Версия возвращена к %KX_OLD%.
exit /b 1

:fail_nover
echo.
echo Сборка не удалась, смотри сообщения выше.
exit /b 1
