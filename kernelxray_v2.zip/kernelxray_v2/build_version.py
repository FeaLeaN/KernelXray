"""Версия сборки: поднимает последнюю цифру в kernelxray/__init__.py и готовит ресурс версии для exe.

Вызывается из build_pyinstaller_onedir.bat / build_nuitka_msvc.bat перед каждой сборкой:
    python build_version.py bump          -> 2.5.5 -> 2.5.6, печатает новую версию
    python build_version.py set 2.5.5     -> вернуть версию (сборка не удалась)
    python build_version.py current       -> напечатать текущую
    python build_version.py resource PATH -> файл версии для PyInstaller (--version-file): свойства exe
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

INIT = Path(__file__).resolve().parent / "kernelxray" / "__init__.py"
_RE = re.compile(r'__version__\s*=\s*"(\d+(?:\.\d+)*)"')


def current() -> str:
    m = _RE.search(INIT.read_text(encoding="utf-8"))
    if not m:
        raise SystemExit(f"В {INIT} нет строки __version__ = \"X.Y.Z\"")
    return m.group(1)


def set_version(v: str) -> str:
    if not re.fullmatch(r"\d+(?:\.\d+)*", v):
        raise SystemExit(f"Неверная версия: {v}")
    text = INIT.read_text(encoding="utf-8")
    INIT.write_text(_RE.sub(f'__version__ = "{v}"', text, count=1), encoding="utf-8")
    return v


def bump(v: str) -> str:
    parts = [int(x) for x in v.split(".")]
    while len(parts) < 3:
        parts.append(0)
    parts[-1] += 1
    return ".".join(map(str, parts))


def resource(v: str, path: Path) -> None:
    nums = ([int(x) for x in v.split(".")] + [0, 0, 0, 0])[:4]
    t = tuple(nums)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"""VSVersionInfo(
  ffi=FixedFileInfo(filevers={t}, prodvers={t}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1,
                    subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('041904B0', [
      StringStruct('CompanyName', 'FeaLeaN'),
      StringStruct('FileDescription', 'KernelXray {v}'),
      StringStruct('FileVersion', '{v}'),
      StringStruct('InternalName', 'KernelXray'),
      StringStruct('OriginalFilename', 'KernelXray_{v}.exe'),
      StringStruct('ProductName', 'KernelXray'),
      StringStruct('ProductVersion', '{v}')])]),
    VarFileInfo([VarStruct('Translation', [1049, 1200])])
  ]
)
""", encoding="utf-8")


def main(argv: list[str]) -> int:
    cmd = argv[0] if argv else "current"
    if cmd == "bump":
        print(set_version(bump(current())))
    elif cmd == "set" and len(argv) > 1:
        print(set_version(argv[1]))
    elif cmd == "current":
        print(current())
    elif cmd == "resource" and len(argv) > 1:
        resource(current(), Path(argv[1]))
    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
