from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

from . import __version__
from .analysis.attribution import backfill_driver_names
from .analysis.kcore import build_kcore, write_kcore
from .analysis.rules import evaluate
from .core.console import ConsoleKeys
from .core.context import SessionContext
from .core.dump import write_telemetry
from .core.probe import ProbeResult
from .core.runner import Runner
from .core.privacy import anonymize_files
from .core.session import OverheadMeter
from .core.tools import (KERNEL_LOGGER, acquire_single_instance, beep, blocking_anticheat_running, is_admin,
                         kernel_logger_owner, stop_stale_etw_sessions)
from .report.html_report import render_report
from .probes import CAPTURE_PROBES, SNAPSHOT_PROBES

LOG_FORMAT = "%(asctime)s.%(msecs)03d - [%(levelname)s] - %(name)s: %(message)s"

# Программа всегда работает в режиме --arm: сессии ETW создаются до запуска игры, захват — по F9.
# Длительность окна фиксирована, выбирать её не нужно.
CAPTURE_SECONDS = 30

_INSTANCE_LOCK = None     # хэндл мьютекса единственного экземпляра, живёт до выхода процесса

# run.py смотрит на этот флаг: если выбор «открыть / закрыть» уже показан, второй паузы не нужно
FINAL_PROMPT_SHOWN = False


def _ask_open_report(report: Path) -> None:
    """После прогона окно не закрывается: Enter открывает отчёт в браузере, Esc или любая другая клавиша
    закрывает окно. Клавиша читается прямо из консоли (msvcrt), поэтому вопрос работает при любом способе
    запуска: двойным щелчком с запросом прав, из cmd, из терминала Windows."""
    global FINAL_PROMPT_SHOWN
    FINAL_PROMPT_SHOWN = True
    log = logging.getLogger("kernelxray")
    print("\n  [Enter] открыть отчёт    [Esc] закрыть", flush=True)
    key, how = _wait_enter_or_esc()
    log.info("финальный вопрос: %s (%s)", "открыть отчёт" if key == "enter" else "закрыть", how)
    if key == "enter":
        os.startfile(report)  # noqa: S606 - открыть отчёт в браузере по умолчанию


def _wait_enter_or_esc() -> tuple[str, str]:
    """("enter" | "esc", как прочитано). Реагирует только на Enter и Esc; остальные клавиши игнорируются.

    Основной путь — буфер ввода консоли (core/console.py), очищенный перед вопросом: в нём лежат нажатия
    со старта захвата, из-за них msvcrt.getwch() сразу возвращал «клавишу», и окно закрывалось само."""
    con = ConsoleKeys.open()
    if con:
        with con:
            try:
                con.flush()
                return con.wait(), "консоль"
            except OSError as exc:
                logging.getLogger("kernelxray").info("консоль не читается (%s), пробую msvcrt", exc)
    try:
        import msvcrt
        while msvcrt.kbhit():
            msvcrt.getwch()
        for _ in range(10000):
            ch = msvcrt.getwch()
            if ch in ("\x00", "\xe0"):     # стрелки и F-клавиши приходят двумя кодами
                msvcrt.getwch()
                continue
            if ch == "\r":
                return "enter", "msvcrt"
            if ch == "\x1b":
                return "esc", "msvcrt"
            if ch == "\uffff":               # чтение не работает: дальше ждать бессмысленно
                break
    except (ImportError, OSError):
        pass
    try:
        answer = input("  Открыть отчёт? [Enter = да, n = нет]: ").strip().lower()
        return ("enter" if answer in ("", "y", "д", "да") else "esc"), "строка ввода"
    except (EOFError, RuntimeError):         # RuntimeError: sys.stdin отсутствует
        return "esc", "нет ввода"


def _finish(report: Path, open_now: bool, no_prompt: bool) -> None:
    """Конец прогона. Вопрос задаётся всегда, кроме --open (открыть сразу) и --no-prompt (скрипты).

    Раньше он зависел от sys.stdin.isatty(): у exe, запущенного двойным щелчком (а не из bat-файла),
    проверка бывает ложной, и окно закрывалось сразу после отчёта."""
    if open_now:
        os.startfile(report)  # noqa: S606 - открыть отчёт в браузере по умолчанию
    elif not no_prompt:
        _ask_open_report(report)


def _can_prompt() -> bool:
    """Можно ли задать вопрос в конце: есть консоль, с которой читается клавиатура.

    Одного sys.stdin.isatty() мало: у exe, запущенного двойным щелчком с запросом прав (UAC) или в терминале
    Windows по умолчанию, он бывает ложным, хотя окно консоли есть и msvcrt читает клавиши. Раньше программу
    запускали из bat-файла (cmd), и это не проявлялось.
    """
    try:
        if sys.stdin and sys.stdin.isatty():
            return True
    except (ValueError, OSError):
        pass
    return _console_window()


def _console_window() -> bool:
    """У процесса есть окно консоли (Windows)."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        return bool(ctypes.windll.kernel32.GetConsoleWindow())
    except (AttributeError, OSError):
        return False


def _names(csv: str | None) -> set[str]:
    return {n.strip().upper() for n in csv.split(",")} if csv else set()


def _select(classes: list, only: set[str], skip: set[str]) -> list:
    return [c() for c in classes if (not only or c.name in only) and c.name not in skip]


def _setup_logging(log_path: Path) -> None:
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setFormatter(logging.Formatter(LOG_FORMAT, "%Y-%m-%d %H:%M:%S"))
    root.addHandler(fh)
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(logging.Formatter("  [%(levelname)s] %(message)s"))
    root.addHandler(ch)


def _print_summary(results: list[ProbeResult], analysis: dict) -> None:
    failed = [r for r in results if not r.success]
    print(f"\nПроб выполнено: {len(results) - len(failed)} из {len(results)}")
    for r in failed:
        print(f"  FAIL {r.probe:<18} {r.error}")
    print(f"\nОценка: {analysis['spi_score']} из 1000. {analysis['verdict']}")
    marks = {"critical": "[!!]", "warning": "[! ]", "info": "[i ]"}
    for f in analysis["findings"]:
        if f["severity"] in marks:
            print(f"  {marks[f['severity']]} {f['title']}  ({f['evidence']})")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="KernelXray", description="Диагностика системных задержек Windows. Запускать ДО игры: "
                                       f"сессии ETW создаются заранее, захват {CAPTURE_SECONDS} с — по F9 в бою.")
    # Старые ключи (ярлыки и bat-файлы прошлых версий): принимаются, но ничего не меняют
    ap.add_argument("-d", "--duration", type=int, default=None, help=argparse.SUPPRESS)
    ap.add_argument("--delay", type=int, default=None, help=argparse.SUPPRESS)
    ap.add_argument("--arm", action="store_true", help=argparse.SUPPRESS)
    # Только для диагностики (например, привязаны ли рывки к F9 или к концу окна): в справке не показывается
    ap.add_argument("--diag-window", type=int, default=None, help=argparse.SUPPRESS)
    ap.add_argument("-o", "--out", type=Path, default=Path("xray_reports"), help="папка для результатов")
    ap.add_argument("-p", "--process", help="подсказка, какой процесс считать игрой (необязательно: "
                    "игра определяется автоматически, можно часть имени, например r5apex)")
    ap.add_argument("--deep", action="store_true", help="добавить CSWITCH/DISPATCHER в ETW (тяжелее)")
    ap.add_argument("--keep-raw", action="store_true", help="не удалять .etl после анализа")
    ap.add_argument("--frames-full", action="store_true",
                    help="в режиме ETL включать провайдеры кадров целиком (файл в разы больше; для проверки)")
    ap.add_argument("--frames-etl", action="store_true", help=argparse.SUPPRESS)   # теперь всегда так (--arm)
    ap.add_argument("--only", help="запустить только эти пробы, через запятую")
    ap.add_argument("--skip", help="пропустить эти пробы, через запятую")
    ap.add_argument("--no-snapshots", action="store_true", help="только захват (ETW, кадры, счётчики)")
    ap.add_argument("--list", action="store_true", help="показать список проб и выйти")
    ap.add_argument("--open", action="store_true", help="открыть отчёт в браузере после завершения, без вопроса")
    ap.add_argument("--anonymize", action="store_true",
                    help="убрать имя пользователя и компьютера из отчёта и telemetry.json (для отправки другим)")
    ap.add_argument("--no-prompt", action="store_true", help="не спрашивать в конце, открывать ли отчёт (для скриптов)")
    ap.add_argument("--version", action="version", version=f"KernelXray {__version__}")
    args = ap.parse_args(argv)

    if args.list:
        for c in SNAPSHOT_PROBES + CAPTURE_PROBES:
            print(c.name)
        return 0
    if sys.platform != "win32":
        print("KernelXray работает только под Windows.")
        return 2
    if not is_admin():
        print("Нужны права администратора (kernel ETW). Запусти от имени администратора.")
        return 1

    # Сессии ETW создаются до игры: с запущенной игрой под EA AntiCheat Windows их создать не даст
    game = blocking_anticheat_running()
    if game:
        print(f"{game} уже запущен. Закрой игру полностью и запусти KernelXray снова: сессии ETW создаются "
              f"до запуска игры, а захват потом включается по F9 уже в бою.")
        return 5

    global _INSTANCE_LOCK
    _INSTANCE_LOCK = acquire_single_instance()
    if _INSTANCE_LOCK is None:
        print("KernelXray уже запущен в другом окне. Дождись его завершения: два захвата одновременно "
              "не работают (NT Kernel Logger в системе один).")
        return 4

    # NT Kernel Logger в системе один. Если его держит другая программа, остановка оборвёт её запись.
    busy, owner = kernel_logger_owner()
    if busy and owner:
        print(f"Внимание: {KERNEL_LOGGER} сейчас занят, похоже, программой {owner}. "
              f"KernelXray остановит эту сессию, и её запись прервётся.")
        if not args.no_prompt and _can_prompt():
            try:
                if input("  Продолжить? [Enter = да, n = выйти]: ").strip().lower() in ("n", "н", "no", "нет"):
                    return 0
            except EOFError:
                pass

    # Глушим зависшие сессии прошлого запуска: logman stop ... -ets
    cleanup = stop_stale_etw_sessions()
    for name, stopped, _ in cleanup:
        if stopped:
            print(f"Остановлена оставшаяся ETW-сессия: {name}")

    out_dir = (args.out / datetime.now().strftime("%Y%m%d_%H%M%S")).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    _setup_logging(out_dir / "kernel_xray.log")
    log = logging.getLogger("kernelxray")
    window_s = CAPTURE_SECONDS if args.diag_window is None else max(10, min(180, args.diag_window))
    log.info("KernelXray %s, захват %s с по F9 (режим --arm)%s", __version__, window_s,
             " — диагностическая длина окна" if window_s != CAPTURE_SECONDS else "")
    log.info("аргументы: %s", " ".join(sys.argv[1:]) or "(нет)")
    if args.duration is not None or args.delay is not None:
        log.info("ключи -d/--delay устарели и не используются: окно захвата всегда %s с", CAPTURE_SECONDS)
    for name, stopped, output in cleanup:
        log.info("logman stop \"%s\" -ets: %s | %s", name, "stopped" if stopped else "not running", output)

    only, skip = _names(args.only), _names(args.skip)
    snapshots = [] if args.no_snapshots else _select(SNAPSHOT_PROBES, only, skip)
    captures = _select(CAPTURE_PROBES, only, skip)
    ctx = SessionContext(out_dir=out_dir, duration_s=window_s, target_process=args.process,
                         start_delay_s=0, deep_trace=args.deep, keep_raw=args.keep_raw, arm=True)
    ctx.shared["presentmon_mode"] = "etl"       # в режиме --arm кадры всегда пишутся в .etl
    ctx.shared["frames_full"] = args.frames_full

    started = datetime.now()
    print(f"KernelXray {__version__} -> {out_dir}")
    print(f"Сначала быстрые проверки ({len(snapshots)}), затем создание сессий ETW.")
    if captures:
        print(f"Игру запускай после сообщения «Сессии ETW созданы». В бою нажми F9 — захват {window_s} с. "
              f"Сигнал — начало захвата, второй сигнал — отчёт готов.")
    with OverheadMeter() as meter:
        results = Runner(ctx, snapshots, captures).run()
    if backfill_driver_names(results):
        log.info("Имена драйверов в сводке DPC/ISR взяты из снимка модулей ядра (в трассе их не было)")

    for leftover in ["kernel_raw.etl"] + ([] if args.keep_raw else ["xray_kernel.etl"]):
        try:
            (out_dir / leftover).unlink(missing_ok=True)   # kernel_raw.etl — промежуточный файл живой сессии
        except OSError:
            log.info("%s занят (сессию не дали остановить), не удалён", leftover)

    dicts = [r.to_dict() for r in results]
    analysis = evaluate(dicts)
    metrics = {r.probe: r.raw_metrics_json for r in results if r.success}
    overhead = meter.result()
    write_telemetry(out_dir / "telemetry.json", results, overhead, analysis)
    kcore = build_kcore(analysis, metrics)
    write_kcore(out_dir / "xray_profile.kcore", kcore)
    log.info("Профиль сохранён: xray_profile.kcore (оценка и id известных исправлений, JSON в base64)")
    report = out_dir / "kernel_xray_report.html"
    render_report(report, dicts, analysis, {
        "started": started.strftime("%Y-%m-%d %H:%M"), "duration_s": window_s,
        "version": __version__, "overhead": overhead, "scan_id": kcore["scan_id"], "out_dir": str(out_dir),
    })

    if args.anonymize:
        root = logging.getLogger()
        for h in list(root.handlers):          # лог дописан: закрываем, чтобы переписать его без имён
            if isinstance(h, logging.FileHandler):
                h.close()
                root.removeHandler(h)
        anonymize_files([report, out_dir / "telemetry.json", out_dir / "kernel_xray.log"])
    _print_summary(results, analysis)
    print(f"\nОтчёт: {report}")
    beep(800)                               # всё готово: итоги выведены, отчёт записан
    _finish(report, args.open, args.no_prompt)
    return 0 if any(r.success for r in results) else 3


if __name__ == "__main__":
    raise SystemExit(main())
