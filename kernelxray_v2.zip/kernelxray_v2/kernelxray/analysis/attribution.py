"""Имена драйверов в сводке ETW_TRACER, если xperf их не определил.

ETW_TRACER строит таблицы по драйверам из `xperf -a dpcisr`. Когда в трассе нет списка загруженных
образов (кольцо --arm провернулось, а остановку логгера запретил античит), там один модуль Unknown.
ETW_SONAR разбирает ту же трассу поэвентно и восстанавливает имена по адресам процедур и снимку модулей
ядра (core/kmodules.py). Здесь его разбивка по модулям подставляется вместо Unknown, а сводка ETW_TRACER
пересчитывается: карта ядер, таблицы драйверов и правила снова видят настоящие имена.
"""
from __future__ import annotations

from ..core.probe import ProbeResult
from ..parsers.dpcisr import summarize
from ..parsers.dumper import is_unknown_module

# Подменяем разбивку xperf, только если в ней без имени большая часть времени: частичные Unknown
# (пара событий без rundown) не повод выбрасывать разбор xperf.
UNKNOWN_SHARE_TO_REPLACE = 0.5


def _unknown_share(modules: dict) -> float:
    total = sum(m.get("total_us") or 0 for m in modules.values())
    if not total:
        return 0.0
    return sum(m.get("total_us") or 0 for n, m in modules.items() if is_unknown_module(n)) / total


def backfill_driver_names(results: list[ProbeResult]) -> bool:
    """Подставляет в ETW_TRACER модули с именами из ETW_SONAR. True, если сводка пересчитана."""
    by = {r.probe: r for r in results if r.success}
    tracer, sonar = by.get("ETW_TRACER"), by.get("ETW_SONAR")
    if not tracer or not sonar:
        return False
    detail = sonar.raw_metrics_json.get("modules_detail") or {}
    raw = tracer.raw_metrics_json.get("raw") or {}
    changed = []
    for key in ("dpc", "isr"):
        sec, det = raw.get(key), detail.get(key)
        if not sec or not det or _unknown_share(sec.get("modules") or {}) < UNKNOWN_SHARE_TO_REPLACE:
            continue
        ncpu = max(sec.get("cpu_count") or 0, *(len(m["per_cpu_us"]) for m in det.values()))
        sec["modules"] = {
            name: {"per_cpu_us": (list(m["per_cpu_us"]) + [0] * ncpu)[:ncpu], "total_us": m["total_us"],
                   "count": m["count"], "histogram": [list(b) for b in m["histogram"]]}
            for name, m in det.items()
        }
        sec["cpu_count"] = ncpu
        changed.append(key)
    if not changed:
        return False
    fresh = summarize(raw)
    for k in ("dpc", "isr", "heatmap"):
        if k in fresh:
            tracer.raw_metrics_json[k] = fresh[k]
    tracer.raw_metrics_json["driver_names_from"] = "снимок модулей ядра (поэвентный разбор ETW_SONAR)"
    return True
