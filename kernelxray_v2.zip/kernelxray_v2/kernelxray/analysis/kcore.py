"""xray_profile.kcore: base64(JSON) с оценкой и списком id исправлений (формат старой версии)."""
from __future__ import annotations

import base64
import datetime as dt
import json
import uuid
from pathlib import Path


def build_kcore(analysis: dict, metrics: dict) -> dict:
    hw = metrics.get("HARDWARE_INFO") or {}
    topo = metrics.get("CPU_TOPOLOGY") or {}
    return {
        "timestamp": dt.datetime.now().isoformat(),
        "scan_id": uuid.uuid4().hex[:12],
        "spi_score": analysis["spi_score"],
        "target_fixes": analysis["target_fixes"],
        "hardware": {
            "cpu": hw.get("cpu_name"),
            "architecture": topo.get("architecture"),
            "cores": topo.get("total_cores"),
            "gpu": (hw.get("gpus") or [{}])[0].get("name"),
            "ram_gb": hw.get("ram_total_gb"),
            "board": hw.get("motherboard"),
            "os_build": hw.get("os_build"),
        },
    }


def write_kcore(path: Path, payload: dict) -> None:
    raw = json.dumps(payload, indent=2, ensure_ascii=False).encode("utf-8")
    path.write_bytes(base64.b64encode(raw))


def read_kcore(path: Path) -> dict:
    return json.loads(base64.b64decode(Path(path).read_bytes()).decode("utf-8"))
