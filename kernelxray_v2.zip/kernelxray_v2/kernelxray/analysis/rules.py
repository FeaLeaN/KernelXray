"""Правила: результаты проб -> находки с серьёзностью, объяснением и (если применимо) id исправления.

Принципы:
  * находка ссылается на измеренные данные (evidence), а не на «общие советы»;
  * пороги консервативные: предупреждение только там, где есть понятный механизм влияния на задержки;
  * настройки безопасности (VBS/HVCI, Spectre, Defender) только описываются, id исправления у них нет:
    отключать защиту ради пары процентов FPS решает человек, а не твикер.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

PENALTY = {"critical": 150, "warning": 60, "info": 15, "ok": 0}     # по умолчанию, у находки можно переопределить
GAME_MODE_ON_PENALTY = 30           # включённый игровой режим: предупреждение со своим штрафом
SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2, "ok": 3}

# Намеренно используемый фоновый софт: не считаем его шумом (оверлеи/опрос датчиков).
BACKGROUND_EXCLUDE = {"rivatuner statistics server"}

# ntoskrnl.exe — DPC самого ядра (таймеры, планировщик), а не сторонний драйвер. «Самый длинный DPC»
# считаем без него — и в правилах, и в отчёте (одна функция на оба места, чтобы цифры не расходились).
DPC_MAX_EXCLUDE = {"ntoskrnl.exe"}
# В «самый длинный DPC» попадают только драйверы, у которых за захват больше стольких DPC:
# единичные события (ACPI.sys и т. п.) не определяют пик.
DPC_MAX_MIN_EVENTS = 100
# Пороги самого длинного DPC, мкс: больше DPC_WARN_US — предупреждение (-60), от DPC_CRIT_US — критично (-150).
DPC_WARN_US = 250
DPC_CRIT_US = 500


def dpc_state(us: float | None) -> str:
    """clean / warning / critical для самого длинного DPC — одна шкала для правила и отчёта."""
    if us is None:
        return "info"
    return "critical" if us >= DPC_CRIT_US else "warning" if us > DPC_WARN_US else "clean"


def _dpc_max_eligible(name: str | None, count: int | None) -> bool:
    return (name or "").lower() not in DPC_MAX_EXCLUDE and (count or 0) > DPC_MAX_MIN_EVENTS


def dpc_max(sonar: dict | None, tracer: dict | None) -> tuple[int | None, str, str]:
    """(макс. длительность DPC в мкс, драйвер, «точно» | «верхняя граница») без DPC самого ядра
    и без драйверов, у которых за захват не больше DPC_MAX_MIN_EVENTS событий."""
    if sonar:
        all_mods = (sonar.get("dpc") or {}).get("modules_by_max") or []
        mods = [m for m in all_mods if m.get("max_us") is not None and _dpc_max_eligible(m.get("module"), m.get("count"))]
        if mods:
            top = max(mods, key=lambda m: m["max_us"])
            return top["max_us"], top["module"], "точно"
        if all_mods:            # разбор по модулям есть, но ни один драйвер не прошёл фильтр
            return None, "?", "точно"
        return (sonar.get("dpc") or {}).get("max_us"), "?", "точно"
    raw = ((tracer or {}).get("raw") or {}).get("dpc") or {}
    best, who = None, "?"
    for name, m in (raw.get("modules") or {}).items():
        if not _dpc_max_eligible(name, m.get("count")):
            continue
        his = [hi for lo, hi, cnt in (m.get("histogram") or []) if cnt > 0]
        if his and (best is None or max(his) > best):
            best, who = max(his), name
    if best is not None:
        return best, who, "верхняя граница"
    return ((tracer or {}).get("dpc") or {}).get("max_latency_bucket_us"), "?", "верхняя граница"


GPU_MODULES = {"dxgkrnl.sys", "dxgmms2.sys", "amdkmdag.sys", "nvlddmkm.sys", "igdkmd64.sys", "igdkmdn64.sys",
               "atikmdag.sys", "amdfendr.sys"}
# Сеть — только то, что обслуживает прерывания сетевой карты (NDIS вызывает ISR/DPC минипортов, либо сам минипорт).
# tcpip.sys сюда не входит: стек TCP/IP работает на любом ядре, где обрабатываются пакеты и таймеры сокетов,
# политика affinity его не переносит, а единичные таймерные DPC встречаются на всех ядрах.
# Службы сетевых карт из пробы CORE_COLLISION добавляются к этому списку на лету (см. _net_services).
NET_HINTS = ("ndis.sys", "rt640x64.sys", "rtux64w10.sys", "e1d", "e2f", "i225", "netwtw", "killer",
             "rtwlane", "mtkwl", "athw", "bcmwl")
# Wdf01000.sys здесь нет: через KMDF работают и USB-контроллеры, и сетевые карты на NetAdapterCx, и часть звука,
# а xperf приписывает их ISR/DPC самому фреймворку. Чьё это прерывание, решает _resolve_kmdf по ядру.
USB_MODULES = {"usbxhci.sys", "ucx01000.sys", "usbport.sys", "usbhub3.sys", "hidclass.sys",
               "hidusb.sys", "mouhid.sys", "kbdhid.sys"}
AUDIO_HINTS = ("hdaudbus.sys", "hdaudio.sys", "portcls.sys", "usbaudio", "rtkvhd", "ks.sys")
KMDF_MODULE = "wdf01000.sys"
_DEVICE_KIND = {"usb": "usb", "net": "net", "media": "audio"}      # класс PCI-устройства -> вид для столкновений

# Столкновение на ядре. Драйвер считается «соседом», только если занимает на ядре заметную долю времени:
# иначе любое ядро «сталкивается» со всем подряд из-за единичных фоновых DPC.
COLLISION_MIN_SHARE_PCT = 0.02     # % времени ядра за захват (0,02% = 6 мс за 30 с)
COLLISION_MIN_CORE_PCT = 2.0       # ядра, где DPC/ISR в сумме меньше, не проверяем
KIND_LABEL = {"gpu": "видеокарта", "net": "сеть", "usb": "USB", "audio": "звук", "kmdf": "KMDF"}
_KIND_INSTR = {"net": "сетью", "usb": "USB", "audio": "звуком", "kmdf": "устройствами на KMDF"}


SUBSYSTEMS = ["KERNEL & DRIVERS", "LATENCY", "FRAME STABILITY", "NETWORK STACK", "HARDWARE", "OS LAYER"]
_CATEGORY_PREFIX = [
    ("ETW_", "KERNEL & DRIVERS"), ("CORE_", "KERNEL & DRIVERS"), ("AUDIO_", "KERNEL & DRIVERS"),
    ("GPU_", "KERNEL & DRIVERS"), ("TIMER_", "LATENCY"), ("PERF_", "LATENCY"), ("INPUT_", "LATENCY"),
    ("USB_", "LATENCY"), ("PCIE_", "LATENCY"), ("FRAMES_", "FRAME STABILITY"), ("HW_REFRESH", "FRAME STABILITY"),
    ("OS_BACKGROUND", "FRAME STABILITY"), ("NET_", "NETWORK STACK"), ("HW_", "HARDWARE"), ("STORAGE_", "HARDWARE"),
    ("BIOS_", "HARDWARE"), ("OS_", "OS LAYER"), ("PROC_", "OS LAYER"), ("MEM_", "OS LAYER"), ("SEC_", "OS LAYER"),
]


def category_of(finding_id: str) -> str:
    return next((cat for prefix, cat in _CATEGORY_PREFIX if finding_id.startswith(prefix)), "OS LAYER")


@dataclass
class Finding:
    id: str
    severity: str
    title: str
    detail: str
    evidence: str = ""
    fix_id: str | None = None
    penalty: int | None = None     # None = по серьёзности; 0 = пункт к сведению, на индекс не влияет

    def to_dict(self) -> dict:
        d = asdict(self)
        d["penalty"] = PENALTY[self.severity] if self.penalty is None else self.penalty
        d["category"] = category_of(self.id)
        return d


class _Ctx:
    def __init__(self, results: list[dict]):
        self.m = {r["probe"]: r["raw_metrics_json"] for r in results if r.get("success")}
        self.failed = {r["probe"]: r.get("error") for r in results if not r.get("success")}
        self.out: list[Finding] = []

    def get(self, probe: str) -> dict:
        return self.m.get(probe) or {}

    def add(self, *a, **kw) -> None:
        self.out.append(Finding(*a, **kw))


def _kind(module: str, net_services: tuple[str, ...] = ()) -> str | None:
    m = module.lower()
    if m in GPU_MODULES:
        return "gpu"
    if any(h in m for h in NET_HINTS) or any(m.startswith(s) for s in net_services):
        return "net"
    if m in USB_MODULES:
        return "usb"
    if any(h in m for h in AUDIO_HINTS):
        return "audio"
    if m == KMDF_MODULE:
        return "kmdf"
    return None


def _mask_bits(mask) -> set[int]:
    try:
        m = int(str(mask), 0)
    except (TypeError, ValueError):
        return set()
    return {i for i in range(64) if m >> i & 1}


def _net_services(devices: list[dict]) -> tuple[str, ...]:
    """Службы сетевых карт (rt25cx21, e2fexpress...): модуль минипорта в трассе начинается с имени службы."""
    return tuple((d.get("service") or "").lower() for d in devices if d.get("class") == "net" and d.get("service"))


def _resolve_kmdf(cpu: int, devices: list[dict], modules_here: set[str]) -> tuple[set[str], list[str]]:
    """Чьи прерывания стоят за Wdf01000.sys на этом ядре: (виды, имена устройств).

    Сам KMDF-драйвер в трассе не виден, поэтому опора — ручная привязка прерываний устройств к ядрам:
    если USB-контроллер закреплён за ядром 10, Wdf01000.sys на ядре 10 — это он. Устройство, чей собственный
    модуль уже есть на этом ядре (NDIS-минипорт, например), работает не через KMDF — его пропускаем.
    Видеокарту не рассматриваем: её драйвер не KMDF, а маска affinity у неё может и не соблюдаться.
    Пустой результат = устройство за фреймворком определить нельзя.
    """
    kinds, names = set(), []
    for d in devices:
        kind = _DEVICE_KIND.get(d.get("class"))
        if not kind or cpu not in _mask_bits(d.get("affinity_mask")):
            continue
        svc = (d.get("service") or "").lower()
        if svc and any(m.startswith(svc) for m in modules_here):
            continue
        kinds.add(kind)
        names.append(d.get("name") or svc)
    return kinds, names


def core_driver_us(tracer: dict | None) -> dict[int, dict[str, int]]:
    """Время DPC+ISR каждого драйвера на каждом ядре за захват, мкс: {cpu: {driver: us}}.

    Берётся из сырого разбора dpcisr (он всегда лежит в ETW_TRACER.raw), а если его нет — из тепловой карты.
    """
    out: dict[int, dict[str, int]] = {}
    raw = (tracer or {}).get("raw") or {}
    for key in ("dpc", "isr"):
        for name, m in ((raw.get(key) or {}).get("modules") or {}).items():
            for cpu, us in enumerate(m.get("per_cpu_us") or []):
                if us:
                    row = out.setdefault(cpu, {})
                    row[name] = row.get(name, 0) + us
    if not out:
        for cpu, h in ((tracer or {}).get("heatmap") or {}).items():
            if h.get("driver_us"):
                out[int(cpu)] = dict(h["driver_us"])
    return out


def core_map(tracer: dict | None, devices: list[dict] | None) -> dict[int, list[dict]]:
    """Все драйверы на каждом ядре по убыванию времени — общая основа для правила и для карты в отчёте.

    Строка: driver, us, share_pct (доля времени ядра), kinds (виды устройств), devices (кто за Wdf01000.sys),
    counts (доля не меньше порога: драйвер участвует в поиске столкновений).
    """
    devices = devices or []
    net_svc = _net_services(devices)
    dur_us = ((tracer or {}).get("trace_duration_s") or 0) * 1e6
    out: dict[int, list[dict]] = {}
    for cpu, mods in sorted(core_driver_us(tracer).items()):
        here = {m.lower() for m in mods}
        rows = []
        for name, us in sorted(mods.items(), key=lambda kv: (-kv[1], kv[0].lower())):
            kind, devs = _kind(name, net_svc), []
            if kind == "kmdf":
                kinds, devs = _resolve_kmdf(cpu, devices, here)
                kinds = kinds or {"kmdf"}
            else:
                kinds = {kind} if kind else set()
            share = us / dur_us * 100 if dur_us else None
            rows.append({"driver": name, "us": us, "share_pct": share, "kinds": sorted(kinds), "devices": devs,
                         "counts": share is None or share >= COLLISION_MIN_SHARE_PCT})
        out[cpu] = rows
    return out


def find_collisions(tracer: dict | None, devices: list[dict] | None) -> list[dict]:
    """Ядра, где видеокарта и другое устройство (сеть, USB, звук, KMDF) оба заметно нагружают ядро.

    Видеокарта берётся из трассы, а не из маски affinity: её драйвер может распределять прерывания сам.
    """
    heat = (tracer or {}).get("heatmap") or {}
    hits = []
    for cpu, rows in core_map(tracer, devices).items():
        if ((heat.get(str(cpu)) or {}).get("percent") or 0) < COLLISION_MIN_CORE_PCT:
            continue
        involved = [r for r in rows if r["counts"] and r["kinds"]]
        kinds = {k for r in involved for k in r["kinds"]}
        others = kinds - {"gpu"}
        if "gpu" in kinds and others:
            hits.append({"cpu": cpu, "others": others, "rows": involved})
    return hits


def fmt_us(us: float) -> str:
    return f"{us / 1000:.1f} мс" if us >= 1000 else f"{us:.0f} мкс"


# --------------------------------------------------------------------------
def _rules_kernel(c: _Ctx) -> None:
    sonar, tracer = c.get("ETW_SONAR"), c.get("ETW_TRACER")
    if not sonar and not tracer:
        if "ETW_TRACER" in c.failed:
            c.add("ETW_MISSING", "info", "Трассировка ядра не выполнена",
                  "Без ETW нельзя оценить задержки DPC/ISR. Основная часть диагностики недоступна.",
                  str(c.failed["ETW_TRACER"])[:200])
        return

    # Точные значения берём у SONAR, при его отсутствии — верхнюю границу корзины гистограммы dpcisr.
    dpc_max_us, dpc_who, exact = dpc_max(sonar, tracer)
    dpc_max_us = dpc_max_us or 0
    if sonar:
        isr_max = sonar["isr"]["max_us"] or 0
        isr_top = sonar["isr"]["modules_by_max"][:1]
        isr_who = isr_top[0]["module"] if isr_top else "?"
    else:
        isr_max = tracer.get("isr", {}).get("max_latency_bucket_us") or 0
        idrivers = sorted(tracer.get("isr", {}).get("top_drivers", []), key=lambda d: d.get("max_latency_bucket_us") or 0)
        isr_who = idrivers[-1]["driver"] if idrivers else "?"

    st = dpc_state(dpc_max_us)
    if st == "critical":
        c.add("ETW_DPC_MAX", "critical", f"Очень длинный DPC у {dpc_who}",
              f"Отдельные DPC от {DPC_CRIT_US} мкс. Пока DPC выполняется, ядро не переключается на потоки игры "
              f"и звука: такие задержки дают треск и рывки кадров. Обычно лечится обновлением или откатом "
              f"этого драйвера.",
              f"макс. DPC {dpc_max_us} мкс ({exact})", fix_id="ETW_DRIVER_DPC")
    elif st == "warning":
        c.add("ETW_DPC_MAX", "warning", f"Длинные DPC у {dpc_who}",
              f"Отдельные DPC дольше {DPC_WARN_US} мкс (но меньше {DPC_CRIT_US}). Пока DPC выполняется, ядро не "
              f"переключается на потоки "
              f"игры; это первый кандидат при жалобах на микрорывки.",
              f"макс. DPC {dpc_max_us} мкс ({exact})", fix_id="ETW_DRIVER_DPC")
    else:
        c.add("ETW_DPC_MAX", "ok", "Длительность DPC в норме", f"Ни один DPC драйверов не дотянул до {DPC_WARN_US} мкс (DPC самого ядра ntoskrnl.exe и драйверов, у которых "
              f"за захват не больше {DPC_MAX_MIN_EVENTS} DPC, не учитываются).",
              f"макс. DPC {dpc_max_us} мкс ({exact})")

    if isr_max >= 500:
        c.add("ETW_ISR_MAX", "critical", f"Очень длинное прерывание у {isr_who}",
              "Обработчик прерывания должен занимать единицы микросекунд. Сотни мкс указывают на проблему "
              "драйвера или устройства.", f"макс. ISR {isr_max} мкс ({exact})", fix_id="ETW_DRIVER_ISR")
    elif isr_max >= 100:
        c.add("ETW_ISR_MAX", "warning", f"Длинные прерывания у {isr_who}",
              "ISR дольше 100 мкс встречаются у проблемных драйверов. Стоит проверить версию драйвера.",
              f"макс. ISR {isr_max} мкс ({exact})", fix_id="ETW_DRIVER_ISR")

    heat = tracer.get("heatmap", {}) if tracer else {}
    for cpu, h in sorted(heat.items(), key=lambda kv: -(kv[1].get("percent") or 0))[:1]:
        pct = h.get("percent") or 0
        if pct >= 10:
            sev = "critical" if pct >= 25 else "warning"
            c.add("ETW_CORE_LOAD", sev, f"Ядро {cpu} перегружено прерываниями",
                  f"{pct:.1f}% времени ядро {cpu} обрабатывает DPC/ISR. Потоки, попавшие на это ядро, "
                  f"получают меньше времени и чаще опаздывают.",
                  f"CPU {cpu}: {pct:.2f}%, драйверы: {', '.join(h.get('drivers', [])[:3])}", fix_id="CORE_AFFINITY")

    _rule_core_collision(c, tracer)

    if sonar:
        worst = (sonar.get("worst_cpu_windows_1ms") or [{}])[0]
        busy = worst.get("busy_us") or 0
        if busy >= 500:
            c.add("ETW_BURST", "warning", "Всплеск: ядро больше половины миллисекунды обрабатывало DPC/ISR",
                  "В одно миллисекундное окно на одном ядре пришлось много DPC/ISR подряд. Такие всплески "
                  "дают единичные подлагивания, даже если средние цифры хорошие.",
                  f"CPU {worst.get('cpu')} в {worst.get('at_ms')} мс: занято {busy} из 1000 мкс, "
                  f"больше всего времени — {worst.get('top_module')}")
        audio_long = [m for m in sonar["dpc"]["modules_by_max"] if _kind(m["module"]) == "audio" and m["max_us"] >= 250]
        if audio_long:
            m = audio_long[0]
            c.add("AUDIO_DPC_LONG", "warning", f"Аудиодрайвер {m['module']} выдаёт длинные DPC",
                  "Длинные DPC звукового стека ведут к треску и щелчкам при малом буфере.",
                  f"макс. {m['max_us']} мкс", fix_id="AUDIO_DRIVER")


def _rule_core_collision(c: _Ctx, tracer: dict | None) -> None:
    """Видеокарта и другое устройство заметно нагружают одно и то же ядро. Одна находка на все такие ядра."""
    hits = find_collisions(tracer, c.get("CORE_COLLISION").get("devices"))
    if not hits:
        return
    order = ["net", "usb", "audio", "kmdf"]
    others = [k for k in order if any(k in h["others"] for h in hits)]
    words = " и ".join(_KIND_INSTR[k] for k in others)
    prep = "со" if words.startswith("зв") else "с"
    cpus = [str(h["cpu"]) for h in hits]
    where = f"ядре {cpus[0]}" if len(cpus) == 1 else f"ядрах {', '.join(cpus[:-1])} и {cpus[-1]}"

    def who(r: dict) -> str:
        label = "/".join(KIND_LABEL[k] for k in r["kinds"])
        if r["kinds"] == ["kmdf"]:
            label = "KMDF, устройство не определено"
        return f"{r['driver']} ({label}) {fmt_us(r['us'])}"

    ev = "; ".join(f"CPU {h['cpu']}: " + ", ".join(who(r) for r in h["rows"]) for h in hits)
    detail = ("Когда видеодрайвер и устройства ввода, звука или сети обслуживаются одним ядром, их обработчики "
              "выстраиваются в очередь. Эффект обычно небольшой, но при микрорывках это стоит развести. "
              "Видеодрайвер может распределять свои прерывания сам, не глядя на политику affinity, поэтому "
              "переносить надёжнее другое устройство — на ядро, где нет видеокарты.")
    if "kmdf" in others:
        detail += (" Wdf01000.sys — общий фреймворк драйверов KMDF: какое устройство за ним стоит, по трассе не видно, "
                   "чаще всего это USB-контроллер. Если закрепить прерывания устройств за ядрами, отчёт подпишет его.")
    c.add("CORE_COLLISION", "info", f"На {where} прерывания видеокарты делят ядро {prep} {words}", detail, ev,
          fix_id="CORE_AFFINITY")


def _rules_frames(c: _Ctx) -> None:
    pm = c.get("PRESENT_MON")
    if not pm.get("captured_frames"):
        # Нет кадров = нет данных, а не «всё идеально». Штрафа нет, но подсистема помечается как неизмеренная.
        reason = c.failed.get("PRESENT_MON") or pm.get("note") or "PresentMon не запускался"
        seen = ", ".join(f"{a}: {n}" for a, n in list((pm.get("observed_processes") or {}).items())[:5])
        c.add("FRAMES_NO_DATA", "info", "Кадры не захвачены", str(reason)[:400],
              f"процессы с кадрами: {seen}" if seen else "", penalty=0)
        return
    app, n = pm.get("application"), pm["captured_frames"]
    modes = pm.get("present_modes") or {}
    composed = sum(v for k, v in modes.items() if "Composed" in k)
    if composed / n > 0.5:
        c.add("FRAMES_COMPOSED", "warning", "Кадры идут через композитор Windows",
              "Режим Composed добавляет задержку вывода примерно на кадр. Обычно помогает полноэкранный режим "
              "или включённые «оптимизации для оконных игр».",
              f"{app}: {composed}/{n} кадров в Composed-режиме", fix_id="GPU_SCHEDULER_WINDOWED_OPT")
    stutter = pm.get("stutter_frames") or 0
    if stutter / n > 0.01:
        c.add("FRAMES_STUTTER", "warning", "Заметные рывки кадров",
              "Больше 1% кадров длятся вдвое дольше обычного. Сравни время рывков с всплесками DPC в отчёте.",
              f"{stutter} из {n} кадров, медиана {pm.get('median_ms_frame_time')} мс")
    avg, low = pm.get("avg_fps"), pm.get("fps_1pct_low")
    if avg and low and low < avg * 0.5:
        c.add("FRAMES_1PCT", "warning", "Проседания 1% low",
              "Худший 1% кадров вдвое медленнее среднего: игра ощущается менее плавной, чем говорит средний FPS.",
              f"средний {avg} FPS, 1% low {low} FPS")
    elif avg:
        c.add("FRAMES_OK", "ok", "Кадры стабильны", "Разброс времени кадра небольшой.",
              f"{app}: {avg} FPS, 1% low {low}, p99 {pm.get('p99_ms_between_presents')} мс")


def _rules_counters(c: _Ctx) -> None:
    pf = c.get("PERFMON_ELITE")
    avg = pf.get("avg") or {}
    if (avg.get("dpc_time_percent") or 0) >= 5:
        c.add("PERF_DPC_TIME", "warning", "Высокое суммарное время DPC",
              "В среднем больше 5% процессорного времени уходит на DPC.", f"{avg['dpc_time_percent']}%")
    _rule_hard_faults(c, pf)
    if avg.get("available_mbytes") is not None and avg["available_mbytes"] < 1500:
        c.add("PERF_LOW_RAM", "warning", "Мало свободной памяти",
              "Меньше 1,5 ГБ свободной памяти во время захвата.", f"{avg['available_mbytes']} МБ")


def _memory_pressure(c: _Ctx, pf: dict) -> bool:
    avail = (pf.get("median") or pf.get("avg") or {}).get("available_mbytes")
    load = c.get("MEMORY_MANAGEMENT").get("memory_load_percent")
    return (avail is not None and avail < 1500) or (load is not None and load >= 85)


def _rule_hard_faults(c: _Ctx, pf: dict) -> None:
    """Жёсткие ошибки страниц. Счётчик Memory\\Page Reads/sec считает ВСЕ чтения с диска по page fault:
    загрузку exe/dll, memory-mapped файлы и только в том числе pagefile.sys. Поэтому «файл подкачки»
    говорим только когда ETW показал чтения именно pagefile.sys; иначе это к сведению, без штрафа."""
    pressure = _memory_pressure(c, pf)
    hf = c.get("ETW_SONAR").get("hard_faults")
    # Атрибуции по файлам верим, только если строки xperf разобрались (формат дампа меняется между версиями WPT)
    trusted = hf is not None and (not hf.get("count") or (hf.get("parse_quality") or 0) >= 0.5)

    if trusted:                                                 # есть точная атрибуция по файлам
        pf_rate, total = hf.get("pagefile_per_sec") or 0, hf.get("per_sec") or 0
        top = ", ".join(f"{x['file'].rsplit(chr(92), 1)[-1]} ({x['count']})" for x in hf["top_files"][:3])
        if pf_rate >= 20:
            c.add("PERF_PAGEFILE_READS", "warning" if pf_rate >= 50 or pressure else "info",
                  "Чтения из файла подкачки",
                  "Система подтягивает выгруженные страницы из pagefile.sys: чья-то память не поместилась в RAM. "
                  "Если это происходит во время игры, возможны фризы. Закрой тяжёлые фоновые программы или добавь RAM.",
                  f"pagefile.sys: {pf_rate} событий/с ({hf['pagefile_io_mb']} МБ), всего hard faults: {total}/с")
        elif total >= 50:
            c.add("PERF_HARD_FAULTS", "info", "Жёсткие ошибки страниц (не файл подкачки)",
                  "Страницы читались с диска, но не из pagefile.sys: это загрузка программ, библиотек и "
                  "memory-mapped файлов. Разово это нормально; повторяется в игре — смотри, какой процесс читает.",
                  f"{total}/с, из pagefile.sys: {pf_rate}/с; топ: {top}", penalty=0)
        return

    # Фолбэк без ETW: источник неизвестен, берём медиану (устойчива к всплескам на старте/остановке)
    reads = (pf.get("median") or pf.get("avg") or {}).get("page_reads_per_sec") or 0
    if reads >= 50 and pressure:
        c.add("PERF_HARD_FAULTS", "warning", "Частые жёсткие ошибки страниц при нехватке памяти",
              "Памяти мало, а страницы часто читаются с диска: вероятно, идёт работа с файлом подкачки. "
              "Во время игры это даёт фризы.", f"медиана {reads} чтений/с")
    elif reads >= 50:
        c.add("PERF_HARD_FAULTS", "info", "Жёсткие ошибки страниц",
              "Страницы читались с диска. Памяти при этом достаточно, так что это скорее загрузка программ и "
              "библиотек, чем файл подкачки. Точный источник покажет ETW-трасса.",
              f"медиана {reads} чтений/с", penalty=0)


def _rules_hardware(c: _Ctx) -> None:
    hw = c.get("HARDWARE_MISCONFIG")
    if hw.get("xmp_likely_disabled"):
        c.add("HW_XMP", "warning", "Память работает ниже паспортной частоты",
              "Судя по маркировке модулей, комплект рассчитан на большую частоту. Включи XMP/EXPO в BIOS. "
              "Это делается только в BIOS, программно не исправить.",
              f"сейчас {hw.get('ram_speed_mhz')} МГц, по маркировке {hw.get('ram_kit_speed_from_part')} МГц")
    if hw.get("single_module"):
        c.add("HW_SINGLE_CHANNEL", "info", "Один модуль памяти",
              "Один модуль обычно означает одноканальный режим и заметно меньшую пропускную способность памяти.",
              f"{hw.get('ram_module_count')} модуль")
    for m in hw.get("monitors") or []:
        if m["current_hz"] < m["max_hz_at_resolution"]:
            dev = str(m.get("device") or "").split("\\")[-1]
            c.add("HW_REFRESH", "warning", f"Монитор {dev} работает не на максимальной частоте",
                  "Windows часто выставляет 60 Гц после переустановки драйвера или смены кабеля. "
                  "Частоту меняют в «Параметры → Дисплей → Расширенные параметры дисплея».",
                  f"{m['current_hz']} Гц из {m['max_hz_at_resolution']} Гц при {m['resolution']}",
                  fix_id="DISPLAY_REFRESH_RATE")

    bios = c.get("BIOS_FIRMWARE")
    if bios.get("forced_hpet_clock"):
        c.add("BIOS_FORCED_HPET", "warning", "Принудительный HPET как источник времени",
              "useplatformclock=Yes заставляет Windows читать время через медленный HPET вместо TSC. "
              "Это увеличивает накладные расходы на каждый запрос времени, а игры делают их постоянно.",
              "bcdedit: useplatformclock Yes", fix_id="BIOS_FIRMWARE_USEPLATFORMCLOCK")
    if bios.get("hvci_running"):
        c.add("SEC_HVCI", "info", "Включена целостность памяти (HVCI)",
              "HVCI защищает ядро от вредоносных драйверов и стоит нескольких процентов производительности "
              "в части игр. Это компромисс безопасности: на индекс он не влияет, решение за тобой.", "HVCI running", penalty=0)
    if (bios.get("bios_age_days") or 0) > 3 * 365:
        c.add("BIOS_OLD", "info", "BIOS старше трёх лет",
              "Обновления BIOS часто содержат новые версии AGESA/microcode и исправления стабильности памяти.",
              f"{bios.get('bios_version')} от {bios.get('bios_date')}")


def _rules_timing(c: _Ctx) -> None:
    sc = c.get("SYSTEM_CORE")
    j = sc.get("wake_jitter_ms") or {}
    if (j.get("p99") or 0) >= 3 or (j.get("max") or 0) >= 10:
        c.add("TIMER_WAKE_JITTER", "warning", "Потоки просыпаются с опозданием",
              "Запрос «проснуться через 1 мс» иногда выполняется гораздо позже. Это прямой показатель "
              "задержек планировщика и прерываний.",
              f"p99 {j.get('p99')} мс, макс. {j.get('max')} мс при запросе 1 мс", fix_id="SYSTEM_CORE_TIMERSTABILITYJITTER")
    elif j:
        c.add("TIMER_WAKE_OK", "ok", "Точность пробуждения потоков в норме", "",
              f"p99 {j.get('p99')} мс при запросе 1 мс")


def _rules_os(c: _Ctx) -> None:
    os_ = c.get("OS_CONFIG")
    if os_.get("game_mode") == "on":
        raw = os_.get("auto_game_mode_enabled")
        c.add("OS_GAME_MODE", "warning", "Игровой режим Windows включён",
              "Игровой режим вмешивается в планирование: перераспределяет потоки и приоритеты фоновых процессов "
              "во время игры. На части систем это даёт неровный фреймтайминг и проседания у фоновых программ "
              "(запись, стрим, голосовой чат). Выключается в «Параметры → Игры → Игровой режим».",
              "AutoGameModeEnabled не задан (по умолчанию включён)" if raw is None else f"AutoGameModeEnabled = {raw}",
              fix_id="OS_CONFIG_GAME_MODE", penalty=GAME_MODE_ON_PENALTY)
    plan = (os_.get("power_plan") or {}).get("known_as")
    if plan == "Power saver":
        c.add("OS_POWER_SAVER", "warning", "Включена схема «Экономия энергии»",
              "Процессор держит низкие частоты и медленно разгоняется: это прямо увеличивает время кадра.",
              (os_.get("power_plan") or {}).get("name") or "", fix_id="OS_CONFIG_POWER_PLAN")
    ps = os_.get("win32_priority_separation") or {}
    if ps and not ps.get("is_default"):
        c.add("OS_PRIO_SEPARATION", "info", "Изменён Win32PrioritySeparation",
              "Это распространённый твик. Измеримого эффекта на современных системах он обычно не даёт, "
              "но и вреда тоже. Отмечено для полноты.", f"значение {ps.get('hex')}", penalty=0)

    ent = c.get("OS_ENTROPY")
    if ent.get("background_recording") == 1:
        c.add("OS_BACKGROUND_RECORDING", "warning", "Включена фоновая запись игр (Xbox Game Bar)",
              "Постоянная запись последних минут игры нагружает видеокодировщик и диск.",
              "HistoricalCaptureEnabled = 1", fix_id="OS_ENTROPY_GAME_DVR")

    procs = c.get("PROCESSES")
    bg = [b for b in (procs.get("background_software") or []) if b["title"].lower() not in BACKGROUND_EXCLUDE]
    polling = [b["title"] for b in bg if b["kind"] in ("sensors", "rgb")]
    if polling:
        c.add("PROC_POLLING", "info", "Запущены программы опроса датчиков или RGB",
              "Такие программы опрашивают датчики и контроллеры по шине SMBus/USB. Это частый источник "
              "периодических всплесков DPC. Если видишь всплески, закрой их и сравни.",
              ", ".join(polling))
    overlays = [b["title"] for b in bg if b["kind"] in ("overlay", "capture")]
    if overlays:
        c.add("PROC_OVERLAYS", "info", "Активны оверлеи или запись экрана",
              "Оверлеи встраиваются в вывод кадра и могут менять режим презентации.", ", ".join(overlays))

    mem = c.get("MEMORY_MANAGEMENT")
    if mem.get("pagefile_disabled"):
        c.add("MEM_NO_PAGEFILE", "warning", "Файл подкачки отключён",
              "Без файла подкачки при нехватке памяти игры просто падают. Выигрыша в задержках это не даёт.",
              "PagingFiles пуст", fix_id="MEMORY_PAGEFILE")


def _rules_devices(c: _Ctx) -> None:
    gpu = c.get("GPU_ANALYSIS")
    for g in gpu.get("gpus") or []:
        if g.get("msi_supported") == 0:
            c.add("GPU_MSI_OFF", "warning", f"Видеокарта работает без MSI ({g.get('name')})",
                  "Без MSI устройство использует линейные прерывания, которые могут делиться с другими устройствами.",
                  "MSISupported = 0", fix_id="GPU_ANALYSIS_MSI_MODE")
    drv = c.get("DRIVER_MANIFEST")
    if (drv.get("gpu_driver_age_days") or 0) > 365:
        c.add("GPU_DRIVER_OLD", "info", "Видеодрайвер старше года",
              "Новые версии драйверов регулярно исправляют задержки DPC и проблемы с конкретными играми.",
              f"{drv.get('gpu_driver_version')} от {drv.get('gpu_driver_date')}")

    audio = c.get("AUDIO_DPC")
    if audio.get("enhancers_detected"):
        c.add("AUDIO_ENHANCERS", "info", "Установлены аудиоулучшайзеры",
              "Программные эффекты обработки звука (APO) добавляют задержку и иногда нагрузку на DPC.",
              ", ".join(audio.get("found_enhancers", [])[:5]))

    inp = c.get("INPUT_ELITE")
    if inp.get("pointer_precision"):
        c.add("INPUT_POINTER_PRECISION", "info", "Включено «Повышенная точность указателя»",
              "Это ускорение мыши, а не задержка: скорость курсора зависит от скорости движения. "
              "В шутерах обычно мешает мышечной памяти.", "MouseSpeed = 1", fix_id="INPUT_POINTER_PRECISION",
                  penalty=0)
    if (inp.get("power_managed_input_devices") or 0) > 0:
        c.add("INPUT_USB_POWER", "info", "Энергосбережение на USB-устройствах ввода",
              "Устройство может засыпать при простое и просыпаться с задержкой на первом движении.",
              f"устройств: {inp['power_managed_input_devices']}", fix_id="INPUT_USB_POWER")

    usb = c.get("USB_POWER")
    if usb.get("usb_selective_suspend_ac") == "enabled":
        c.add("USB_SELECTIVE_SUSPEND", "info", "Выборочная приостановка USB включена в схеме питания",
              "Может вызывать задержки пробуждения USB-устройств (особенно ЦАПов и беспроводных приёмников).",
              "USB selective suspend (AC) = enabled", fix_id="USB_POWER_SELECTIVE_SUSPEND")
    if usb.get("pcie_aspm_ac") in ("moderate", "maximum"):
        c.add("PCIE_ASPM", "info", "Энергосбережение PCIe (ASPM) включено",
              "Выход линка PCIe из энергосбережения добавляет микросекунды к первым обращениям к устройству.",
              f"ASPM (AC) = {usb.get('pcie_aspm_ac')}", fix_id="USB_POWER_PCIE_ASPM")

    for a in (c.get("NETWORK_ELITE").get("adapters") or []):
        if a.get("power_saving_features_on") and not a.get("wireless"):
            c.add("NET_EEE", "info", f"Энергосбережение Ethernet включено ({a.get('name')})",
                  "Energy Efficient Ethernet переводит линк в сон между пакетами. Иногда это даёт скачки пинга.",
                  ", ".join(a["power_saving_features_on"]), fix_id="NETWORK_ELITE_EEE")

    st = c.get("STORAGE_ELITE")
    sd = st.get("system_disk") or {}
    if sd.get("media") == "HDD":
        c.add("STORAGE_HDD", "warning", "Система стоит на жёстком диске",
              "Подгрузка данных с HDD во время игры даёт фризы на сотни миллисекунд.", sd.get("name") or "")
    if sd.get("health") in ("warning", "unhealthy"):
        c.add("STORAGE_HEALTH", "critical", "Системный диск сообщает о проблемах",
              "Сделай резервную копию важных данных.", f"{sd.get('name')}: {sd.get('health')}")
    if c.get("STORAGE_GUIDE").get("trim_enabled") is False:
        c.add("STORAGE_TRIM", "warning", "TRIM отключён",
              "Без TRIM SSD со временем замедляет запись.", "DisableDeleteNotify = 1", fix_id="STORAGE_TRIM")


# Ключевые поля, которые правила проверяют. Пусто (None) = проверить не удалось, а не «проблем нет».
KEY_FIELDS = [
    ("OS_CONFIG", ("power_plan", "guid"), "схема электропитания"),
    ("OS_CONFIG", ("min_processor_state_percent_ac",), "минимальное состояние процессора"),
    ("OS_CONFIG", ("core_parking_min_cores_percent_ac",), "парковка ядер"),
    ("USB_POWER", ("usb_selective_suspend_ac",), "выборочная приостановка USB"),
    ("USB_POWER", ("pcie_aspm_ac",), "энергосбережение PCIe (ASPM)"),
    ("STORAGE_GUIDE", ("trim_enabled",), "TRIM"),
    ("STORAGE_ELITE", ("system_disk",), "системный диск"),
    ("HARDWARE_MISCONFIG", ("ram_speed_mhz",), "частота памяти"),
    ("SYSTEM_CORE", ("wake_jitter_ms",), "точность пробуждения потоков"),
]
CAPTURE_PROBES = {"ETW_TRACER", "ETW_SONAR", "PRESENT_MON", "PERFMON_ELITE"}   # у них свои находки об отказе


def _rules_unchecked(c: _Ctx) -> None:
    missing = [f"{p}: {c.failed[p]}"[:120] for p in sorted(c.failed) if p not in CAPTURE_PROBES]
    for probe, path, label in KEY_FIELDS:
        if probe not in c.m:
            continue                      # проба целиком не выполнена — она уже в списке выше
        v = c.m[probe]
        for k in path:
            v = v.get(k) if isinstance(v, dict) else None
        if v is None:
            missing.append(label)
    if missing:
        c.add("CHECK_INCOMPLETE", "info", "Часть проверок не выполнена",
              "Эти пункты прочитать не удалось. Отсутствие находок по ним не значит, что с ними всё в порядке.",
              "; ".join(missing), penalty=0)


def _rules_extra(c: _Ctx) -> None:
    """Данные, которые раньше только показывались: таймер, MPO. Без штрафа.
    Ручная привязка прерываний к ядрам находкой не считается: она видна на карте ядер в отчёте."""
    tr = c.get("TIMER_RESOLUTION")
    cur = tr.get("current_resolution_ms")
    if cur is not None and cur < 1.0:
        ru = (lambda v: f"{v:g}".replace(".", ","))
        c.add("TIMER_HIGH_RES", "info", f"Системный таймер держится на {ru(cur)} мс",
              "Какая-то программа запросила повышенное разрешение таймера (игры, плееры и твикеры делают это "
              "часто). На задержки это не вредит, но немного повышает энергопотребление. Отмечено для полноты.",
              f"текущее разрешение {ru(cur)} мс, минимально возможное "
              f"{ru(tr['finest_resolution_ms']) if tr.get('finest_resolution_ms') is not None else '—'} мс", penalty=0)
    if c.get("GPU_SCHEDULER").get("mpo_disabled"):
        c.add("GPU_MPO_OFF", "info", "Отключены аппаратные оверлеи (MPO)",
              "Отключение MPO — известный твик против мерцания. Для игр в окне без рамки он может увеличить "
              "задержку вывода, потому что кадр чаще идёт через композитор Windows.",
              "OverlayTestMode = 5", penalty=0)


def evaluate(results: list[dict]) -> dict:
    c = _Ctx(results)
    for rule in (_rules_kernel, _rules_frames, _rules_counters, _rules_hardware, _rules_timing, _rules_os,
                 _rules_devices, _rules_extra, _rules_unchecked):
        try:
            rule(c)
        except Exception as exc:           # одно сломанное правило не должно ронять отчёт
            c.add(f"RULE_ERROR_{rule.__name__.upper()}", "info", "Правило не отработало", str(exc)[:200])
    findings = sorted(c.out, key=lambda f: SEVERITY_ORDER[f.severity])
    score = max(0, 1000 - sum(f.to_dict()["penalty"] for f in findings))
    worst = findings[0].severity if findings else "ok"
    verdict = {
        "critical": "Есть серьёзные источники задержек, начни с красных пунктов.",
        "warning": "Система в целом в порядке, но есть что поправить.",
        "info": "Серьёзных проблем с задержками не найдено.",
        "ok": "Серьёзных проблем с задержками не найдено.",
    }[worst]
    dicts = [f.to_dict() for f in findings]
    # Баланс подсистем для радара: 100 минус взвешенные штрафы находок этой подсистемы
    subsystems: dict[str, int | None] = {
        cat: max(0, round(100 - 0.4 * sum(f["penalty"] for f in dicts if f["category"] == cat)))
        for cat in SUBSYSTEMS}
    if not c.get("PRESENT_MON").get("captured_frames"):
        subsystems["FRAME STABILITY"] = None          # не измерено: не рисуем 100 на радаре
        verdict += " Кадры не захвачены, поэтому плавность картинки в оценку не вошла."
    return {
        "spi_score": score,
        "verdict": verdict,
        "subsystems": subsystems,
        "findings": dicts,
        "target_fixes": sorted({f.fix_id for f in findings if f.fix_id and f.severity in ("critical", "warning", "info")}),
    }
