"""Чтение Enter / Esc прямо из буфера ввода консоли (CONIN$), без sys.stdin и msvcrt.

Зачем. У exe, запущенного двойным щелчком (с запросом прав или в терминале Windows), sys.stdin бывает
«не терминалом», а msvcrt.getwch() в конце прогона возвращал «клавишу», которую никто не нажимал: окно
закрывалось сразу после отчёта. Здесь консоль открывается явно, буфер ввода перед вопросом очищается
(там остаются нажатия F9/Enter со старта захвата), и учитываются только нажатия Enter и Esc.
"""
from __future__ import annotations

import ctypes
import sys
from ctypes import byref, c_int32, c_uint16, c_uint32, c_void_p

KEY_EVENT = 0x0001
VK_RETURN, VK_ESCAPE = 0x0D, 0x1B
WAIT_OBJECT_0 = 0


class _KeyEvent(ctypes.Structure):
    _fields_ = [("bKeyDown", c_int32), ("wRepeatCount", c_uint16), ("wVirtualKeyCode", c_uint16),
                ("wVirtualScanCode", c_uint16), ("UnicodeChar", c_uint16), ("dwControlKeyState", c_uint32)]


class _Event(ctypes.Union):
    _fields_ = [("KeyEvent", _KeyEvent), ("_pad", ctypes.c_byte * 16)]


class INPUT_RECORD(ctypes.Structure):
    _fields_ = [("EventType", c_uint16), ("Event", _Event)]


def key_of(rec: INPUT_RECORD) -> str | None:
    """"enter" / "esc" для нажатия этих клавиш, иначе None (отпускание, мышь, фокус, другие клавиши)."""
    if rec.EventType != KEY_EVENT or not rec.Event.KeyEvent.bKeyDown:
        return None
    ev = rec.Event.KeyEvent
    if ev.wVirtualKeyCode == VK_RETURN or ev.UnicodeChar == 0x0D:
        return "enter"
    if ev.wVirtualKeyCode == VK_ESCAPE or ev.UnicodeChar == 0x1B:
        return "esc"
    return None


class ConsoleKeys:
    """Открытая консоль процесса. Создавать через open(): None, если консоли нет."""

    def __init__(self, k32, handle) -> None:
        self._k32, self._h = k32, handle

    @classmethod
    def open(cls) -> "ConsoleKeys | None":
        if sys.platform != "win32":
            return None
        try:
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.CreateFileW.restype = c_void_p
            k32.CreateFileW.argtypes = [ctypes.c_wchar_p, c_uint32, c_uint32, c_void_p, c_uint32, c_uint32, c_void_p]
            k32.ReadConsoleInputW.argtypes = [c_void_p, ctypes.POINTER(INPUT_RECORD), c_uint32,
                                             ctypes.POINTER(c_uint32)]
            k32.GetNumberOfConsoleInputEvents.argtypes = [c_void_p, ctypes.POINTER(c_uint32)]
            k32.FlushConsoleInputBuffer.argtypes = [c_void_p]
            k32.WaitForSingleObject.argtypes = [c_void_p, c_uint32]
            k32.WaitForSingleObject.restype = c_uint32
            k32.CloseHandle.argtypes = [c_void_p]
            # GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, OPEN_EXISTING
            h = k32.CreateFileW("CONIN$", 0xC0000000, 0x3, None, 3, 0, None)
        except (AttributeError, OSError):
            return None
        if not h or h == c_void_p(-1).value:
            return None
        return cls(k32, h)

    def flush(self) -> None:
        """Выбросить всё, что накопилось в буфере ввода (нажатия со старта захвата и т. п.)."""
        self._k32.FlushConsoleInputBuffer(self._h)

    def poll(self, timeout_ms: int) -> str | None:
        """Ждать до timeout_ms нажатия Enter/Esc. Возвращает "enter" / "esc" / None (ничего не нажато).
        Другие события вычитываются и отбрасываются. OSError — консоль перестала читаться."""
        if self._k32.WaitForSingleObject(self._h, timeout_ms) != WAIT_OBJECT_0:
            return None
        n = c_uint32(0)
        if not self._k32.GetNumberOfConsoleInputEvents(self._h, byref(n)):
            raise OSError(ctypes.get_last_error(), "GetNumberOfConsoleInputEvents")
        rec, got = INPUT_RECORD(), c_uint32(0)
        for _ in range(n.value):
            if not self._k32.ReadConsoleInputW(self._h, byref(rec), 1, byref(got)):
                raise OSError(ctypes.get_last_error(), "ReadConsoleInputW")
            key = key_of(rec)
            if key:
                return key
        return None

    def wait(self) -> str:
        """Ждать Enter или Esc без ограничения по времени (Ctrl+C прерывает ожидание)."""
        while True:
            key = self.poll(250)          # короткие ожидания: между ними Python обрабатывает Ctrl+C
            if key:
                return key

    def close(self) -> None:
        if self._h:
            self._k32.CloseHandle(self._h)
            self._h = None

    def __enter__(self) -> "ConsoleKeys":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

