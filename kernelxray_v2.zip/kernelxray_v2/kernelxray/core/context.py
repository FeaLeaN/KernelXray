from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SessionContext:
    """Общие параметры одного запуска, передаются во все пробы."""

    out_dir: Path
    duration_s: int = 30
    start_delay_s: int = 10             # пауза перед захватом, чтобы успеть развернуть игру
    target_process: str | None = None   # подсказка для выбора игры (можно часть имени); None = автовыбор
    deep_trace: bool = False            # + CSWITCH/DISPATCHER в ETW (тяжелее, но даёт планировщик)
    keep_raw: bool = False              # не удалять .etl после анализа
    arm: bool = False                   # --arm: ETW-сессии создаются до запуска игры, захват по F9
    interrupted: threading.Event = field(default_factory=threading.Event)
    shared: dict = field(default_factory=dict)       # обмен данными между пробами (путь к .etl и т.п.)
    log: logging.Logger = field(default_factory=lambda: logging.getLogger("kernelxray"))
