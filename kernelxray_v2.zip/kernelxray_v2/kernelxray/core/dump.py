from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .probe import ProbeResult


def write_telemetry(path: Path, results: list[ProbeResult], overhead: dict, analysis: dict | None = None) -> None:
    """Полный дамп сессии. Структура как у старого etw_debug.log, только без текстовой шапки."""
    doc = {
        "timestamp": time.time(),
        "session_info": {
            "pid": os.getpid(),
            "probes_executed": len(results),
            "heisenberg_overhead": overhead,
        },
        "probes_raw_volume": [r.to_dict() for r in results],
        "analysis": analysis,
    }
    path.write_text(json.dumps(doc, indent=4, ensure_ascii=False), encoding="utf-8")
