"""Минимальная обёртка над ETW API (advapi32) через ctypes: своя файловая сессия, включение провайдеров, остановка.

Зачем не logman: с EA AntiCheat (Battlefield 6) после старта игры StartTrace падает с ERROR_ACCESS_DENIED,
а EnableTraceEx2 по хэндлу заранее созданной сессии работает (github.com/GameTechDev/PresentMon/issues/573).
`logman update -p` по дороге делает и другие вызовы (запрос/обновление сессии по имени), и античит его
отклоняет. Здесь KernelXray сам держит хэндл сессии и включает провайдеры ровно одним вызовом EnableTraceEx2.
"""
from __future__ import annotations

import ctypes
import re
import subprocess
import uuid
from ctypes import c_int64, c_uint8, c_uint16, c_uint32, c_uint64, c_void_p, c_wchar_p
from pathlib import Path

ERROR_ACCESS_DENIED = 5
ERROR_ALREADY_EXISTS = 183
WNODE_FLAG_TRACED_GUID = 0x00020000
EVENT_TRACE_FILE_MODE_SEQUENTIAL = 0x00000001
EVENT_TRACE_CONTROL_STOP = 1
EVENT_CONTROL_CODE_DISABLE_PROVIDER = 0
EVENT_CONTROL_CODE_ENABLE_PROVIDER = 1
EVENT_CONTROL_CODE_CAPTURE_STATE = 2
MAX_NAME_CHARS = 1024

# Запасной вариант, если `logman query providers <имя>` не ответил (GUID из манифестов Windows).
KNOWN_PROVIDER_GUIDS = {
    "microsoft-windows-dxgkrnl": "802ec45a-1e99-4b83-9920-87c98277ba9d",
    "microsoft-windows-dxgi": "ca11c036-0102-4a2d-a6ad-f03cfed5d3c9",
    "microsoft-windows-d3d9": "783aca0a-790e-4d7f-8451-aa850511c6b9",
    "microsoft-windows-dwm-core": "9e9bba3c-2e38-40cb-99f4-9e8281425164",
    "microsoft-windows-win32k": "8c416c79-d49b-4f01-a467-e56d3aa8234c",
}


class GUID(ctypes.Structure):
    _fields_ = [("Data1", c_uint32), ("Data2", c_uint16), ("Data3", c_uint16), ("Data4", c_uint8 * 8)]

    @classmethod
    def from_str(cls, s: str) -> "GUID":
        return cls.from_buffer_copy(uuid.UUID(s).bytes_le)


class WNODE_HEADER(ctypes.Structure):
    _fields_ = [("BufferSize", c_uint32), ("ProviderId", c_uint32), ("HistoricalContext", c_uint64),
                ("TimeStamp", c_int64), ("Guid", GUID), ("ClientContext", c_uint32), ("Flags", c_uint32)]


class EVENT_TRACE_PROPERTIES(ctypes.Structure):
    _fields_ = [("Wnode", WNODE_HEADER), ("BufferSize", c_uint32), ("MinimumBuffers", c_uint32),
                ("MaximumBuffers", c_uint32), ("MaximumFileSize", c_uint32), ("LogFileMode", c_uint32),
                ("FlushTimer", c_uint32), ("EnableFlags", c_uint32), ("AgeLimit", ctypes.c_int32),
                ("NumberOfBuffers", c_uint32), ("FreeBuffers", c_uint32), ("EventsLost", c_uint32),
                ("BuffersWritten", c_uint32), ("LogBuffersLost", c_uint32), ("RealTimeBuffersLost", c_uint32),
                ("LoggerThreadId", c_void_p), ("LogFileNameOffset", c_uint32), ("LoggerNameOffset", c_uint32)]


class _PropsBuffer(ctypes.Structure):
    """EVENT_TRACE_PROPERTIES + место под имя сессии и путь к файлу (так требует API)."""
    _fields_ = [("props", EVENT_TRACE_PROPERTIES), ("logger_name", ctypes.c_wchar * MAX_NAME_CHARS),
                ("log_file", ctypes.c_wchar * MAX_NAME_CHARS)]


def _props(log_file: str | None = None, buffer_kb=1024, min_buf=64, max_buf=512, max_file_mb=2048) -> _PropsBuffer:
    buf = _PropsBuffer()
    p = buf.props
    p.Wnode.BufferSize = ctypes.sizeof(_PropsBuffer)
    p.Wnode.Flags = WNODE_FLAG_TRACED_GUID
    p.Wnode.ClientContext = 1                 # QPC, как у xperf/PresentMon
    p.BufferSize, p.MinimumBuffers, p.MaximumBuffers = buffer_kb, min_buf, max_buf
    p.MaximumFileSize = max_file_mb
    p.LogFileMode = EVENT_TRACE_FILE_MODE_SEQUENTIAL
    p.LoggerNameOffset = _PropsBuffer.logger_name.offset
    p.LogFileNameOffset = _PropsBuffer.log_file.offset if log_file else 0
    if log_file:
        buf.log_file = log_file
    return buf


def _advapi():
    a = ctypes.WinDLL("advapi32")
    a.StartTraceW.argtypes = [ctypes.POINTER(c_uint64), c_wchar_p, ctypes.POINTER(_PropsBuffer)]
    a.StartTraceW.restype = c_uint32
    a.ControlTraceW.argtypes = [c_uint64, c_wchar_p, ctypes.POINTER(_PropsBuffer), c_uint32]
    a.ControlTraceW.restype = c_uint32
    a.EnableTraceEx2.argtypes = [c_uint64, ctypes.POINTER(GUID), c_uint32, c_uint8, c_uint64, c_uint64,
                                 c_uint32, c_void_p]
    a.EnableTraceEx2.restype = c_uint32
    return a


def resolve_provider_guid(name: str) -> str | None:
    """GUID провайдера по имени: `logman query providers <имя>` (до запуска игры), иначе встроенная таблица."""
    if re.fullmatch(r"\{?[0-9a-fA-F-]{36}\}?", name):
        return name.strip("{}")
    try:
        r = subprocess.run(["logman", "query", "providers", name], capture_output=True, text=True,
                           encoding="oem", errors="replace", timeout=15,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        m = re.search(r"\{([0-9a-fA-F-]{36})\}", r.stdout or "")
        if m:
            return m.group(1)
    except (OSError, subprocess.TimeoutExpired, LookupError):
        pass
    return KNOWN_PROVIDER_GUIDS.get(name.lower())


class EtwError(RuntimeError):
    def __init__(self, what: str, code: int):
        super().__init__(f"{what}: код {code}" + (" (отказано в доступе)" if code == ERROR_ACCESS_DENIED else ""))
        self.code = code


class FileSession:
    """Файловая ETW-сессия, которой владеет этот процесс (хэндл нужен для EnableTraceEx2)."""

    def __init__(self, name: str, log_file: Path, **buffers):
        self.name, self.log_file, self.buffers = name, Path(log_file), buffers
        self.handle = c_uint64(0)
        self._api = None

    def start(self) -> None:
        self._api = _advapi()
        buf = _props(str(self.log_file), **self.buffers)
        rc = self._api.StartTraceW(ctypes.byref(self.handle), self.name, ctypes.byref(buf))
        if rc == ERROR_ALREADY_EXISTS:            # осталась от упавшего запуска: гасим по имени и пробуем снова
            self._api.ControlTraceW(0, self.name, ctypes.byref(_props()), EVENT_TRACE_CONTROL_STOP)
            buf = _props(str(self.log_file), **self.buffers)
            rc = self._api.StartTraceW(ctypes.byref(self.handle), self.name, ctypes.byref(buf))
        if rc != 0:
            raise EtwError(f"StartTrace {self.name}", rc)

    def enable(self, guid: str, level: int, keywords: int) -> None:
        rc = self._api.EnableTraceEx2(self.handle.value, ctypes.byref(GUID.from_str(guid)),
                                      EVENT_CONTROL_CODE_ENABLE_PROVIDER, level, keywords, 0, 0, None)
        if rc != 0:
            raise EtwError(f"EnableTraceEx2 {guid}", rc)

    def disable(self, guid: str) -> int:
        """Выключить провайдер. Работает и там, где античит запрещает останавливать сессию: файл перестаёт расти."""
        return self._api.EnableTraceEx2(self.handle.value, ctypes.byref(GUID.from_str(guid)),
                                        EVENT_CONTROL_CODE_DISABLE_PROVIDER, 0, 0, 0, 0, None)

    def capture_state(self, guid: str, level: int = 5, keywords: int = 0xFFFFFFFFFFFFFFFF) -> int:
        """Rundown провайдера (устройства, контексты DxgKrnl). Ошибка не критична: возвращаем код."""
        return self._api.EnableTraceEx2(self.handle.value, ctypes.byref(GUID.from_str(guid)),
                                        EVENT_CONTROL_CODE_CAPTURE_STATE, level, keywords, 0, 0, None)

    def stop(self) -> tuple[int, int]:
        """(код, потеряно событий)."""
        buf = _props()
        rc = self._api.ControlTraceW(self.handle.value, None, ctypes.byref(buf), EVENT_TRACE_CONTROL_STOP)
        if rc != 0:     # хэндл не принят: пробуем по имени
            buf = _props()
            rc = self._api.ControlTraceW(0, self.name, ctypes.byref(buf), EVENT_TRACE_CONTROL_STOP)
        return rc, buf.props.EventsLost
