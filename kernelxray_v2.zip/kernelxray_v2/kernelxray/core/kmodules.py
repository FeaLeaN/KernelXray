"""Список загруженных модулей ядра с адресами: имена драйверов для DPC/ISR без rundown в трассе.

Зачем. Имя драйвера у DPC/ISR xperf берёт из списка загруженных образов, который NT Kernel Logger пишет
только в начале сессии и при её остановке. В режиме --arm логгер пишет в кольцевой файл с момента запуска
KernelXray: если до F9 прошло несколько минут, кольцо проворачивается и начало трассы со списком
затирается. А остановить логгер под античитом не дают, поэтому списка в конце тоже нет. Тогда каждый
DPC/ISR в трассе — просто адрес, и xperf пишет «Unknown».

Здесь тот же список снимается напрямую у ядра (NtQuerySystemInformation, SystemModuleInformation):
до запуска игры и сразу после окна захвата. Адрес процедуры DPC/ISR из дампа xperf попадает в диапазон
одного из модулей — это и есть драйвер. Сессии ETW тут не участвуют, так что античит этому не мешает.

С Windows 11 24H2 ядро отдаёт реальные адреса модулей только процессу с включённой SeDebugPrivilege
(у администратора она есть, но выключена), поэтому перед запросом она включается.
"""
from __future__ import annotations

import bisect
import ctypes
import sys
from ctypes import c_char, c_uint16, c_uint32, c_void_p

SYSTEM_MODULE_INFORMATION = 11
STATUS_INFO_LENGTH_MISMATCH = 0xC0000004
SE_DEBUG_PRIVILEGE = 20


class _ModuleInfo(ctypes.Structure):
    """RTL_PROCESS_MODULE_INFORMATION."""
    _fields_ = [("Section", c_void_p), ("MappedBase", c_void_p), ("ImageBase", c_void_p),
                ("ImageSize", c_uint32), ("Flags", c_uint32), ("LoadOrderIndex", c_uint16),
                ("InitOrderIndex", c_uint16), ("LoadCount", c_uint16), ("OffsetToFileName", c_uint16),
                ("FullPathName", c_char * 256)]


def _ntdll():
    nt = ctypes.WinDLL("ntdll")
    nt.NtQuerySystemInformation.argtypes = [ctypes.c_ulong, c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
    nt.NtQuerySystemInformation.restype = ctypes.c_long
    nt.RtlAdjustPrivilege.argtypes = [ctypes.c_ulong, ctypes.c_ubyte, ctypes.c_ubyte, ctypes.POINTER(ctypes.c_ubyte)]
    nt.RtlAdjustPrivilege.restype = ctypes.c_long
    return nt


def enable_debug_privilege() -> bool:
    """SeDebugPrivilege для всего процесса. False — не вышло (не администратор)."""
    if sys.platform != "win32":
        return False
    was = ctypes.c_ubyte(0)
    return _ntdll().RtlAdjustPrivilege(SE_DEBUG_PRIVILEGE, 1, 0, ctypes.byref(was)) == 0


def _file_name(m: _ModuleInfo) -> str:
    full = bytes(m.FullPathName).split(b"\0", 1)[0]
    raw = full[m.OffsetToFileName:] if m.OffsetToFileName < len(full) else full
    for enc in ("mbcs", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("latin-1", errors="replace")


def snapshot() -> list[tuple[int, int, str]]:
    """[(база, размер, имя файла)] всех загруженных модулей ядра. Пустой список, если адреса скрыты."""
    if sys.platform != "win32":
        return []
    enable_debug_privilege()
    nt = _ntdll()
    size = 1 << 16
    for _ in range(8):
        buf = ctypes.create_string_buffer(size)
        need = ctypes.c_ulong(0)
        st = nt.NtQuerySystemInformation(SYSTEM_MODULE_INFORMATION, buf, size, ctypes.byref(need))
        if (st & 0xFFFFFFFF) == STATUS_INFO_LENGTH_MISMATCH:
            size = max(size * 2, need.value + 4096)
            continue
        if st != 0:
            raise OSError(f"NtQuerySystemInformation(SystemModuleInformation): 0x{st & 0xFFFFFFFF:08X}")
        break
    else:
        raise OSError("NtQuerySystemInformation: буфер так и не подошёл по размеру")
    count = c_uint32.from_buffer(buf).value

    class _Modules(ctypes.Structure):
        _fields_ = [("NumberOfModules", c_uint32), ("Modules", _ModuleInfo * count)]

    mods = _Modules.from_buffer(buf)
    out = []
    for m in mods.Modules:
        base = m.ImageBase or 0
        if base and m.ImageSize:
            out.append((int(base), int(m.ImageSize), _file_name(m)))
    return out


class ModuleMap:
    """Адрес -> имя модуля. Снимки можно добавлять: модули, загруженные между ними, тоже найдутся."""

    def __init__(self, modules: list[tuple[int, int, str]] | None = None) -> None:
        self._items: dict[tuple[int, int], str] = {}
        self._bases: list[int] = []
        self._rows: list[tuple[int, int, str]] = []
        if modules:
            self.add(modules)

    def add(self, modules: list[tuple[int, int, str]]) -> None:
        for base, size, name in modules:
            if base and size and name:
                self._items[(base, size)] = name
        self._rows = sorted((b, b + s, n) for (b, s), n in self._items.items())
        self._bases = [r[0] for r in self._rows]

    def __len__(self) -> int:
        return len(self._rows)

    def lookup(self, addr: int | None) -> str | None:
        if not addr or not self._rows:
            return None
        i = bisect.bisect_right(self._bases, addr) - 1
        # Снимки до и после окна могут дать модуль с тем же именем по другому адресу (перезагрузка драйвера):
        # проверяем несколько ближайших снизу, а не только один.
        for j in range(i, max(-1, i - 4), -1):
            lo, hi, name = self._rows[j]
            if lo <= addr < hi:
                return name
        return None


def parse_address(text: str | None) -> int | None:
    """'0xfffff80212345678' -> int; всё остальное -> None."""
    s = (text or "").strip().strip('"')
    if not s.lower().startswith("0x"):
        return None
    try:
        v = int(s, 16)
    except ValueError:
        return None
    return v or None
