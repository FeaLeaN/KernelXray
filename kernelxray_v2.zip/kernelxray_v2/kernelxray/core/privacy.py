"""Обезличивание отчёта для отправки другим: имя пользователя и компьютера заменяются метками."""
from __future__ import annotations

import os
import re
from pathlib import Path


def _secrets() -> list[tuple[str, str]]:
    pairs = []
    profile = os.environ.get("USERPROFILE")
    if profile:
        pairs.append((profile, r"C:\Users\<user>"))
    for var, label in (("USERNAME", "<user>"), ("COMPUTERNAME", "<pc>"), ("USERDOMAIN", "<domain>")):
        v = os.environ.get(var)
        if v and len(v) >= 3:             # слишком короткие имена заменять опасно: заденут обычный текст
            pairs.append((v, label))
    return pairs


def anonymize_text(text: str, pairs: list[tuple[str, str]] | None = None) -> str:
    for value, label in pairs if pairs is not None else _secrets():
        text = re.sub(re.escape(value), lambda _m, lab=label: lab, text, flags=re.I)
        # В JSON обратные слеши экранированы: C:\\Users\\name
        esc = value.replace("\\", "\\\\")
        if esc != value:
            text = re.sub(re.escape(esc), lambda _m, lab=label: lab.replace("\\", "\\\\"), text, flags=re.I)
    return text


def anonymize_files(paths: list[Path]) -> None:
    pairs = _secrets()
    for p in paths:
        if p.exists():
            p.write_text(anonymize_text(p.read_text(encoding="utf-8", errors="replace"), pairs), encoding="utf-8")
