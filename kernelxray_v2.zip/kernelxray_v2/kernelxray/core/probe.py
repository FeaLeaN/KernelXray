from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from typing import Any, Callable

from .context import SessionContext


@dataclass
class ProbeResult:
    probe: str
    success: bool
    error: str | None
    duration_ms: float
    raw_metrics_json: dict

    def to_dict(self) -> dict:
        return asdict(self)


class ProbeUnavailable(RuntimeError):
    """Проба не может работать на этой системе (нет утилиты, нет модуля и т.п.)."""


class SnapshotProbe(ABC):
    """Быстрая проба: читает текущее состояние системы (реестр, WMI, API), без окна захвата."""

    name: str = "UNNAMED"
    timeout_s: float = 5.0

    @abstractmethod
    def collect(self, ctx: SessionContext) -> dict: ...


class CaptureProbe(ABC):
    """Проба с окном захвата: prepare() -> start() -> [окно] -> stop() -> analyze()."""

    name: str = "UNNAMED"
    analyze_timeout_s: float = 600.0
    armable: bool = False       # умеет создать свою ETW-сессию заранее (режим --arm)

    def arm(self, ctx: SessionContext) -> None:
        """Режим --arm: создать ETW-сессию до запуска игры (после её старта античит может это запретить).
        Вызывается после prepare(); start() потом только включает запись."""
        raise NotImplementedError

    def preflight(self, ctx: SessionContext) -> None:
        """Необязательная быстрая проверка до обратного отсчёта. Только предупреждает, захват не отменяет."""

    def prepare(self, ctx: SessionContext) -> None:
        """Проверки до старта. Бросает ProbeUnavailable, если работать нельзя."""

    @abstractmethod
    def start(self, ctx: SessionContext) -> None: ...

    @abstractmethod
    def stop(self, ctx: SessionContext) -> None: ...

    @abstractmethod
    def analyze(self, ctx: SessionContext) -> dict: ...


def run_with_timeout(fn: Callable[[], Any], timeout_s: float) -> Any:
    """Запускает fn в daemon-потоке. Зависший поток не убить, но и ждать его мы не будем."""
    box: dict[str, Any] = {}

    def target() -> None:
        try:
            box["value"] = fn()
        except BaseException as exc:  # noqa: BLE001 - пробрасываем ниже как есть
            box["error"] = exc

    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(timeout_s)
    if t.is_alive():
        raise TimeoutError(f"Probe exceeded {timeout_s:.1f}s threshold")
    if "error" in box:
        raise box["error"]
    return box.get("value")
