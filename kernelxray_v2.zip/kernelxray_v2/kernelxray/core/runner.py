from __future__ import annotations

import sys
import time
from time import perf_counter

from .console import ConsoleKeys
from .context import SessionContext
from .tools import beep
from .probe import CaptureProbe, ProbeResult, SnapshotProbe, run_with_timeout
from .win import jsonable


ARM_KEY = 0x78      # VK_F9: клавиша запуска захвата в режиме --arm
ARM_KEY_NAME = "F9"
# --arm: пробы останавливаются через STOP_GUARD_S после конца окна. Остановка (слияние .etl, rundown
# видеодрайвера) может подтормаживать игру; окно захвата от этого отделено, лишнее потом отрезается.
STOP_GUARD_S = 3.0


def _ms(t0: float) -> float:
    return round((perf_counter() - t0) * 1000, 4)


def _err(exc: BaseException) -> str:
    if isinstance(exc, TimeoutError):
        return f"TIMEOUT: {exc}"
    return f"{type(exc).__name__}: {exc}"


class Runner:
    def __init__(self, ctx: SessionContext, snapshots: list[SnapshotProbe], captures: list[CaptureProbe]):
        self.ctx = ctx
        self.snapshots = snapshots
        self.captures = captures

    def run(self) -> list[ProbeResult]:
        results = [self._run_snapshot(p) for p in self.snapshots]
        results += self._run_captures()
        return results

    # --- snapshot ---------------------------------------------------------
    def _run_snapshot(self, p: SnapshotProbe) -> ProbeResult:
        t0 = perf_counter()
        try:
            data = run_with_timeout(lambda: p.collect(self.ctx), p.timeout_s)
            return ProbeResult(p.name, True, None, _ms(t0), jsonable(data or {}))
        except Exception as exc:
            self.ctx.log.warning("%s failed: %s", p.name, _err(exc))
            return ProbeResult(p.name, False, _err(exc), _ms(t0), {})

    # --- capture ----------------------------------------------------------
    def _run_captures(self) -> list[ProbeResult]:
        ctx, log = self.ctx, self.ctx.log
        if not self.captures:
            return []
        # Быстрые проверки до отсчёта (например, пробный запуск PresentMon): о проблеме лучше узнать сразу
        for p in self.captures:
            try:
                p.preflight(ctx)
            except Exception as exc:      # предпроверка только предупреждает, захват не отменяет
                log.warning("%s preflight: %s", p.name, _err(exc))
        failed: dict[str, ProbeResult] = {}
        armed: list[CaptureProbe] = []
        if ctx.arm:
            # --arm: сессии ETW создаются сейчас, до запуска игры: после старта античит может это запретить
            for p in self.captures:
                if not p.armable:
                    continue
                t0 = perf_counter()
                try:
                    p.prepare(ctx)
                    p.arm(ctx)
                    armed.append(p)
                    log.info("%s armed", p.name)
                except Exception as exc:
                    log.warning("%s not armed: %s", p.name, _err(exc))
                    failed[p.name] = ProbeResult(p.name, False, _err(exc), _ms(t0), {})
            if not self._wait_trigger():
                log.info("capture cancelled while armed")
                for p in reversed(armed):
                    try:
                        p.stop(ctx)
                    except Exception as exc:
                        log.error("%s stop after cancel failed: %s", p.name, _err(exc))
                return [ProbeResult(p.name, False, "отменено до начала захвата", 0.0, {}) for p in self.captures]
        elif not self._countdown(ctx.start_delay_s):
            log.info("capture cancelled during countdown")
            return [ProbeResult(p.name, False, "отменено до начала захвата (Ctrl+C)", 0.0, {}) for p in self.captures]
        started: list[CaptureProbe] = []
        # Время пробы в журнале = её собственный запуск + окно захвата + её остановка + её анализ.
        # Остановка и анализ соседних проб сюда не входят (раньше «время» у всех было ~35 с).
        cost: dict[str, float] = {}
        t_started: dict[str, float] = {}

        for p in self.captures:
            if p.name in failed:
                continue
            t0 = perf_counter()
            try:
                if p not in armed:
                    p.prepare(ctx)
                p.start(ctx)
                cost[p.name] = perf_counter() - t0
                t_started[p.name] = perf_counter()
                started.append(p)
                log.info("%s started", p.name)
            except Exception as exc:
                log.warning("%s not started: %s", p.name, _err(exc))
                failed[p.name] = ProbeResult(p.name, False, _err(exc), _ms(t0), {})

        t_window_end = perf_counter()
        try:
            if started:
                if ctx.start_delay_s <= 0 and not ctx.arm:
                    beep(1200)              # без отсчёта сигналим прямо на старте захвата
                t_win = time.monotonic()
                ctx.shared["window_mono"] = (t_win, t_win + ctx.duration_s)
                log.info("окно захвата началось, длительность %s с%s", ctx.duration_s,
                         f", остановка проб через {STOP_GUARD_S:.0f} с после конца окна" if ctx.arm else "")
                self._wait(ctx.duration_s + (STOP_GUARD_S if ctx.arm else 0))
        finally:
            t_window_end = perf_counter()
            log.info("окно захвата закончилось, останавливаю пробы")
            # Останавливаем всегда, даже при Ctrl+C: иначе kernel-сессия ETW останется висеть.
            for p in reversed(started):
                t1 = perf_counter()
                try:
                    p.stop(ctx)
                    log.info("%s stopped", p.name)
                except Exception as exc:
                    log.error("%s stop failed: %s", p.name, _err(exc))
                    failed[p.name] = ProbeResult(p.name, False, _err(exc), self._own_ms(p.name, cost, t_started,
                                                                                         t_window_end, t1), {})
                cost[p.name] += perf_counter() - t1

        results = list(failed.values())
        for p in started:
            if p.name in failed:
                continue
            t1 = perf_counter()
            try:
                data = run_with_timeout(lambda p=p: p.analyze(ctx), p.analyze_timeout_s)
                cost[p.name] += perf_counter() - t1
                results.append(ProbeResult(p.name, True, None, self._own_ms(p.name, cost, t_started, t_window_end),
                                           jsonable(data or {})))
            except Exception as exc:
                cost[p.name] += perf_counter() - t1
                log.error("%s analyze failed: %s", p.name, _err(exc))
                results.append(ProbeResult(p.name, False, _err(exc),
                                           self._own_ms(p.name, cost, t_started, t_window_end), {}))
        return results

    @staticmethod
    def _own_ms(name: str, cost: dict, t_started: dict, t_window_end: float, t_now: float | None = None) -> float:
        own = cost.get(name, 0.0) + max(0.0, t_window_end - t_started.get(name, t_window_end))
        if t_now is not None:
            own += perf_counter() - t_now
        return round(own * 1000, 4)

    def _countdown(self, seconds: int) -> bool:
        """Пауза перед захватом, чтобы успеть переключиться в игру. False, если нажали Ctrl+C."""
        if seconds <= 0:
            return True
        self.ctx.log.info("countdown %s s before capture", seconds)
        end = time.monotonic() + seconds
        beeped = False
        try:
            while (left := end - time.monotonic()) > 0:
                sys.stdout.write(f"\r  Разверни игру: захват начнётся через {left:4.1f} с ")
                sys.stdout.flush()
                if not beeped and left <= 1.0:
                    beep(1200)              # последняя секунда отсчёта: слышно из игры, что сейчас начнётся
                    beeped = True
                    continue
                time.sleep(min(0.2, left))
            sys.stdout.write("\r" + " " * 60 + "\r")
            return True
        except KeyboardInterrupt:
            print("\n  Отменено до начала захвата.")
            return False

    def _wait_trigger(self, timeout_s: float = 1800.0) -> bool:
        """Режим --arm: ждём F9 (работает и из игры) или Enter в этом окне. False — отмена или таймаут."""
        print("\n  Сессии ETW созданы. Теперь запускай игру и заходи в бой.")
        print(f"  В бою нажми {ARM_KEY_NAME} (или Enter в этом окне) — начнётся захват на {self.ctx.duration_s} с. "
              f"Отмена: Ctrl+C в этом окне.", flush=True)
        self.ctx.log.info("armed: waiting for %s / Enter (max %.0f s)", ARM_KEY_NAME, timeout_s)
        try:
            import ctypes
            import msvcrt
            key_state = ctypes.windll.user32.GetAsyncKeyState
        except (ImportError, AttributeError, OSError):
            try:
                input("  [Enter] начать захват: ")
                return True
            except (EOFError, KeyboardInterrupt):
                return False
        key_state(ARM_KEY)                  # сбросить «нажата с прошлого вызова»
        # Enter читаем прямо из буфера консоли (см. core/console.py), msvcrt — запасной вариант
        con = ConsoleKeys.open()
        if con:
            con.flush()
        else:
            while msvcrt.kbhit():
                msvcrt.getwch()
        end = time.monotonic() + timeout_s
        how = None
        try:
            while time.monotonic() < end:
                if key_state(ARM_KEY) & 0x8000:
                    how = ARM_KEY_NAME
                    break
                if con:
                    try:
                        if con.poll(50) == "enter":
                            how = "Enter"
                            break
                        continue
                    except OSError:
                        con.close()
                        con = None
                if msvcrt.kbhit() and msvcrt.getwch() == "\r":
                    how = "Enter"
                    break
                time.sleep(0.05)
            else:
                print("  Время ожидания вышло, захват отменён.")
                return False
        except KeyboardInterrupt:
            print("\n  Отменено.")
            return False
        finally:
            if con:
                con.flush()                  # нажатие F9/Enter не должно остаться в буфере до конца прогона
                con.close()
        self.ctx.log.info("armed: trigger received (%s)", how)
        beep(1200)
        return True

    def _wait(self, seconds: int) -> None:
        end = time.monotonic() + seconds
        try:
            while (left := end - time.monotonic()) > 0:
                sys.stdout.write(f"\r  Захват... осталось {left:5.1f} с ")
                sys.stdout.flush()
                time.sleep(min(0.5, left))
            sys.stdout.write("\r" + " " * 40 + "\r")
        except KeyboardInterrupt:
            self.ctx.interrupted.set()
            print("\n  Прервано: останавливаю сбор и анализирую то, что успели записать.")
