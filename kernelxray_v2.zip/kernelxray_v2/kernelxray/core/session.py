from __future__ import annotations

import ctypes
import os
import sys
from time import perf_counter


def _process_cycles() -> int | None:
    if sys.platform != "win32":
        return None
    from ctypes import wintypes

    k32 = ctypes.windll.kernel32
    # Без явных типов ctypes передаст псевдо-хэндл -1 как 32-битный int, и на x64 вызов не сработает.
    k32.GetCurrentProcess.restype = wintypes.HANDLE
    k32.QueryProcessCycleTime.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_ulonglong)]
    k32.QueryProcessCycleTime.restype = wintypes.BOOL
    cycles = ctypes.c_ulonglong(0)
    if k32.QueryProcessCycleTime(k32.GetCurrentProcess(), ctypes.byref(cycles)):
        return cycles.value
    return None


class OverheadMeter:
    """Сколько ресурсов съел сам KernelXray (без дочерних xperf/PresentMon)."""

    def __enter__(self) -> "OverheadMeter":
        self._t0 = perf_counter()
        self._cpu0 = os.times()
        self._cyc0 = _process_cycles()
        return self

    def __exit__(self, *exc) -> None:
        self._t1 = perf_counter()
        self._cpu1 = os.times()
        self._cyc1 = _process_cycles()

    def result(self) -> dict:
        cycles = None
        if self._cyc0 is not None and self._cyc1 is not None:
            cycles = self._cyc1 - self._cyc0
        return {
            "cycles": cycles,
            "kernel_ms": round((self._cpu1.system - self._cpu0.system) * 1000, 3),
            "user_ms": round((self._cpu1.user - self._cpu0.user) * 1000, 3),
            "total_duration_ms": round((self._t1 - self._t0) * 1000, 3),
        }
