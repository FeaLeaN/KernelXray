from __future__ import annotations

import ctypes
import re
import shutil
import subprocess
import sys
from pathlib import Path

WPT_DIRS = [
    Path(r"C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit"),
    Path(r"C:\Program Files\Windows Kits\10\Windows Performance Toolkit"),
]

_CONSOLE_ENCODING = "oem" if sys.platform == "win32" else "utf-8"


def app_dir() -> Path:
    """Папка рядом с exe (Nuitka/PyInstaller) или корень проекта при запуске из исходников."""
    frozen = getattr(sys, "frozen", False) or "__compiled__" in globals()
    if frozen:
        return Path(sys.argv[0]).resolve().parent
    return Path(__file__).resolve().parents[2]


def find_tool(patterns: list[str], extra_dirs: list[Path] | None = None) -> Path | None:
    """Ищет утилиту: ./tools рядом с программой -> PATH -> extra_dirs. Поддерживает glob."""
    tools = app_dir() / "tools"
    for pat in patterns:
        hits = sorted(tools.glob(pat), reverse=True)  # самая свежая версия по имени
        if hits:
            return hits[0]
    for pat in patterns:
        if "*" not in pat and (found := shutil.which(pat)):
            return Path(found)
    for d in extra_dirs or []:
        for pat in patterns:
            hits = sorted(d.glob(pat), reverse=True)
            if hits:
                return hits[0]
    return None


def run_tool(cmd: list, timeout: float, check: bool = True) -> subprocess.CompletedProcess:
    r = subprocess.run(
        [str(c) for c in cmd],
        capture_output=True,
        text=True,
        encoding=_CONSOLE_ENCODING,
        errors="replace",
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if check and r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip()[-600:]
        raise RuntimeError(f"{Path(str(cmd[0])).name} exit {r.returncode}: {tail}")
    return r


# ETW-сессии, которые могли остаться от прошлого запуска (падение, закрытое окно, чужой профайлер).
# Пока они висят, xperf -on и PresentMon не могут создать свои сессии.
# Имена старых версий оставлены явно; всё, что начинается с OWN_SESSION_PREFIX, находится через logman query.
STALE_ETW_SESSIONS = ["NT Kernel Logger", "KernelXray_PresentMon", "KernelXray_PMCheck"]
OWN_SESSION_PREFIX = "KernelXray_"
ETW_SESSION_LIMIT = 64          # столько ETW-сессий Windows держит одновременно
KERNEL_LOGGER = "NT Kernel Logger"
# Программы, которые сами держат NT Kernel Logger. Если одна из них запущена, сессия, скорее всего, её.
KERNEL_LOGGER_USERS = {
    "latmon.exe": "LatencyMon", "latencymon.exe": "LatencyMon",
    "procmon.exe": "Process Monitor", "procmon64.exe": "Process Monitor",
    "wpr.exe": "Windows Performance Recorder", "wprui.exe": "Windows Performance Recorder",
    "perfview.exe": "PerfView", "perfview64.exe": "PerfView",
    "processhacker.exe": "Process Hacker", "systeminformer.exe": "System Informer",
    "xperf.exe": "xperf (другой экземпляр)",
}


# Античиты, после запуска которых новые ETW-сессии не создаются (StartTrace -> ERROR_ACCESS_DENIED),
# хотя включить провайдеры в уже созданной сессии можно (github.com/GameTechDev/PresentMon/issues/573).
ETW_BLOCKING_ANTICHEATS = {
    "eaanticheat.gameservice.exe": "EA AntiCheat (Javelin)",
    "bf6.exe": "Battlefield 6 (EA AntiCheat)",
}


def blocking_anticheat_running() -> str | None:
    """Название запущенной игры/античита, при котором новые ETW-сессии не создаются. None — всё чисто."""
    try:
        from .win import process_names, processes
        processes.cache_clear()             # нужен текущий список, а не кэшированный снимок
        names = process_names()
        processes.cache_clear()             # пробе PROCESSES — свой, свежий снимок
    except Exception:
        return None
    return next((title for exe, title in ETW_BLOCKING_ANTICHEATS.items() if exe in names), None)


def etw_block_hint() -> str | None:
    """Если запущен античит, который запрещает создавать ETW-сессии, — готовая подсказка, что делать."""
    try:
        from .win import process_names
        names = process_names()
    except Exception:
        return None
    found = [title for exe, title in ETW_BLOCKING_ANTICHEATS.items() if exe in names]
    if not found:
        return None
    return (f"{found[0]} не даёт создавать ETW-сессии, пока игра запущена "
            f"(github.com/GameTechDev/PresentMon/issues/573). Закрой игру полностью и запусти KernelXray "
            f"ДО неё: сессии создадутся заранее, а захват включится по F9 уже в бою.")


def etw_session_running(name: str) -> bool:
    try:
        return run_tool(["logman", "query", name, "-ets"], timeout=15, check=False).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def kernel_logger_owner() -> tuple[bool, str | None]:
    """(занят ли NT Kernel Logger, чья это вероятно сессия). None = владельца не видно: скорее всего,
    осталась от прошлого запуска KernelXray."""
    if not etw_session_running(KERNEL_LOGGER):
        return False, None
    try:
        from .win import process_names
        names = process_names()
    except Exception:
        names = set()
    owners = sorted({title for exe, title in KERNEL_LOGGER_USERS.items() if exe in names})
    return True, (", ".join(owners) or None)


def acquire_single_instance():
    """Именованный мьютекс: два KernelXray одновременно подерутся за единственный NT Kernel Logger.
    Возвращает хэндл (держать до выхода) или None, если уже запущен другой экземпляр."""
    if sys.platform != "win32":
        return True
    from ctypes import wintypes
    k32 = ctypes.windll.kernel32
    k32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    k32.CreateMutexW.restype = wintypes.HANDLE
    h = k32.CreateMutexW(None, False, "Global\\KernelXray_SingleInstance")
    if not h:
        return True               # мьютекс не создался: не мешаем запуску
    if k32.GetLastError() == 183:     # ERROR_ALREADY_EXISTS
        k32.CloseHandle(h)
        return None
    return h


def parse_logman_query(text: str) -> list[str]:
    """Имена сессий из вывода `logman query -ets`. Таблица идёт после строки из дефисов и кончается
    пустой строкой; колонки разделены 2+ пробелами (в имени, как у "NT Kernel Logger", бывают одиночные)."""
    names: list[str] = []
    in_table = False
    for line in text.splitlines():
        s = line.strip()
        if not in_table:
            in_table = bool(s) and set(s) <= {"-"}
            continue
        if not s:
            break
        names.append(re.split(r"\s{2,}", s)[0])
    return names


def list_etw_sessions() -> list[str] | None:
    """Все запущенные ETW-сессии. None, если logman не ответил."""
    try:
        r = run_tool(["logman", "query", "-ets"], timeout=15, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    return parse_logman_query(r.stdout or "")


def stop_etw_session(name: str) -> tuple[bool, str]:
    """logman stop <имя> -ets. (остановлена ли, вывод logman). «Не найдена» — не ошибка."""
    try:
        r = run_tool(["logman", "stop", name, "-ets"], timeout=15, check=False)
        return r.returncode == 0, (r.stdout or r.stderr or "").strip()[-300:]
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"{type(exc).__name__}: {exc}"


def stop_own_etw_sessions(exclude: set[str] | None = None) -> list[str]:
    """Останавливает все сессии KernelXray_*, кроме exclude. Возвращает имена остановленных."""
    stopped = []
    for name in list_etw_sessions() or []:
        if name.startswith(OWN_SESSION_PREFIX) and name not in (exclude or set()):
            if stop_etw_session(name)[0]:
                stopped.append(name)
    return stopped


def stop_stale_etw_sessions() -> list[tuple[str, bool, str]]:
    """logman stop <сессия> -ets для каждой сессии. Возвращает (имя, остановлена ли, вывод logman).

    Ненулевой код logman — обычно «сессия не найдена», это не ошибка: значит, чистить нечего.
    Кроме списка известных имён, гасит любые KernelXray_* (у PresentMon теперь уникальное имя на запуск).
    """
    running = list_etw_sessions() or []
    names = STALE_ETW_SESSIONS + [n for n in running
                                  if n.startswith(OWN_SESSION_PREFIX) and n not in STALE_ETW_SESSIONS]
    results = []
    for name in names:
        try:
            ok, out = stop_etw_session(name)
            results.append((name, ok, out))
        except (OSError, subprocess.TimeoutExpired) as exc:
            results.append((name, False, f"{type(exc).__name__}: {exc}"))
    if len(running) >= ETW_SESSION_LIMIT - 8:
        results.append(("(все сессии)", False, f"в системе {len(running)} ETW-сессий из {ETW_SESSION_LIMIT} "
                                               f"возможных, новые могут не создаться: {', '.join(running)}"))
    return results


def is_admin() -> bool:
    if sys.platform != "win32":
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except OSError:
        return False


def beep(freq: int, ms: int = 150) -> None:
    """Короткий звуковой сигнал (только Windows); на других системах молча ничего не делает."""
    try:
        import winsound
        winsound.Beep(freq, ms)
    except (ImportError, RuntimeError):
        pass
