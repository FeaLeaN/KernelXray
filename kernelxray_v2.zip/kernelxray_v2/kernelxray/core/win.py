"""Windows-хелперы: реестр, WMI, powercfg, bcdedit, службы, процессы, PCI-устройства.

Все импорты Windows-модулей ленивые, чтобы пакет импортировался и на других ОС (для тестов).
Тяжёлые запросы кешируются на время запуска: несколько проб используют одни и те же данные.
"""
from __future__ import annotations

import csv
import datetime as dt
import functools
import io
import re
import threading

from .tools import run_tool

HKLM, HKCU = "HKLM", "HKCU"
_lock = threading.Lock()


# --------------------------------------------------------------------------
# JSON-безопасные значения
# --------------------------------------------------------------------------
def jsonable(v):
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, bytes):
        return v.hex()
    if isinstance(v, (list, tuple)):
        return [jsonable(x) for x in v]
    if isinstance(v, dict):
        return {str(k): jsonable(x) for k, x in v.items()}
    return str(v)


# --------------------------------------------------------------------------
# Реестр
# --------------------------------------------------------------------------
def _hive(name: str):
    import winreg
    return {HKLM: winreg.HKEY_LOCAL_MACHINE, HKCU: winreg.HKEY_CURRENT_USER}[name]


def reg_get(hive: str, key: str, value: str, default=None):
    import winreg
    try:
        with winreg.OpenKey(_hive(hive), key) as k:
            return winreg.QueryValueEx(k, value)[0]
    except OSError:
        return default


def reg_values(hive: str, key: str) -> dict:
    import winreg
    out = {}
    try:
        with winreg.OpenKey(_hive(hive), key) as k:
            i = 0
            while True:
                try:
                    name, v, _ = winreg.EnumValue(k, i)
                except OSError:
                    break
                out[name] = v
                i += 1
    except OSError:
        pass
    return out


def reg_subkeys(hive: str, key: str) -> list[str]:
    import winreg
    out = []
    try:
        with winreg.OpenKey(_hive(hive), key) as k:
            i = 0
            while True:
                try:
                    out.append(winreg.EnumKey(k, i))
                except OSError:
                    break
                i += 1
    except OSError:
        pass
    return out


def as_int(v) -> int | None:
    """REG_DWORD / REG_SZ "1" / REG_BINARY -> int."""
    if v is None:
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, bytes):
        return int.from_bytes(v, "little") if v else None
    try:
        return int(str(v).strip(), 0)
    except ValueError:
        return None


# --------------------------------------------------------------------------
# WMI (через COM из pywin32, без PowerShell: быстрее в разы)
# --------------------------------------------------------------------------
def wmi(query: str, namespace: str = r"root\cimv2") -> list[dict]:
    import pythoncom
    import win32com.client

    # ВАЖНО: все COM-прокси (locator, svc, obj) должны быть освобождены ДО CoUninitialize.
    # Если объект жив на момент CoUninitialize, его Release() уедет в уже разрушенный
    # апартмент -> access violation (см. kernelxray_fault.log). Поэтому результат
    # материализуется в обычные dict, а ссылки на COM обнуляются в finally перед уходом.
    pythoncom.CoInitialize()
    locator = svc = None
    try:
        locator = win32com.client.Dispatch("WbemScripting.SWbemLocator")
        svc = locator.ConnectServer(".", namespace)
        rows: list[dict] = []
        for obj in svc.ExecQuery(query):
            rows.append({p.Name: jsonable(p.Value) for p in obj.Properties_})
            obj = None  # noqa: PLW2901 - явно роняем прокси текущей строки
        return rows
    finally:
        svc = None
        locator = None
        pythoncom.CoUninitialize()


def cim_date(s) -> dt.date | None:
    """'20240115000000.000000-000' -> date."""
    if not s:
        return None
    m = re.match(r"(\d{4})(\d{2})(\d{2})", str(s))
    return dt.date(int(m[1]), int(m[2]), int(m[3])) if m else None


def parse_us_date(s) -> dt.date | None:
    """'1-15-2024' / '01/15/2024' -> date (формат DriverDate и BIOSReleaseDate)."""
    if not s:
        return None
    m = re.match(r"(\d{1,2})[-/](\d{1,2})[-/](\d{4})", str(s))
    if not m:
        return None
    try:
        return dt.date(int(m[3]), int(m[1]), int(m[2]))
    except ValueError:
        return None


def age_days(d: dt.date | None) -> int | None:
    return (dt.date.today() - d).days if d else None


# --------------------------------------------------------------------------
# powercfg (GUID-ы вместо алиасов и имён: вывод powercfg локализован)
# --------------------------------------------------------------------------
PWR = {
    "SUB_PROCESSOR": "54533251-82be-4824-96c1-47b60b740d00",
    "CPMINCORES": "0cc5b647-c1df-4637-891a-dec35c318583",
    "PROCTHROTTLEMIN": "893dee8e-2bef-41e0-89c6-b55d0929964c",
    "PERFBOOSTMODE": "be337238-0d82-4146-a960-4f3749d470c7",
    "IDLEDISABLE": "5d76a2ca-e8c0-402f-a133-2158492d58ad",
    "SUB_USB": "2a737441-1930-4402-8d77-b2bebba308a3",
    "USBSELECTSUSPEND": "48e6b7a6-50f5-4782-a5d4-53bb8f07e226",
    "SUB_PCIEXPRESS": "501a4d13-42af-4429-9fd1-a8218c268e20",
    "ASPM": "ee12f906-d277-404b-b6da-e5fa1a576df5",
    "SUB_DISK": "0012ee47-9041-4b5d-9b77-535fba8b1442",
    "DISKIDLE": "6738e2c4-e8a5-4a42-b16a-e040e769756e",
}
KNOWN_SCHEMES = {
    "381b4222-f694-41f0-9685-ff5bb260df2e": "Balanced",
    "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c": "High performance",
    "a1841308-3541-4fab-bc81-f71556f20b4a": "Power saver",
    "e9a42b02-d5df-448d-aa00-03f14749eb61": "Ultimate Performance",
}


# Основной путь — API электропитания (powrprof.dll): не зависит от языка Windows и формата вывода
# powercfg и читает в том числе скрытые параметры (парковка ядер и т.п.). powercfg — только запасной путь.
def _guid(s: str):
    import ctypes
    import uuid

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16),
                    ("Data4", ctypes.c_ubyte * 8)]
    return GUID.from_buffer_copy(uuid.UUID(s).bytes_le)


def _guid_str(p) -> str:
    import ctypes
    import uuid
    return str(uuid.UUID(bytes_le=ctypes.string_at(p, 16)))


@functools.lru_cache(maxsize=1)
def _powrprof():
    import ctypes
    from ctypes import wintypes
    pp = ctypes.WinDLL("powrprof.dll")
    pp.PowerGetActiveScheme.argtypes = [wintypes.HKEY, ctypes.POINTER(ctypes.c_void_p)]
    pp.PowerGetActiveScheme.restype = wintypes.DWORD
    for fn in (pp.PowerReadACValueIndex, pp.PowerReadDCValueIndex):
        fn.argtypes = [wintypes.HKEY, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
        fn.restype = wintypes.DWORD
    pp.PowerReadFriendlyName.argtypes = [wintypes.HKEY, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                                         ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
    pp.PowerReadFriendlyName.restype = wintypes.DWORD
    return pp


def _active_scheme_api() -> str | None:
    import ctypes
    pp = _powrprof()
    p = ctypes.c_void_p()
    if pp.PowerGetActiveScheme(None, ctypes.byref(p)) != 0 or not p.value:
        return None
    try:
        return _guid_str(p.value)
    finally:
        ctypes.windll.kernel32.LocalFree(p)


def _power_api(sub: str, setting: str) -> tuple[int | None, int | None]:
    import ctypes
    from ctypes import wintypes
    pp = _powrprof()
    scheme = _active_scheme_api()
    if not scheme:
        return None, None
    sg, sub_g, set_g = _guid(scheme), _guid(PWR[sub]), _guid(PWR[setting])
    out = []
    for fn in (pp.PowerReadACValueIndex, pp.PowerReadDCValueIndex):
        v = wintypes.DWORD()
        rc = fn(None, ctypes.byref(sg), ctypes.byref(sub_g), ctypes.byref(set_g), ctypes.byref(v))
        out.append(v.value if rc == 0 else None)
    return out[0], out[1]


def _powercfg_ac_dc(sub: str, setting: str) -> tuple[int | None, int | None]:
    r = run_tool(["powercfg", "/query", "SCHEME_CURRENT", PWR[sub], PWR[setting]], timeout=10, check=False)
    hexes = re.findall(r":\s*0x([0-9a-fA-F]+)\s*$", r.stdout or "", re.M)
    if len(hexes) < 2:
        return None, None
    return int(hexes[-2], 16), int(hexes[-1], 16)   # последние два: текущие AC и DC


def powercfg_ac_dc(sub: str, setting: str) -> tuple[int | None, int | None]:
    """Текущие значения (AC, DC) параметра электропитания активной схемы. None = прочитать не удалось."""
    try:
        ac, dc = _power_api(sub, setting)
        if ac is not None or dc is not None:
            return ac, dc
    except (OSError, AttributeError, ValueError):
        pass
    return _powercfg_ac_dc(sub, setting)


def active_power_scheme() -> dict:
    guid = name = None
    try:
        import ctypes
        from ctypes import wintypes
        guid = _active_scheme_api()
        if guid:
            pp, g, size = _powrprof(), _guid(guid), wintypes.DWORD(0)
            pp.PowerReadFriendlyName(None, ctypes.byref(g), None, None, None, ctypes.byref(size))
            if size.value:
                buf = ctypes.create_string_buffer(size.value)
                if pp.PowerReadFriendlyName(None, ctypes.byref(g), None, None, buf, ctypes.byref(size)) == 0:
                    name = buf.raw[: size.value].decode("utf-16-le", errors="replace").rstrip("\x00") or None
    except (OSError, AttributeError, ValueError):
        guid = None
    if not guid:
        r = run_tool(["powercfg", "/getactivescheme"], timeout=10, check=False)
        m = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\s*\((.*)\)", r.stdout or "", re.I)
        if not m:
            return {"guid": None, "name": None, "known_as": None}
        guid, name = m[1], m[2].strip()
    guid = guid.lower()
    return {"guid": guid, "name": name, "known_as": KNOWN_SCHEMES.get(guid)}


# --------------------------------------------------------------------------
# bcdedit
# --------------------------------------------------------------------------
def bcd_current() -> dict:
    r = run_tool(["bcdedit", "/enum", "{current}"], timeout=10, check=False)
    out = {}
    for line in (r.stdout or "").splitlines():
        m = re.match(r"^([A-Za-z][\w]*)\s{2,}(.+?)\s*$", line)
        if m:
            out[m[1].lower()] = m[2]
    return out


# --------------------------------------------------------------------------
# Процессы и службы
# --------------------------------------------------------------------------
@functools.lru_cache(maxsize=1)
def processes() -> list[dict]:
    r = run_tool(["tasklist", "/fo", "csv", "/nh"], timeout=15, check=False)
    out = []
    for row in csv.reader(io.StringIO(r.stdout or "")):
        if len(row) >= 5:
            mem = re.sub(r"\D", "", row[4])
            out.append({"name": row[0], "pid": as_int(row[1]), "mem_kb": int(mem) if mem else None})
    return out


def process_names() -> set[str]:
    return {p["name"].lower() for p in processes()}


def pid_names_now() -> dict[int, str]:
    """PID -> имя процесса на текущий момент (processes() кэширует снимок начала запуска)."""
    r = run_tool(["tasklist", "/fo", "csv", "/nh"], timeout=15, check=False)
    out: dict[int, str] = {}
    for row in csv.reader(io.StringIO(r.stdout or "")):
        if len(row) >= 2 and (pid := as_int(row[1])) is not None:
            out[pid] = row[0]
    return out


_SVC_STATE = {1: "stopped", 2: "start_pending", 3: "stop_pending", 4: "running", 5: "continue_pending",
              6: "pause_pending", 7: "paused"}
_SVC_START = {0: "boot", 1: "system", 2: "auto", 3: "manual", 4: "disabled"}


def _enum_services(kind: str) -> dict[str, dict]:
    import win32service

    types = {"win32": win32service.SERVICE_WIN32, "driver": win32service.SERVICE_DRIVER}
    out = {}
    scm = win32service.OpenSCManager(None, None, win32service.SC_MANAGER_ENUMERATE_SERVICE)
    try:
        for name, display, status in win32service.EnumServicesStatus(
                scm, types[kind], win32service.SERVICE_STATE_ALL):
            out[name.lower()] = {"name": name, "display": display, "state": _SVC_STATE.get(status[1], status[1])}
    finally:
        win32service.CloseServiceHandle(scm)
    for key, s in out.items():
        start = as_int(reg_get(HKLM, rf"SYSTEM\CurrentControlSet\Services\{s['name']}", "Start"))
        s["start"] = _SVC_START.get(start, start)
    return out


@functools.lru_cache(maxsize=1)
def services() -> dict[str, dict]:
    """Обычные службы: name(lower) -> {name, display, state, start}."""
    return _enum_services("win32")


@functools.lru_cache(maxsize=1)
def drivers() -> dict[str, dict]:
    """Службы-драйверы (ядро): name(lower) -> {name, display, state, start}. Здесь MMCSS и драйверы античитов."""
    return _enum_services("driver")


# --------------------------------------------------------------------------
# PCI-устройства: MSI, affinity, драйвер
# --------------------------------------------------------------------------
CLASS_ROOT = r"SYSTEM\CurrentControlSet\Control\Class"
CLASS = {
    "display": "{4d36e968-e325-11ce-bfc1-08002be10318}",
    "net": "{4d36e972-e325-11ce-bfc1-08002be10318}",
    "media": "{4d36e96c-e325-11ce-bfc1-08002be10318}",
    "usb": "{36fc9e60-c465-11cf-8056-444553540000}",
    "storage": "{4d36e97b-e325-11ce-bfc1-08002be10318}",   # SCSIAdapter: сюда же NVMe
    "hdc": "{4d36e96a-e325-11ce-bfc1-08002be10318}",       # SATA/AHCI
}
_CLASS_NAME = {v: k for k, v in CLASS.items()}
_AFFINITY_POLICY = {0: "default", 1: "all_close", 2: "one_close", 3: "all", 4: "specified", 5: "spread"}


def _clean_desc(s) -> str | None:
    # '@oem12.inf,%amd744c.1%;AMD Radeon RX 7900 XTX' -> 'AMD Radeon RX 7900 XTX'
    return str(s).split(";")[-1].strip() if s else None


@functools.lru_cache(maxsize=1)
def pci_devices() -> list[dict]:
    """Только присутствующие PCI-устройства (по WMI), с настройками прерываний из реестра."""
    present = wmi("SELECT PNPDeviceID, Name, ClassGuid, Service FROM Win32_PnPEntity WHERE PNPDeviceID LIKE 'PCI%'")
    devs = []
    for p in present:
        inst = p.get("PNPDeviceID") or ""
        base = rf"SYSTEM\CurrentControlSet\Enum\{inst}"
        v = reg_values(HKLM, base)
        im = base + r"\Device Parameters\Interrupt Management"
        msi = reg_values(HKLM, im + r"\MessageSignaledInterruptProperties")
        aff = reg_values(HKLM, im + r"\Affinity Policy")
        mask = as_int(aff.get("AssignmentSetOverride"))
        ids = re.search(r"VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})", inst, re.I)
        cls = (p.get("ClassGuid") or v.get("ClassGUID") or "").lower()
        devs.append({
            "instance_id": inst,
            "name": p.get("Name") or _clean_desc(v.get("FriendlyName") or v.get("DeviceDesc")),
            "class": _CLASS_NAME.get(cls, cls),
            "service": p.get("Service") or v.get("Service"),
            "driver_key": v.get("Driver"),
            "vendor_id": ids[1].upper() if ids else None,
            "device_id": ids[2].upper() if ids else None,
            "msi_supported": as_int(msi.get("MSISupported")),
            "msi_message_limit": as_int(msi.get("MessageNumberLimit")),
            "affinity_policy": _AFFINITY_POLICY.get(as_int(aff.get("DevicePolicy")), aff.get("DevicePolicy")),
            "affinity_mask": hex(mask) if mask else None,
            "device_priority": as_int(aff.get("DevicePriority")),
        })
    return devs


def devices_of(cls: str) -> list[dict]:
    return [d for d in pci_devices() if d["class"] == cls]


def class_values(driver_key: str | None) -> dict:
    return reg_values(HKLM, rf"{CLASS_ROOT}\{driver_key}") if driver_key else {}


def driver_info(driver_key: str | None) -> dict:
    v = class_values(driver_key)
    date = parse_us_date(v.get("DriverDate"))
    return {
        "driver_desc": v.get("DriverDesc"),
        "provider": v.get("ProviderName"),
        "version": v.get("DriverVersion"),
        "date": date.isoformat() if date else None,
        "age_days": age_days(date),
    }
