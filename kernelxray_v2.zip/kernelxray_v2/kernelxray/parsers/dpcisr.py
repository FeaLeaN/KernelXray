"""Парсер текстового вывода `xperf -i trace.etl -o out.txt -a dpcisr`.

Разделы вывода (для DPC и Interrupt одинаковые):
  * таблица usec/% по каждому CPU для каждого модуля (драйвера);
  * общая гистограмма длительностей + гистограмма по каждому модулю (корзины 2^n мкс);
  * загрузка по CPU с шагом 1 с.
"""
from __future__ import annotations

import re
from pathlib import Path

_SECTION = re.compile(r"^(DPC|Interrupt) Info\s*$")
_RANGE = re.compile(r"CPU Usage from (\d+) us to (\d+) us")
_TOTAL = re.compile(r"^Total = (\d+)\s*$")
_TOTAL_MOD = re.compile(r"^Total = (\d+) for module (.+?)\s*$")
_BUCKET = re.compile(r"^Elapsed Time, >\s*(\d+) usecs AND <=\s*(\d+) usecs,\s*(\d+),")
_INTERVAL = re.compile(r"^\s*(\d+)-(\d+)\s*:,(.*)$")
_CELL = re.compile(r"^\s*(\d+)\s+([\d.]+)\s*$")

_SECTION_KEY = {"DPC": "dpc", "Interrupt": "isr"}


def _new_section() -> dict:
    return {
        "trace_duration_us": None,
        "cpu_count": 0,
        "total_count": 0,
        "histogram": [],     # [[lo_us, hi_us, count], ...]
        "modules": {},       # name -> {per_cpu_us, total_us, count, histogram}
        "timeline": [],      # [{start_ms, end_ms, per_cpu_us}]
    }


def parse_dpcisr_text(text: str) -> dict:
    out: dict[str, dict] = {}
    sec: dict | None = None
    mode: str | None = None        # "usage" | "timeline" | None
    hist: list | None = None       # куда складываем текущие корзины

    for raw in text.splitlines():
        line = raw.rstrip("\r")
        s = line.strip()

        if m := _SECTION.match(s):
            sec = out[_SECTION_KEY[m.group(1)]] = _new_section()
            mode, hist = None, None
            continue
        if sec is None:
            continue

        if m := _RANGE.search(s):
            sec["trace_duration_us"] = int(m.group(2)) - int(m.group(1))
            continue
        if "usec" in s and s.endswith("Module"):
            mode = "usage"
            continue
        if mode == "usage":
            if not s:
                mode = None
                continue
            *cells, module = [c for c in line.split(",")]
            per_cpu = []
            for c in cells:
                if cm := _CELL.match(c):
                    per_cpu.append(int(cm.group(1)))
            if per_cpu:
                name = module.strip()
                mod = sec["modules"].setdefault(name, {"per_cpu_us": [], "total_us": 0, "count": 0, "histogram": []})
                mod["per_cpu_us"] = per_cpu
                mod["total_us"] = sum(per_cpu)
                sec["cpu_count"] = max(sec["cpu_count"], len(per_cpu))
            continue

        if m := _TOTAL_MOD.match(s):
            mod = sec["modules"].setdefault(m.group(2), {"per_cpu_us": [], "total_us": 0, "count": 0, "histogram": []})
            mod["count"] = int(m.group(1))
            hist = mod["histogram"]
            continue
        if m := _TOTAL.match(s):
            sec["total_count"] = int(m.group(1))
            hist = sec["histogram"]
            continue
        if m := _BUCKET.match(s):
            if hist is not None:
                hist.append([int(m.group(1)), int(m.group(2)), int(m.group(3))])
            continue
        if s.startswith("Total,"):
            hist = None
            continue

        if s.startswith("Usage From") and "intervals" in s:
            mode = "timeline"
            continue
        if s.startswith("Distribution of number"):
            mode = None
            continue
        if mode == "timeline" and (m := _INTERVAL.match(line)):
            cells = m.group(3).split(",")
            per_cpu = [int(cm.group(1)) for c in cells if (cm := _CELL.match(c))]
            sec["timeline"].append({"start_ms": int(m.group(1)), "end_ms": int(m.group(2)), "per_cpu_us": per_cpu})

    return out


def parse_dpcisr_file(path: Path) -> dict:
    return parse_dpcisr_text(Path(path).read_text(encoding="utf-8", errors="replace"))


# --------------------------------------------------------------------------
# Сводка для отчёта
# --------------------------------------------------------------------------
def _max_bucket(hist: list) -> int | None:
    """Верхняя граница самой «длинной» непустой корзины. Точный максимум dpcisr не даёт."""
    nonzero = [hi for lo, hi, cnt in hist if cnt > 0]
    return max(nonzero) if nonzero else None


def _count_over(hist: list, threshold_us: int) -> int:
    """Сколько событий гарантированно длиннее threshold_us (корзины с нижней границей >= порога)."""
    return sum(cnt for lo, hi, cnt in hist if lo >= threshold_us)


def summarize_section(sec: dict, top_n: int = 8) -> dict:
    dur_us = sec.get("trace_duration_us") or 0
    mods = sec["modules"]
    top = sorted(mods.items(), key=lambda kv: kv[1]["total_us"], reverse=True)[:top_n]
    total_us = sum(m["total_us"] for m in mods.values())

    ncpu = sec["cpu_count"]
    per_cpu_total = [sum(m["per_cpu_us"][i] for m in mods.values() if i < len(m["per_cpu_us"])) for i in range(ncpu)]

    peak_1s = None
    for row in sec["timeline"]:
        span_us = max(1, (row["end_ms"] - row["start_ms"]) * 1000)
        for cpu, us in enumerate(row["per_cpu_us"]):
            pct = us / span_us * 100
            if peak_1s is None or pct > peak_1s["percent"]:
                peak_1s = {"cpu": cpu, "start_ms": row["start_ms"], "percent": round(pct, 2), "usec": us}

    return {
        "event_count": sec["total_count"],
        "total_time_ms": round(total_us / 1000, 3),
        "events_per_sec": round(sec["total_count"] / (dur_us / 1e6), 1) if dur_us else None,
        "max_latency_bucket_us": _max_bucket(sec["histogram"]),
        "events_over_64us": _count_over(sec["histogram"], 64),
        "events_over_256us": _count_over(sec["histogram"], 256),
        "events_over_1024us": _count_over(sec["histogram"], 1024),
        "top_drivers": [
            {
                "driver": name,
                "time_us": m["total_us"],
                "count": m["count"],
                "avg_us": round(m["total_us"] / m["count"], 2) if m["count"] else None,
                "max_latency_bucket_us": _max_bucket(m["histogram"]),
                "cpus": [i for i, us in enumerate(m["per_cpu_us"]) if us > 0],
            }
            for name, m in top
        ],
        "per_cpu_load_percent": [round(us / dur_us * 100, 3) if dur_us else None for us in per_cpu_total],
        "peak_1s_window": peak_1s,
    }


def summarize(parsed: dict) -> dict:
    out = {k: summarize_section(v) for k, v in parsed.items()}
    # Тепловая карта по ядрам: DPC+ISR вместе и кто на ядре сидит
    dpc, isr = parsed.get("dpc"), parsed.get("isr")
    secs = [s for s in (dpc, isr) if s]
    if secs:
        dur_us = secs[0].get("trace_duration_us") or 0
        ncpu = max(s["cpu_count"] for s in secs)
        heat = {}
        for cpu in range(ncpu):
            usec, drivers = 0, {}
            for s in secs:
                for name, m in s["modules"].items():
                    us = m["per_cpu_us"][cpu] if cpu < len(m["per_cpu_us"]) else 0
                    if us:
                        usec += us
                        drivers[name] = drivers.get(name, 0) + us
            if usec:
                ordered = sorted(drivers.items(), key=lambda kv: kv[1], reverse=True)
                heat[str(cpu)] = {
                    "usecs": usec,
                    "percent": round(usec / dur_us * 100, 3) if dur_us else None,
                    "drivers": [d for d, _ in ordered],
                    "driver_us": dict(ordered),          # время DPC+ISR каждого драйвера на этом ядре, мкс
                }
        out["heatmap"] = heat
        out["trace_duration_s"] = round(dur_us / 1e6, 3) if dur_us else None
    return out


def tail_gaps(parsed: dict, min_gap_s: int = 2, min_active_share: float = 0.8) -> dict[int, int]:
    """Ядра, у которых данные обрываются раньше конца трассы: {cpu: секунд без событий в конце}.

    Если логгер не остановили (античит), последний неполный буфер каждого ядра остаётся в памяти и в файл
    не попадает. Чем тише ядро, тем дольше заполняется его буфер и тем больше секунд в конце теряется.
    Признак: ядро было занято DPC/ISR почти каждую секунду, а в конце несколько секунд подряд — ноль.
    """
    rows: list[list[int]] = []
    for key in ("dpc", "isr"):
        for i, row in enumerate((parsed.get(key) or {}).get("timeline") or []):
            cells = row.get("per_cpu_us") or []
            while len(rows) <= i:
                rows.append([])
            acc = rows[i]
            if len(acc) < len(cells):
                acc.extend([0] * (len(cells) - len(acc)))
            for c, us in enumerate(cells):
                acc[c] += us or 0
    if not rows:
        return {}
    ncpu = max(len(r) for r in rows)
    gaps: dict[int, int] = {}
    for cpu in range(ncpu):
        vals = [r[cpu] if cpu < len(r) else 0 for r in rows]
        busy = [i for i, v in enumerate(vals) if v > 0]
        if not busy:
            continue
        last = busy[-1]
        trailing = len(vals) - 1 - last
        if trailing < min_gap_s or last + 1 < 3:
            continue
        if len(busy) / (last + 1) >= min_active_share:
            gaps[cpu] = trailing
    return gaps
