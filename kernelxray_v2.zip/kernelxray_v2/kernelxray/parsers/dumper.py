"""Потоковый разбор `xperf -i trace.etl -a dumper`: каждое событие DPC/ISR с точной длительностью.

Формат строк (из заголовка дампа):
  DPC,       TimeStamp, ElapsedTime, CPU, ServiceAddr, Image!Function
  DPCTmr,    TimeStamp, ElapsedTime, CPU, ServiceAddr, Image!Function
  Interrupt, TimeStamp, ElapsedTime, CPU, Vector, MessageIndex, Status, ServiceAddr, Image!Function
  CSwitch,   TimeStamp, ... , CPU (17-е поле), ...
  HardFault, TimeStamp, Process Name ( PID), ThreadID, VirtualAddress, ByteOffset, IOSize, ElapsedTime,
             FileObject, FileName
TimeStamp и ElapsedTime в микросекундах от начала трассы.

Если в трассе нет списка загруженных образов (кольцо --arm провернулось, а остановить логгер античит
не дал), xperf вместо имени драйвера пишет Unknown. Тогда имя восстанавливается по адресу процедуры
(ServiceAddr) и снимку модулей ядра (core/kmodules.py), а процесс в hard faults — по PID.

Колонки HardFault берём из заголовка дампа (BeginHeader...EndHeader), а не по жёстким индексам:
их набор отличается между версиями WPT.
"""
from __future__ import annotations

import heapq
import re
from collections import defaultdict
from typing import Callable, Iterable

from ..core.kmodules import parse_address
from .stats import percentile, r

THRESHOLDS_US = (100, 250, 500, 1000)
TOP_EVENTS = 25
BIN_US = 1000


def _exclusive_segments(events: list[tuple[int, int, str]]):
    """События одного ядра (начало, конец, модуль) -> непересекающиеся отрезки (t0, t1, модуль).

    ISR, пришедший во время DPC, входит в ElapsedTime этого DPC. Если просто сложить длительности,
    время вложенного прерывания считается дважды. Здесь каждый микросекундный участок отдаётся
    самому внутреннему активному событию (начавшемуся позже), так что сумма по ядру не превышает
    реально прошедшее время.
    """
    events.sort(key=lambda e: (e[0], -e[1]))        # при равном начале внешнее (длиннее) идёт первым
    stack: list[tuple[int, str]] = []                # (конец, модуль); вершина — самое внутреннее
    t = None
    for s, e, mod in events:
        if t is None:
            t = s
        while stack and t < s:
            top_end, top_mod = stack[-1]
            seg_end = min(top_end, s)
            if seg_end > t:
                yield t, seg_end, top_mod
                t = seg_end
            if top_end <= s:
                stack.pop()
            else:
                break
        t = max(t, s)
        stack.append((e, mod))
    while stack:
        top_end, top_mod = stack.pop()
        if t is not None and top_end > t:
            yield t, top_end, top_mod
            t = top_end


def _spread(t0: int, t1: int):
    """Отрезок [t0, t1) по миллисекундным окнам: событие на стыке делится между соседними окнами."""
    while t0 < t1:
        ms = t0 // BIN_US
        edge = min(t1, (ms + 1) * BIN_US)
        yield ms, edge - t0
        t0 = edge


def _bucket(el: int) -> tuple[int, int]:
    """Корзина длительности как у xperf -a dpcisr: (0, 1], (1, 2], (2, 4], (4, 8] ... мкс."""
    hi = 1
    while hi < el:
        hi *= 2
    return (0 if hi == 1 else hi // 2), hi


class _Acc:
    def __init__(self) -> None:
        self.durations: list[int] = []
        self.total = 0
        self.modules: dict[str, list] = defaultdict(lambda: [0, 0, 0])   # count, total, max
        # Для замены сводки xperf, если имена там не определились: время по ядрам и корзины по модулю
        self.per_cpu: dict[str, dict[int, int]] = defaultdict(lambda: defaultdict(int))
        self.hist: dict[str, dict[tuple[int, int], int]] = defaultdict(lambda: defaultdict(int))

    def add(self, module: str, el: int, cpu: int = 0) -> None:
        self.durations.append(el)
        self.total += el
        m = self.modules[module]
        m[0] += 1
        m[1] += el
        if el > m[2]:
            m[2] = el
        self.per_cpu[module][cpu] += el
        self.hist[module][_bucket(el)] += 1

    def detail(self, ncpu: int) -> dict:
        """Модули в формате разбора dpcisr (per_cpu_us, total_us, count, histogram)."""
        out = {}
        for name, (count, total, _mx) in self.modules.items():
            cpus = self.per_cpu[name]
            out[name] = {
                "per_cpu_us": [cpus.get(i, 0) for i in range(ncpu)],
                "total_us": total,
                "count": count,
                "histogram": [[lo, hi, n] for (lo, hi), n in sorted(self.hist[name].items())],
            }
        return out

    def summary(self, duration_s: float) -> dict:
        d = sorted(self.durations)
        n = len(d)
        mods = sorted(self.modules.items(), key=lambda kv: kv[1][2], reverse=True)[:12]
        return {
            "count": n,
            "per_sec": r(n / duration_s, 1) if duration_s else None,
            "total_ms": r(self.total / 1000, 3),
            "max_us": d[-1] if d else None,
            "p50_us": r(percentile(d, 50), 1),
            "p99_us": r(percentile(d, 99), 1),
            "p999_us": r(percentile(d, 99.9), 1),
            **{f"over_{t}us": sum(1 for x in d if x > t) for t in THRESHOLDS_US},
            "modules_by_max": [{"module": k, "count": c, "max_us": mx, "avg_us": r(t / c, 2), "total_ms": r(t / 1000, 3)}
                               for k, (c, t, mx) in mods],
        }


def _module(image: str) -> str:
    return image.split("!")[0].strip().strip('"') or "unknown"


def is_unknown_module(name: str | None) -> bool:
    """Модуль, который xperf не смог назвать: Unknown, пусто или голый адрес."""
    n = (name or "").strip().strip('"').strip().lower()
    return n in ("", "unknown", "n/a") or n.startswith("0x")


_PID_RE = re.compile(r"^(.*?)\s*\(\s*(-?\d+)\s*\)\s*$")
_ADDR_RE = re.compile(r"^(0x[0-9a-f]+|\d+|n/a|unknown)?$", re.I)
KERNEL_CONTEXT = "<ядро / прерывание>"     # page fault без пользовательского процесса (контекст DPC/ISR, System)
PAGEFILE_NAMES = ("pagefile.sys", "swapfile.sys")
SELF_IMAGES = {"xperf.exe"}      # xperf запускается на старте/остановке сессии, его загрузку не считаем


class _HardFaults:
    """Жёсткие ошибки страниц из ETW с привязкой к файлу: отличает чтение pagefile.sys от загрузки образов."""

    def __init__(self, exclude_pids: set[int], pid_names: dict[int, str] | None = None) -> None:
        self.exclude_pids = exclude_pids
        self.pid_names = pid_names or {}
        self.cols: dict[str, int] | None = None     # None = в заголовке нет HardFault (флаг не включали)
        self.count = self.io = self.excluded = 0
        self.good_rows = 0          # строки, где и процесс, и файл разобрались осмысленно
        self.pf_count = self.pf_io = 0
        self.files: dict[str, list] = defaultdict(lambda: [0, 0])     # count, bytes
        self.procs: dict[str, int] = defaultdict(int)

    def header(self, names: list[str]) -> None:
        low = [n.strip().lower() for n in names]

        def find(*keys):
            return next((i for i, n in enumerate(low) if any(k in n for k in keys)), None)
        self.cols = {"proc": find("process name"), "io": find("iosize"), "file": find("filename")}

    @staticmethod
    def _file(parts: list[str], idx: int | None) -> str | None:
        """Имя файла из колонки FileName.

        Путь может содержать запятые (тогда он разбит на несколько частей), а новые версии WPT дописывают
        после FileName ещё колонки (Image!Function, адреса, N/A). Поэтому берём хвост строки, срезаем с конца
        всё, что похоже на адрес или Image!Function, и склеиваем остальное.
        """
        if idx is None or idx >= len(parts):
            return None
        tail = list(parts[idx:])
        while tail and (_ADDR_RE.match(tail[-1].strip().strip('"')) or "!0x" in tail[-1].lower()):
            tail.pop()
        name = ",".join(tail).strip().strip('"').strip()
        if not name or _ADDR_RE.match(name) or "!0x" in name.lower():
            return None           # вместо файла адрес: колонки сдвинуты или у события нет файла
        return name

    def add(self, parts: list[str]) -> None:
        c = self.cols
        if c is None:
            return
        proc_raw = parts[c["proc"]].strip() if c["proc"] is not None and c["proc"] < len(parts) else ""
        m = _PID_RE.match(proc_raw)
        # Без «имя ( PID)» это не пользовательский процесс: xperf пишет туда контекст (Interrupt, DPC, System)
        name, pid = (m.group(1).strip(), int(m.group(2))) if m else (KERNEL_CONTEXT, -1)
        if m and is_unknown_module(name) and self.pid_names.get(pid):
            name = self.pid_names[pid]          # процесс без rundown в трассе: имя по снимку PID
        if pid in self.exclude_pids or name.lower() in SELF_IMAGES:
            self.excluded += 1
            return
        io = 0
        if c["io"] is not None and c["io"] < len(parts):
            try:
                io = int(parts[c["io"]].strip(), 0)     # xperf пишет размер и в hex (0x1000), и в dec
            except ValueError:
                io = 0
        file = self._file(parts, c["file"])
        if m and file:
            self.good_rows += 1
        fname = file or "unknown"
        self.count += 1
        self.io += io
        if fname.lower().endswith(PAGEFILE_NAMES):
            self.pf_count += 1
            self.pf_io += io
        f = self.files[fname]
        f[0] += 1
        f[1] += io
        self.procs[name] += 1

    def summary(self, duration_s: float) -> dict | None:
        if self.cols is None:
            return None
        per = (lambda n: r(n / duration_s, 1) if duration_s else None)
        files = sorted(self.files.items(), key=lambda kv: kv[1][0], reverse=True)[:10]
        procs = sorted(self.procs.items(), key=lambda kv: kv[1], reverse=True)[:10]
        return {
            "count": self.count,
            "per_sec": per(self.count),
            "io_mb": r(self.io / 2**20, 2),
            "pagefile_count": self.pf_count,
            "pagefile_per_sec": per(self.pf_count),
            "pagefile_io_mb": r(self.pf_io / 2**20, 2),
            "excluded_self": self.excluded,
            # Доля строк, где процесс и файл разобрались. Низкая = формат xperf не тот, выводам не доверять.
            "parse_quality": r(self.good_rows / self.count, 2) if self.count else None,
            "top_files": [{"file": k, "count": n, "io_mb": r(b / 2**20, 2)} for k, (n, b) in files],
            "top_processes": [{"process": k, "count": n} for k, n in procs],
        }


class _Procs:
    """Запуски и завершения процессов в окне (P-Start / P-End из трассы ядра, флаг PROC_THREAD).

    Нужны, чтобы рядом с рывками было видно, что в этот момент запускалось (апдейтер, ping.exe из
    какого-нибудь монитора сети и т. п.) и кто это запустил. Командные строки не сохраняются: лаунчеры
    передают играм токены входа именно так, а отчётом делятся."""

    MAX_EVENTS = 200

    def __init__(self, exclude_pids: set[int], pid_names: dict[int, str]) -> None:
        self.exclude_pids = exclude_pids
        self.pid_names = pid_names
        self.cols: dict[str, dict[str, int | None]] = {}
        self.events: list[tuple[int, str, str, int, int | None]] = []   # ts, kind, name, pid, parent

    def header(self, kind: str, names: list[str]) -> None:
        low = [n.strip().lower() for n in names]
        self.cols[kind] = {"proc": next((i for i, n in enumerate(low) if "process name" in n), None),
                           "parent": next((i for i, n in enumerate(low) if "parentpid" in n.replace(" ", "")), None)}

    def add(self, kind: str, parts: list[str], ts: int) -> None:
        c = self.cols.get(kind) or {}
        i = c.get("proc") if c.get("proc") is not None else 2
        m = _PID_RE.match(parts[i].strip()) if i < len(parts) else None
        if not m:
            return
        name, pid = m.group(1).strip().strip('"'), int(m.group(2))
        if pid in self.exclude_pids or name.lower() in SELF_IMAGES:
            return
        if is_unknown_module(name) and self.pid_names.get(pid):
            name = self.pid_names[pid]
        parent = None
        j = c.get("parent")
        if j is not None and j < len(parts):
            try:
                parent = int(parts[j].strip(), 0)
            except ValueError:
                parent = None
        if len(self.events) < self.MAX_EVENTS:
            self.events.append((ts, kind, name, pid, parent))

    def summary(self, start_us: int) -> dict | None:
        if not self.events:
            return None
        names = {pid: name for _, _, name, pid, _ in self.events}

        def row(ts, name, pid, parent):
            d = {"name": name, "pid": pid, "at_ms": r((ts - start_us) / 1000, 1)}
            if parent is not None:
                d["parent_pid"] = parent
                pname = names.get(parent) or self.pid_names.get(parent)
                if pname:
                    d["parent"] = pname
            return d
        started = [row(ts, n, p, par) for ts, k, n, p, par in self.events if k == "start"]
        ended = [row(ts, n, p, par) for ts, k, n, p, par in self.events if k == "end"]
        by_name: dict[str, int] = defaultdict(int)
        for x in started:
            by_name[x["name"]] += 1
        return {"started": started[:60], "ended": ended[:60],
                "started_by_name": dict(sorted(by_name.items(), key=lambda kv: -kv[1]))}


def parse_dumper(lines: Iterable[str], exclude_pids: set[int] | None = None, start_us: int = 0,
                 resolve: Callable[[int | None], str | None] | None = None,
                 pid_names: dict[int, str] | None = None) -> dict:
    """start_us: начало окна (xperf -range). Длительность и все отметки времени считаются от него,
    иначе частоты занижаются, а «в N мс» указывает на позицию во всей кольцевой трассе.

    resolve: адрес процедуры -> имя модуля (снимок модулей ядра). Вызывается только для событий,
    которым xperf не нашёл имя. pid_names: PID -> имя процесса для hard faults без имени."""
    acc = {"dpc": _Acc(), "isr": _Acc()}
    hf = _HardFaults(set(exclude_pids or ()), pid_names)
    procs = _Procs(set(exclude_pids or ()), pid_names or {})
    resolved = unresolved = 0
    resolve_cache: dict[str, str | None] = {}
    max_cpu = -1
    in_header = False
    top: list[tuple] = []                                   # min-heap самых длинных событий
    cpu_events: dict[int, list] = defaultdict(list)         # cpu -> [(начало, конец, модуль)] всех DPC/ISR
    longest_in_bin: dict[tuple[int, int], int] = {}         # (cpu, ms) -> самое длинное событие, начавшееся в окне
    cswitch_total, cswitch_cpu, ready = 0, defaultdict(int), 0
    last_ts = 0

    for line in lines:
        s = line.lstrip()
        if not s or s[0] not in "DIRCHBEP":
            continue
        if s.startswith("BeginHeader"):
            in_header = True
            continue
        if s.startswith("EndHeader"):
            in_header = False
            continue
        if s.startswith("HardFault,"):
            parts = s.rstrip("\r\n").split(",")
            if in_header:
                hf.header(parts)
                continue
            try:
                ts = int(parts[1])
            except (ValueError, IndexError):
                continue
            hf.add(parts)
            last_ts = max(last_ts, ts)
            continue
        if s.startswith(("P-Start,", "P-End,")):
            parts = s.rstrip("\r\n").split(",")
            kind = "start" if parts[0] == "P-Start" else "end"
            if in_header:
                procs.header(kind, parts)
                continue
            try:
                ts = int(parts[1])
            except (ValueError, IndexError):
                continue
            procs.add(kind, parts, ts)
            continue
        if in_header:
            continue
        if s.startswith(("DPC,", "DPCTmr,", "Interrupt,")):
            parts = s.split(",")
            try:
                ts, el, cpu = int(parts[1]), int(parts[2]), int(parts[3])
            except (ValueError, IndexError):
                continue                                    # строки заголовка
            kind = "isr" if parts[0] == "Interrupt" else "dpc"
            mod = _module(parts[-1])
            if resolve is not None and is_unknown_module(mod):
                key = parts[-2].strip() if len(parts) >= 2 else ""
                if key not in resolve_cache:
                    resolve_cache[key] = resolve(parse_address(key))
                name = resolve_cache[key]
                if name:
                    mod = name
                    resolved += 1
                else:
                    mod = "Unknown"
                    unresolved += 1
            max_cpu = max(max_cpu, cpu)
            acc[kind].add(mod, el, cpu)
            last_ts = max(last_ts, ts)
            item = (el, ts, cpu, mod, kind)
            if len(top) < TOP_EVENTS:
                heapq.heappush(top, item)
            elif el > top[0][0]:
                heapq.heapreplace(top, item)
            cpu_events[cpu].append((ts, ts + el, mod))
            key = (cpu, ts // BIN_US)
            if el > longest_in_bin.get(key, -1):
                longest_in_bin[key] = el
        elif s.startswith("CSwitch,"):
            parts = s.split(",")
            try:
                ts = int(parts[1])
                cpu = int(parts[16])
            except (ValueError, IndexError):
                continue
            cswitch_total += 1
            cswitch_cpu[cpu] += 1
            last_ts = max(last_ts, ts)
        elif s.startswith("ReadyThread,"):
            ready += 1

    dur_s = (last_ts - start_us) / 1e6 if last_ts > start_us else 0.0
    # Занятость по миллисекундам считаем по реальному времени: вложенные ISR не дублируются,
    # событие на стыке окон делится между ними. Поэтому на одном ядре окно не бывает больше 1000 мкс.
    sys_bins: dict[int, dict[str, int]] = defaultdict(lambda: defaultdict(int))   # ms -> {модуль: usec}
    worst_cpu: list[tuple[int, int, int, dict]] = []                               # (usec, cpu, ms, {модуль: usec})
    for cpu, evs in cpu_events.items():
        bins: dict[int, list] = {}
        for t0, t1, mod in _exclusive_segments(evs):
            for ms, us in _spread(t0, t1):
                b = bins.get(ms)
                if b is None:
                    b = bins[ms] = [0, defaultdict(int)]
                b[0] += us
                b[1][mod] += us
                sys_bins[ms][mod] += us
        worst_cpu.extend((v[0], cpu, ms, v[1]) for ms, v in heapq.nlargest(10, bins.items(), key=lambda kv: kv[1][0]))
    worst_cpu = sorted(worst_cpu, key=lambda w: w[0], reverse=True)[:10]
    worst_sys = sorted(sys_bins.items(), key=lambda kv: sum(kv[1].values()), reverse=True)[:10]
    extra: dict = {}
    if resolve is not None:
        total = resolved + unresolved
        extra["name_resolution"] = {
            "source": "снимок модулей ядра",
            "resolved_events": resolved,
            "unresolved_events": unresolved,
            "resolved_share": r(resolved / total, 3) if total else None,
        }
        if resolved:
            # Полная сводка по модулям с восстановленными именами: ею заменяется «Unknown» у ETW_TRACER
            ncpu = max_cpu + 1
            extra["modules_detail"] = {k: acc[k].detail(ncpu) for k in ("dpc", "isr")}
    return {
        "trace_duration_s": r(dur_s, 3),
        "dpc": acc["dpc"].summary(dur_s),
        "isr": acc["isr"].summary(dur_s),
        "longest_events": [{"type": k, "module": m, "us": el, "cpu": c, "at_ms": r((ts - start_us) / 1000, 3)}
                           for el, ts, c, m, k in sorted(top, reverse=True)],
        # Сколько микросекунд из одной миллисекунды ядро было занято DPC/ISR и не могло выполнять потоки.
        # top_module — драйвер, занявший в этом окне больше всего времени; top_event_us — самое длинное
        # событие, начавшееся в окне (None, если окно занято хвостом события из предыдущей миллисекунды).
        "worst_cpu_windows_1ms": [{"cpu": c, "at_ms": ms - start_us // BIN_US, "busy_us": busy,
                                   "top_module": max(mods, key=mods.get), "top_event_us": longest_in_bin.get((c, ms))}
                                  for busy, c, ms, mods in worst_cpu],
        # Окна, где несколько драйверов на разных ядрах сработали в одну и ту же миллисекунду
        "worst_system_windows_1ms": [{
            "at_ms": ms - start_us // BIN_US, "busy_us": sum(mods.values()),
            "modules": [{"module": m, "us": us} for m, us in sorted(mods.items(), key=lambda kv: -kv[1])[:5]],
        } for ms, mods in worst_sys],
        "cswitch": {
            "count": cswitch_total,
            "per_sec": r(cswitch_total / dur_s, 1) if dur_s else None,
            "per_cpu": dict(sorted(cswitch_cpu.items())),
        } if cswitch_total else None,
        "ready_thread_events": ready or None,
        # None = HARD_FAULTS в трассе не было (старая версия или флаг выключен)
        "hard_faults": hf.summary(dur_s),
        # None = за окно ничего не запускалось и не завершалось (кроме самого KernelXray)
        "processes": procs.summary(start_us),
        **extra,
    }
