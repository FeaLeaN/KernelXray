"""Агрегация сэмплов счётчиков производительности (avg / peak)."""
from __future__ import annotations

import csv
from pathlib import Path

from .stats import mean, percentile, r

FIELDS = [
    "timestamp",
    "processor_queue_length",
    "context_switches_per_sec",
    "dpc_time_percent",
    "interrupt_time_percent",
    "interrupts_per_sec",
    "cpu_usage_percent",
    "disk_queue_depth",
    "disk_transfers_per_sec",
    "page_reads_per_sec",
    "pages_input_per_sec",
    "available_mbytes",
    "max_core_interrupts_per_sec",
    "max_core_interrupt_name",
    "max_core_dpc_time_percent",
]
_NON_NUMERIC = {"timestamp", "max_core_interrupt_name"}


def write_csv(path: Path, samples: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(samples)


def read_csv(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as f:
        samples = []
        for row in csv.DictReader(f):
            s = {}
            for k, v in row.items():
                if k in _NON_NUMERIC:
                    s[k] = v
                else:
                    try:
                        s[k] = float(v)
                    except (TypeError, ValueError):
                        s[k] = None
            samples.append(s)
        return samples


def aggregate(samples: list[dict]) -> dict:
    if not samples:
        return {"status": "NO_DATA", "sample_count": 0}
    out: dict = {"status": "OK", "sample_count": len(samples), "avg": {}, "median": {}, "peak": {}}
    for field in FIELDS:
        if field in _NON_NUMERIC:
            continue
        vals = [s[field] for s in samples if isinstance(s.get(field), (int, float))]
        if vals:
            out["avg"][field] = r(mean(vals), 1)
            out["median"][field] = r(percentile(sorted(vals), 50), 1)
            out["peak"][field] = r(max(vals), 1)
    hot = max(samples, key=lambda s: s.get("max_core_interrupts_per_sec") or 0)
    out["hottest_core"] = hot.get("max_core_interrupt_name")
    out["raw_samples"] = samples
    return out
