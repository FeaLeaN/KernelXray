"""Статистика по CSV PresentMon 2.x + автоматический выбор игры среди всех процессов с кадрами."""
from __future__ import annotations

import bisect
import csv
import io
import locale
import re
from collections import Counter, defaultdict
from pathlib import Path

from .stats import mean, percentile, r

METRICS = [
    "MsBetweenPresents",         # frame time
    "MsBetweenDisplayChange",    # интервал между сменами картинки на экране
    "MsUntilDisplayed",          # present -> экран
    "MsRenderPresentLatency",    # present -> GPU закончил рендер
    "MsInPresentAPI",            # сколько поток игры провёл внутри вызова Present
    "MsCPUBusy",
    "MsCPUWait",
    "MsGPUBusy",
    "MsGPUWait",
    "MsGPUTime",
    "MsGPULatency",
    "MsFlipDelay",
    "MsAllInputToPhotonLatency",
    "MsClickToPhotonLatency",
]
# PresentMon с --v2_metrics (и будущие версии) пишет те же величины под другими именами.
COLUMN_ALIASES = {
    "FrameTime": "MsBetweenPresents",
    "CPUBusy": "MsCPUBusy",
    "CPUWait": "MsCPUWait",
    "GPUBusy": "MsGPUBusy",
    "GPUWait": "MsGPUWait",
    "GPULatency": "MsGPULatency",
    "GPUTime": "MsGPUTime",
    "AllInputToPhotonLatency": "MsAllInputToPhotonLatency",
    "ClickToPhotonLatency": "MsClickToPhotonLatency",
    "msUntilDisplayed": "MsUntilDisplayed",
    "msBetweenPresents": "MsBetweenPresents",
    "msFlipDelay": "MsFlipDelay",
    "Runtime": "PresentRuntime",
}

# Кадры есть всегда, но это не игра: композитор и неопознанные процессы.
SYSTEM_APPS = {"dwm.exe", "<unknown>", ""}
# Процессы, которые рисуют кадры, но почти никогда не являются целью замера.
# Точные имена (без .exe): короткие слова вроде "opera" или "origin" встречаются в названиях игр.
NON_GAME_EXACT = {
    "explorer", "systemsettings", "widgets", "snippingtool", "screenclippinghost", "notepad", "devenv", "code",
    "chrome", "msedge", "firefox", "opera", "brave", "vivaldi", "arc",
    "steam", "epicgameslauncher", "eadesktop", "origin", "battle.net", "upc", "ubisoftconnect", "galaxyclient",
    "discord", "telegram", "whatsapp", "slack", "teams", "ms-teams", "zoom", "skype", "spotify",
    "obs64", "obs32", "streamlabs obs", "medal", "overwolf", "rtss", "msiafterburner", "hwinfo64", "capframex",
    "lively", "rainmeter", "wallpaper32", "wallpaper64",
}
# Подстроки: достаточно длинные и специфичные, чтобы не задеть игру.
NON_GAME_HINTS = (
    "experiencehost", "searchhost", "searchapp", "textinputhost", "applicationframehost", "lockapp", "gamebar",
    "xboxpcapp", "webview", "webhelper", "cefsharp", "qtwebengine", "browser", "launcher", "riotclient",
    "nvcontainer", "nvidia", "radeonsoftware", "amdrsserv", "яндекс", "музыка",
)

MAX_SERIES = 5000
# Кадр игры считается растянутым сторонним выводом, если он дольше медианы в столько раз и на его интервал
# пришёлся present без цепочки буферов игры (SwapChainAddress 0x0) из того же процесса.
FOREIGN_SLOW_FACTOR = 1.5
FOREIGN_TOL_MS = 0.5


def _snake(name: str) -> str:
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", "_", name).lower()


def _num(v: str | None) -> float | None:
    if v is None or v in ("", "NA"):
        return None
    try:
        return float(v)
    except ValueError:
        return None


def _stem(app: str) -> str:
    a = app.strip().lower()
    return a[:-4] if a.endswith(".exe") else a


def is_non_game(app: str) -> bool:
    s = _stem(app)
    return app.strip().lower() in SYSTEM_APPS or s in NON_GAME_EXACT or any(h in s for h in NON_GAME_HINTS)


def _read_text(path: Path) -> str:
    """PresentMon пишет имена процессов в кодировке консоли; кириллица в имени не должна ломать разбор."""
    return decode_console_bytes(path.read_bytes())


def decode_console_bytes(raw: bytes) -> str:
    """PresentMon при перенаправлении stdout/stderr в файл пишет UTF-16LE с BOM (FF FE)."""
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")) or (len(raw) >= 4 and raw[1:40:2].count(0) > 5):
        return raw.decode("utf-16", errors="replace").lstrip("\ufeff")
    for enc in ("utf-8-sig", locale.getpreferredencoding(False), "cp1251"):
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", errors="replace")


def _read_rows(path: Path) -> list[dict]:
    text = _read_text(path)
    # Всё до строки заголовка (предупреждения, если PresentMon что-то напишет в stdout) пропускаем.
    start = text.find("Application,")
    if start < 0:
        return []
    rows = []
    for row in csv.DictReader(io.StringIO(text[start:], newline="")):
        if not row.get("ProcessID") or row.get("Application") == "Application" or None in row.values():
            continue      # обрывок последней строки (процесс остановлен посреди записи) или повторный заголовок
        rows.append({COLUMN_ALIASES.get(k, k): v for k, v in row.items() if k is not None})
    return rows


def _null_swapchain(addr: str | None) -> bool:
    try:
        return int(addr, 16) == 0 if addr else False
    except ValueError:
        return False


def count_frames(path: Path) -> int:
    """Сколько строк-кадров в CSV PresentMon (любых процессов)."""
    return len(_read_rows(path))


def _fullscreen_share(frames: list[dict]) -> float:
    modes = Counter(f.get("PresentMode") or "" for f in frames)
    hw = sum(n for m, n in modes.items() if m.startswith("Hardware"))
    return hw / len(frames) if frames else 0.0


def pick_application(per_app: dict[str, list[dict]], target: str | None) -> tuple[str | None, str, str | None]:
    """Возвращает (приложение, как выбрано, пояснение). Приложение None, если игры в кадрах нет."""
    note = None
    if target:
        t = _stem(target)
        exact = [a for a in per_app if _stem(a) == t]
        partial = [a for a in per_app if t and (t in _stem(a) or _stem(a) in t) and _stem(a) not in ("", "dwm")]
        hit = exact or partial
        if hit:
            return max(hit, key=lambda a: len(per_app[a])), "target", None
        note = f"{target} не выводил кадры во время захвата, игра выбрана автоматически."

    games = [a for a in per_app if not is_non_game(a)]
    if games:
        # Больше кадров и полноэкранный вывод (Hardware: Independent Flip / Legacy Flip) -> вероятнее игра.
        app = max(games, key=lambda a: len(per_app[a]) * (1 + _fullscreen_share(per_app[a])))
        return app, "auto", note

    others = [a for a in per_app if a.strip().lower() not in SYSTEM_APPS]
    if others:
        app = max(others, key=lambda a: len(per_app[a]))
        return app, "fallback", ((note + " ") if note else "") + (
            f"Игр среди процессов с кадрами не найдено, показан самый активный: {app}.")
    return None, "none", note


def _app_stats(frames: list[dict]) -> dict:
    """Метрики одного процесса: средние/перцентили, FPS, 1% low, рывки, ряд для графика, режимы вывода."""
    out: dict = {"captured_frames": len(frames)}
    for col in METRICS:
        vals = sorted(v for row in frames if (v := _num(row.get(col))) is not None)
        if not vals:
            continue
        key = _snake(col)
        out[f"avg_{key}"] = r(mean(vals))
        out[f"p95_{key}"] = r(percentile(vals, 95))
        out[f"p99_{key}"] = r(percentile(vals, 99))
        out[f"max_{key}"] = r(vals[-1])

    # GPU-колонки, где все значения ровно 0, — это не «GPU свободен», а отсутствие данных (например, в .etl
    # не было rundown контекстов DxgKrnl). Убираем их, чтобы отчёт показал прочерк, а не 0.000 ms.
    gpu_keys = [k for k in list(out) if "_gpu_" in k]
    if gpu_keys and all(out[k] == 0 for k in gpu_keys):
        for k in gpu_keys:
            del out[k]
        out["gpu_metrics_missing"] = True

    ft = [v for row in frames if (v := _num(row.get("MsBetweenPresents"))) is not None and v > 0]
    if ft:
        ft_sorted = sorted(ft)
        worst = ft_sorted[-max(1, len(ft_sorted) // 100):]
        median = percentile(ft_sorted, 50)
        out["avg_fps"] = r(1000 / mean(ft), 1)
        out["fps_1pct_low"] = r(1000 / mean(worst), 1)
        out["median_ms_frame_time"] = r(median, 3)
        out["stutter_frames"] = sum(1 for v in ft if v > 2 * median)   # кадр вдвое дольше медианы
        # Когда были медленные кадры (от начала захвата): отчёт сверяет их с запусками процессов
        times = [(t, v) for row in frames
                 if (v := _num(row.get("MsBetweenPresents"))) is not None and v > FOREIGN_SLOW_FACTOR * median
                 and (t := _num(row.get("TimeInMs"))) is not None]
        t_first = min((t for row in frames if (t := _num(row.get("TimeInMs"))) is not None), default=None)
        if times and t_first is not None:
            out["slow_frame_at_s"] = [round((t - t_first) / 1000, 2) for t, _ in times][:100]
        step = max(1, len(ft) // MAX_SERIES)
        out["frame_time_series"] = [round(v, 3) for v in ft[::step]]

    # NA в MsUntilDisplayed = кадр так и не попал на экран
    shown = sum(1 for row in frames if _num(row.get("MsUntilDisplayed")) is not None)
    out["dropped_frames"] = len(frames) - shown if any("MsUntilDisplayed" in row for row in frames) else None

    out["present_modes"] = dict(Counter(row.get("PresentMode", "?") for row in frames))
    out["sync_interval"] = dict(Counter(row.get("SyncInterval", "?") for row in frames))
    return out


def foreign_presents(frames: list[dict], ghosts: list[dict], median_ms: float | None) -> dict | None:
    """Present без цепочки игры (SwapChainAddress 0x0) внутри процесса игры и кадры, которые они растянули.

    Так в трассе выглядит вторая поверхность в процессе игры: всплывающее окно или уведомление оверлея
    (Steam, Discord, EA app, AMD Adrenalin, RTSS). Сами эти строки из статистики уже убраны, но кадр игры,
    на интервал которого пришёлся такой вывод, часто длится в 2–5 раз дольше. Здесь такие кадры считаются
    отдельно, чтобы их не путали с задержками драйверов.
    """
    times: set[float] = set()
    for g in ghosts:
        t, d = _num(g.get("TimeInMs")), _num(g.get("MsBetweenPresents"))
        if t is None:
            continue
        times.add(round(t, 3))
        if d and d > 0:
            times.add(round(t - d, 3))        # предыдущий такой present: у первого строки в CSV нет
    if not times:
        return None
    ts = sorted(times)
    first = min((t for row in frames if (t := _num(row.get("TimeInMs"))) is not None), default=ts[0])
    ft_len = sum(1 for row in frames if (v := _num(row.get("MsBetweenPresents"))) is not None and v > 0)
    step = max(1, ft_len // MAX_SERIES)       # как в frame_time_series
    stalls: list[tuple[int, float, float]] = []
    idx = -1
    for row in frames:
        v = _num(row.get("MsBetweenPresents"))
        if v is None or v <= 0:
            continue
        idx += 1
        t = _num(row.get("TimeInMs"))
        if t is None or not median_ms or v <= FOREIGN_SLOW_FACTOR * median_ms:
            continue
        j = bisect.bisect_left(ts, t - v - FOREIGN_TOL_MS)
        if j < len(ts) and ts[j] <= t + FOREIGN_TOL_MS:
            stalls.append((idx, t, v))
    rel = [round((t - first) / 1000, 2) for t in ts]
    return {
        "foreign_presents": len(ts),
        "foreign_present_at_s": rel[:30],
        "foreign_stall_frames": len(stalls),
        "foreign_stall_max_ms": r(max((v for _, _, v in stalls), default=0.0)) if stalls else None,
        "foreign_stall_at_s": [round((t - first) / 1000, 2) for _, t, _ in stalls][:30],
        "foreign_stall_series_idx": sorted({i // step for i, _, _ in stalls})[:200],
    }


def parse_presentmon_csv(path: Path, target_process: str | None = None) -> dict:
    rows = _read_rows(path)
    if not rows:
        return {"captured_frames": 0, "observed_processes": {}, "selection": "none",
                "note": "PresentMon не увидел ни одного кадра, даже от рабочего стола (dwm.exe): события вывода "
                        "не доходили до его ETW-сессии. Текст PresentMon — в present_mon_console.log."}

    per_app: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        per_app[row.get("Application", "")].append(row)
    # Кадры без цепочки буферов (SwapChainAddress 0x0) у процесса, который рисует через свою цепочку, — не кадры
    # игры: в режиме ETL PresentMon иногда приписывает игре редкие служебные present (интервал 50–300 мс), и
    # они одни обрушивают 1% low. Если у процесса есть настоящая цепочка, такие строки отбрасываем.
    ghost_frames: dict[str, int] = {}
    ghost_rows: dict[str, list[dict]] = {}
    for app, frames in per_app.items():
        real = [f for f in frames if not _null_swapchain(f.get("SwapChainAddress"))]
        if real and len(real) < len(frames) and len(real) >= len(frames) / 2:
            ghost_frames[app] = len(frames) - len(real)
            ghost_rows[app] = [f for f in frames if _null_swapchain(f.get("SwapChainAddress"))]
            per_app[app] = real
    observed = dict(sorted(((a or "<empty>", len(f)) for a, f in per_app.items()), key=lambda x: -x[1])[:15])

    # Рабочий стол (композитор) считаем отдельно и всегда: его ритм виден и в оконных играх, и без игры.
    dwm_frames = [row for a, frames in per_app.items() if a.strip().lower() == "dwm.exe" for row in frames]
    dwm = _app_stats(dwm_frames) if dwm_frames else None

    app, how, note = pick_application(per_app, target_process)
    if app is None:
        out = {"captured_frames": 0, "observed_processes": observed, "selection": how,
               "note": ((note + " ") if note else "") +
                       "Игра кадры не выводила (свёрнута, на паузе в фоне или не запущена), "
                       "поэтому ниже только рабочий стол Windows (dwm.exe)."}
        if dwm:
            out["dwm"] = dwm
        return out

    out = {"application": app, "selection": how, "observed_processes": observed}
    if ghost_frames.get(app):
        out["excluded_null_swapchain_frames"] = ghost_frames[app]
    if note:
        out["note"] = note
    out.update(_app_stats(per_app[app]))
    if ghost_rows.get(app):
        out.update(foreign_presents(per_app[app], ghost_rows[app], out.get("median_ms_frame_time")) or {})
    if dwm:
        out["dwm"] = dwm
    return out
