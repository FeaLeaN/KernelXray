from __future__ import annotations

import math


def percentile(sorted_vals: list[float], p: float) -> float | None:
    """Линейная интерполяция (как numpy.percentile по умолчанию). Список должен быть отсортирован."""
    if not sorted_vals:
        return None
    k = (len(sorted_vals) - 1) * p / 100.0
    f = math.floor(k)
    c = min(f + 1, len(sorted_vals) - 1)
    return sorted_vals[f] + (sorted_vals[c] - sorted_vals[f]) * (k - f)


def mean(vals: list[float]) -> float | None:
    return sum(vals) / len(vals) if vals else None


def r(x: float | None, nd: int = 2) -> float | None:
    return None if x is None else round(x, nd)
