from .devices import (AudioDpcProbe, CoreCollisionProbe, DriverManifestProbe, GpuAnalysisProbe,
                      GpuSchedulerProbe, InputEliteProbe, UsbPowerProbe)
from .etw_sonar import EtwSonarProbe
from .etw_tracer import EtwTracerProbe
from .network import NetworkEliteProbe
from .os_probes import OsConfigProbe, OsEntropyProbe, ServicesBloatProbe
from .perfmon import PerfmonProbe
from .present_mon import PresentMonProbe
from .storage import StorageEliteProbe, StorageGuideProbe
from .system import (BiosFirmwareProbe, CpuTopologyProbe, HardwareInfoProbe, HardwareMisconfigProbe,
                     MemoryManagementProbe, ProcessesProbe, SystemCoreProbe, TimerResolutionProbe)

# Снапшоты выполняются до окна захвата, чтобы их собственная активность (WMI, powercfg) не попала в трассу.
SNAPSHOT_PROBES = [
    CpuTopologyProbe, HardwareInfoProbe, HardwareMisconfigProbe, BiosFirmwareProbe,
    SystemCoreProbe, TimerResolutionProbe, MemoryManagementProbe, ProcessesProbe,
    OsConfigProbe, OsEntropyProbe, ServicesBloatProbe,
    DriverManifestProbe, GpuAnalysisProbe, GpuSchedulerProbe, AudioDpcProbe, InputEliteProbe,
    UsbPowerProbe, CoreCollisionProbe,
    NetworkEliteProbe,
    StorageEliteProbe, StorageGuideProbe,
]
# Порядок важен: пробы стартуют по списку и останавливаются в обратном порядке.
# PresentMon запускается первым, чтобы загрузка его образа (hard faults, диск) не попала в ETW и PerfMon.
# PerfMon стартует последним и останавливается первым: слияние .etl в `xperf -d` и остановка PresentMon
# идут уже вне окна счётчиков. SONAR анализирует трассу ETW_TRACER, своей сессии у него нет.
CAPTURE_PROBES = [PresentMonProbe, EtwTracerProbe, EtwSonarProbe, PerfmonProbe]
