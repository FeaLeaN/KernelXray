"""Пробы устройств: драйверы, GPU, аудио, ввод, USB, распределение прерываний по ядрам."""
from __future__ import annotations

import re

from ..core.context import SessionContext
from ..core.probe import SnapshotProbe
from ..core.win import (HKCU, HKLM, as_int, class_values, devices_of, driver_info, pci_devices,
                        powercfg_ac_dc, process_names, reg_get, reg_values, services, wmi)

VENDORS = {"1002": "AMD", "10DE": "NVIDIA", "8086": "Intel"}


def _dev_brief(d: dict) -> dict:
    return {k: d.get(k) for k in ("name", "class", "service", "msi_supported", "msi_message_limit",
                                  "affinity_policy", "affinity_mask", "device_priority")}


class DriverManifestProbe(SnapshotProbe):
    name = "DRIVER_MANIFEST"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        out = {}
        for cls in ("display", "net", "media", "usb", "storage", "hdc"):
            out[cls] = [{"name": d["name"], "service": d["service"], **driver_info(d["driver_key"])}
                        for d in devices_of(cls)]
        gpu = out["display"][0] if out["display"] else {}
        out.update({
            "gpu_driver_version": gpu.get("version"),
            "gpu_driver_date": gpu.get("date"),
            "gpu_driver_provider": gpu.get("provider"),
            "gpu_driver_age_days": gpu.get("age_days"),
        })
        return out


class GpuAnalysisProbe(SnapshotProbe):
    name = "GPU_ANALYSIS"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        gpus = []
        for d in devices_of("display"):
            v = class_values(d["driver_key"])
            vram = as_int(v.get("HardwareInformation.qwMemorySize") or v.get("HardwareInformation.MemorySize"))
            gpus.append({
                **_dev_brief(d),
                "vendor": VENDORS.get(d["vendor_id"], d["vendor_id"]),
                "vendor_id": d["vendor_id"], "device_id": d["device_id"],
                "vram_mb": vram // 2**20 if vram else None,
                **{f"driver_{k}": x for k, x in driver_info(d["driver_key"]).items()},
            })
        return {"gpus": gpus, "gpu_count": len(gpus)}


class GpuSchedulerProbe(SnapshotProbe):
    name = "GPU_SCHEDULER"
    timeout_s = 5.0

    def collect(self, ctx: SessionContext) -> dict:
        gd = reg_values(HKLM, r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers")
        prefs = reg_values(HKCU, r"Software\Microsoft\DirectX\UserGpuPreferences")
        glob = prefs.pop("DirectXUserGlobalSettings", "") or ""
        glob_kv = dict(p.split("=", 1) for p in glob.split(";") if "=" in p)
        return {
            "hags": {2: "on", 1: "off"}.get(as_int(gd.get("HwSchMode")), "driver_default"),
            "tdr_delay_s": as_int(gd.get("TdrDelay")),
            "windowed_optimizations": {"1": "on", "0": "off"}.get(glob_kv.get("SwapEffectUpgradeEnable"), "default"),
            "vrr_optimizations": {"1": "on", "0": "off"}.get(glob_kv.get("VRROptimizeEnable"), "default"),
            "per_app_gpu_preferences": len(prefs),
            "mpo_disabled": as_int(reg_get(HKLM, r"SOFTWARE\Microsoft\Windows\Dwm", "OverlayTestMode")) == 5,
        }


# Шаблоны с границами слов: короткие «dts», «sonar», «waves» подстрокой ловили посторонние программы.
# Служба Realtek RtkAudUService — обычный компонент драйвера, а не улучшайзер, в список не входит.
AUDIO_ENHANCERS = [
    r"nahimic", r"sonic\s?studio", r"\bdolby", r"\bdts\s?(apo|audio|sound|x|headphone)", r"\bdtsapo",
    r"steelseries\s?sonar", r"\bsonar(service)?\.exe\b", r"nvbroadcast|nvidia broadcast", r"voicemeeter",
    r"fxsound", r"maxxaudio", r"\bwaves\s?(maxx|audio|svc)|\bwavessvc", r"realtek audio console",
]
_AUDIO_RE = re.compile("|".join(f"(?:{p})" for p in AUDIO_ENHANCERS), re.I)


def is_audio_enhancer(text: str) -> bool:
    return bool(_AUDIO_RE.search(text or ""))


class AudioDpcProbe(SnapshotProbe):
    name = "AUDIO_DPC"
    timeout_s = 15.0

    def collect(self, ctx: SessionContext) -> dict:
        devs = wmi("SELECT Name, Manufacturer, PNPDeviceID, Status FROM Win32_SoundDevice")
        found = set()
        for s in services().values():
            text = f"{s['name']} {s['display']}".lower()
            if s["state"] == "running" and is_audio_enhancer(text):
                found.add(s["display"])
        for p in process_names():
            if is_audio_enhancer(p):
                found.add(p)
        eq_apo = bool(reg_values(HKLM, r"SOFTWARE\EqualizerAPO"))
        if eq_apo:
            found.add("Equalizer APO")
        return {
            "devices": [{"name": d.get("Name"), "vendor": d.get("Manufacturer"),
                         "bus": (d.get("PNPDeviceID") or "").split("\\")[0]} for d in devs],
            "usb_audio_count": sum(1 for d in devs if (d.get("PNPDeviceID") or "").upper().startswith("USB")),
            "found_enhancers": sorted(found),
            "enhancers_detected": bool(found),
        }


class InputEliteProbe(SnapshotProbe):
    name = "INPUT_ELITE"
    timeout_s = 15.0

    def collect(self, ctx: SessionContext) -> dict:
        mouse = reg_values(HKCU, r"Control Panel\Mouse")
        hid = wmi("SELECT PNPDeviceID, Name, PNPClass FROM Win32_PnPEntity "
                  "WHERE PNPClass='HIDClass' OR PNPClass='Mouse' OR PNPClass='Keyboard'")
        usb_nodes = sorted({h["PNPDeviceID"] for h in hid if (h.get("PNPDeviceID") or "").upper().startswith("USB\\")})
        power = []
        for inst in usb_nodes:
            dp = reg_values(HKLM, rf"SYSTEM\CurrentControlSet\Enum\{inst}\Device Parameters")
            power.append({
                "instance": inst,
                "enhanced_power_management": as_int(dp.get("EnhancedPowerManagementEnabled")),
                "selective_suspend": as_int(dp.get("SelectiveSuspendEnabled")),
            })
        return {
            "pointer_precision": str(mouse.get("MouseSpeed", "1")) != "0",
            "mouse_sensitivity": as_int(mouse.get("MouseSensitivity")),
            "usb_input_devices": len(usb_nodes),
            "power_managed_input_devices": sum(1 for p in power if p["enhanced_power_management"] == 1
                                               or p["selective_suspend"] == 1),
            "devices_power": power,
        }


class UsbPowerProbe(SnapshotProbe):
    name = "USB_POWER"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        ss = powercfg_ac_dc("SUB_USB", "USBSELECTSUSPEND")
        aspm = powercfg_ac_dc("SUB_PCIEXPRESS", "ASPM")
        return {
            "usb_selective_suspend_ac": {0: "disabled", 1: "enabled"}.get(ss[0], ss[0]),
            "pcie_aspm_ac": {0: "off", 1: "moderate", 2: "maximum"}.get(aspm[0], aspm[0]),
            "usb_disable_selective_suspend_reg": as_int(
                reg_get(HKLM, r"SYSTEM\CurrentControlSet\Services\USB", "DisableSelectiveSuspend")),
            "usb_controllers": [_dev_brief(d) for d in devices_of("usb")],
        }


RSS_KEYS = ["*RSS", "*RssBaseProcNumber", "*MaxRssProcessors", "*NumRssQueues", "*RSSProfile"]


class CoreCollisionProbe(SnapshotProbe):
    """Как прерывания GPU/NIC/USB/аудио закреплены за ядрами (Affinity Policy и RSS)."""
    name = "CORE_COLLISION"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        devs = [_dev_brief(d) for d in pci_devices() if d["class"] in ("display", "net", "usb", "media", "storage")]
        nics = []
        for d in devices_of("net"):
            v = class_values(d["driver_key"])
            nics.append({"name": d["name"], **{k.strip("*"): v.get(k) for k in RSS_KEYS}})
        return {
            "devices": devs,
            "custom_affinity_devices": [d["name"] for d in devs if d["affinity_policy"] not in (None, "default")],
            "nic_rss": nics,
            "rss_enabled": any(str(n.get("RSS")) == "1" for n in nics) if nics else None,
        }
