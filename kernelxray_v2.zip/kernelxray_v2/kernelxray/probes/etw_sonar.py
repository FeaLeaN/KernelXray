"""ETW_SONAR: поэвентный разбор той же трассы, что снял ETW_TRACER (точные максимумы и всплески)."""
from __future__ import annotations

import os

from ..core.context import SessionContext
from ..core.probe import CaptureProbe, ProbeUnavailable
from ..core.tools import run_tool
from ..parsers.dumper import parse_dumper


class EtwSonarProbe(CaptureProbe):
    name = "ETW_SONAR"
    analyze_timeout_s = 1200.0

    def prepare(self, ctx: SessionContext) -> None:
        if "etw" not in ctx.shared:
            raise ProbeUnavailable("работает поверх ETW_TRACER, а тот отключён или не запустился")

    def start(self, ctx: SessionContext) -> None:
        pass     # своей сессии нет: второй NT Kernel Logger параллельно не запустить

    def stop(self, ctx: SessionContext) -> None:
        pass

    def analyze(self, ctx: SessionContext) -> dict:
        etw = ctx.shared["etw"]
        if not etw["etl"].exists():
            raise RuntimeError("трасса ETW_TRACER не записалась")
        dump = ctx.out_dir / "etw_events.txt"
        cmd = [etw["xperf"], "-i", etw["etl"], "-o", dump, "-a", "dumper"]
        if etw.get("range_us"):          # --arm: только окно захвата (ETW_TRACER уже его вычислил)
            cmd += ["-range", str(etw["range_us"][0]), str(etw["range_us"][1])]
        run_tool(cmd, timeout=self.analyze_timeout_s)
        try:
            with open(dump, encoding="utf-8", errors="replace") as f:
                # Свои процессы (KernelXray, загрузчик onefile, PresentMon) в hard faults не считаем
                own = {os.getpid(), os.getppid(), *ctx.shared.get("child_pids", ())}
                # Снимок модулей ядра от ETW_TRACER: имена драйверов там, где xperf пишет Unknown
                kmap = ctx.shared.get("kernel_modules")
                result = parse_dumper(f, exclude_pids=own, start_us=int((etw.get("range_us") or (0, 0))[0]),
                                      resolve=kmap.lookup if kmap else None,
                                      pid_names=ctx.shared.get("pid_names"))
        finally:
            if not ctx.keep_raw:
                dump.unlink(missing_ok=True)
        if not result["dpc"]["count"] and not result["isr"]["count"]:
            raise RuntimeError("в дампе нет событий DPC/Interrupt")
        nr = result.get("name_resolution")
        if nr and nr["resolved_events"]:
            ctx.log.info("ETW_SONAR: имена драйверов восстановлены по снимку модулей ядра: %d событий, "
                         "без имени осталось %d", nr["resolved_events"], nr["unresolved_events"])
        return result
