"""ETW_TRACER: kernel-трассировка DPC/ISR через xperf + сводка `-a dpcisr`.

xperf умеет kernel-флаги (DPC/INTERRUPT/...) ТОЛЬКО с единственным безымянным
NT Kernel Logger (см. docs: "Only a single instance of the kernel logger can exist").
Именованная сессия (-start ИМЯ -on ...) трактуется как пользовательская, и kernel-флаги
для неё невалидны -> ERROR_INVALID_FLAGS (0x3ec). Поэтому используем NT Kernel Logger.
Второй параллельный kernel-логгер через xperf невозможен в принципе — только через ETW API.
"""
from __future__ import annotations

import time

from ..core.context import SessionContext
from ..core.kmodules import ModuleMap, snapshot as kernel_modules_snapshot
from ..core.probe import CaptureProbe, ProbeUnavailable
from ..core.tools import KERNEL_LOGGER, WPT_DIRS, etw_block_hint, find_tool, run_tool
from ..core.win import pid_names_now
from ..parsers.dpcisr import parse_dpcisr_file, summarize, tail_gaps

# Минимум для dpcisr: DPC/ISR + процессы и загрузчик (адреса -> имена драйверов).
# HARD_FAULTS + FILENAME: атрибуция жёстких page-fault'ов; событий немного, трассу почти не раздувают.
# SYSCALL в старой версии раздувал трассу до ~900 МБ за 15 с, для задержек он не нужен.
BASE_FLAGS = ["PROC_THREAD", "LOADER", "DPC", "INTERRUPT", "HARD_FAULTS", "FILENAME"]
DEEP_FLAGS = ["CSWITCH", "DISPATCHER"]
# --arm: логгер работает с момента запуска KernelXray, пока игра грузится. Кольцевой файл хранит
# только последние ARM_MAX_FILE_MB, чтобы трасса не росла, пока ждём F9.
ARM_MAX_FILE_MB = 96     # ~1 МБ/с DPC+ISR в игре: хватает на окно захвата и ~минуту до него
# Если трасса короче жизни сессии больше чем на столько секунд, кольцо провернулось и начало затёрто
RING_LOST_MIN_S = 2.0


class EtwTracerProbe(CaptureProbe):
    name = "ETW_TRACER"
    analyze_timeout_s = 900.0
    armable = True

    def prepare(self, ctx: SessionContext) -> None:
        self.xperf = find_tool(["xperf.exe"], WPT_DIRS)
        if not self.xperf:
            raise ProbeUnavailable(
                "xperf.exe не найден. Поставь Windows Performance Toolkit (из Windows ADK) "
                "или положи xperf в папку tools/ рядом с программой."
            )
        self.raw = ctx.out_dir / "kernel_raw.etl"      # файл живой сессии, после слияния не нужен
        self.etl = ctx.out_dir / "xray_kernel.etl"
        self.report = ctx.out_dir / "etw_dpcisr.txt"
        self._armed = False
        self._circular = False
        self._armed_mono = None
        # Снимок модулей ядра до запуска игры: по нему восстанавливаются имена драйверов, если в трассе
        # не окажется списка образов (кольцо провернулось, остановку не дал античит). См. core/kmodules.py.
        self._kmap = ModuleMap()
        self._snapshot_modules(ctx, "до захвата")

    def _snapshot_modules(self, ctx: SessionContext, when: str) -> None:
        try:
            mods = kernel_modules_snapshot()
        except Exception as exc:          # имена драйверов — не повод ронять трассу
            ctx.log.warning("ETW_TRACER: снимок модулей ядра (%s) не получен: %s", when, exc)
            return
        self._kmap.add(mods)
        if mods:
            ctx.shared["kernel_modules"] = self._kmap
        ctx.log.info("ETW_TRACER: снимок модулей ядра (%s): %d модулей%s", when, len(mods),
                     "" if mods else " (адреса скрыты системой: имена драйверов восстановить не получится)")

    def arm(self, ctx: SessionContext) -> None:
        self._circular = True
        self._armed_mono = time.monotonic()
        self.start(ctx)
        self._armed = True

    def start(self, ctx: SessionContext) -> None:
        if self._armed:
            return                  # логгер уже пишет с момента --arm
        flags = "+".join(BASE_FLAGS + (DEEP_FLAGS if ctx.deep_trace else []))
        # На случай, если NT Kernel Logger остался висеть от прошлого запуска — гасим перед стартом.
        run_tool([self.xperf, "-stop"], timeout=15, check=False)
        try:
            # Без -start имя опускается -> подразумевается NT Kernel Logger (единственный kernel-логгер).
            # 512 КБ x 64..320 буферов: с запасом для ~20-50 тыс. событий/с и без лишней nonpaged-памяти.
            cmd = [self.xperf, "-on", flags, "-f", self.raw,
                   "-BufferSize", "512", "-MinBuffers", "64", "-MaxBuffers", "320"]
            if self._circular:
                cmd += ["-FileMode", "Circular", "-MaxFile", str(ARM_MAX_FILE_MB)]
            run_tool(cmd, timeout=30)
        except RuntimeError as exc:
            raise self._start_error(exc) from exc
        ctx.shared["etw"] = {"xperf": self.xperf, "etl": self.etl}

    def _window_us(self, ctx: SessionContext, trace_s: float | None) -> tuple[int, int] | None:
        """Окно захвата в микросекундах от начала .etl. Конец трассы = момент остановки (stop), поэтому
        окно отсчитывается от конца: T2 = длина трассы - (остановка - конец окна), T1 = T2 - длительность."""
        win = ctx.shared.get("window_mono")
        end = getattr(self, "_trace_end_mono", None)
        if not (self._circular and win and end and trace_s):
            return None
        t2 = trace_s - (end - win[1])
        t1 = max(0.0, t2 - (win[1] - win[0]))
        if t2 <= t1 or t2 > trace_s or trace_s - (t2 - t1) < 1.0:
            return None                  # окно не меньше трассы или не помещается: резать нечего
        return int(t1 * 1e6), int(t2 * 1e6)

    @staticmethod
    def _start_error(exc: RuntimeError) -> RuntimeError:
        hint = etw_block_hint() if "0x5" in str(exc) else None
        if hint:
            return RuntimeError(f"{exc}\n{hint}")
        return RuntimeError(
            f"{exc}\nNT Kernel Logger не поднялся. Частые причины:\n"
            f"  0x5 (отказано в доступе): запусти от администратора; если это не помогает, "
            f"kernel ETW блокирует драйвер (kernel-level античит вроде vgk.sys, либо политика системы).\n"
            f"  0xB7 (уже существует): kernel-логгер занят другим инструментом "
            f"(ProcMon, Process Hacker, WPR, Xbox Game Bar). Закрой его или: xperf -stop"
        )

    def stop(self, ctx: SessionContext) -> None:
        self._trace_end_mono = time.monotonic()      # конец трассы: по нему окно захвата ищется внутри .etl
        try:
            self._stop_logger(ctx)
        finally:
            # Уже после остановки (чтобы не сдвигать конец трассы): второй снимок модулей — драйверы,
            # загруженные вместе с игрой, — и PID -> имя для hard faults без имени процесса.
            self._snapshot_modules(ctx, "после окна")
            try:
                ctx.shared["pid_names"] = pid_names_now()
            except Exception as exc:
                ctx.log.info("ETW_TRACER: список процессов не получен: %s", exc)

    def _stop_logger(self, ctx: SessionContext) -> None:
        # -d = остановить NT Kernel Logger и слить с rundown-данными в один .etl
        try:
            run_tool([self.xperf, "-d", self.etl], timeout=300)
        except RuntimeError as exc:
            if not (self._armed and "0x5" in str(exc)):
                raise
            # --arm под EA AntiCheat: остановить логгер не дают. Пробуем прочитать живой кольцевой файл как есть.
            ctx.log.warning("NT Kernel Logger не остановлен (отказано в доступе), он продолжит писать в кольцевой "
                            "файл до следующего запуска KernelXray без игры или до перезагрузки. "
                            "Пробую разобрать то, что уже записано.")
            # Без остановки последние буферы ядер остаются в памяти, и у тихих ядер обрывается хвост окна.
            # Сброс буферов — отдельный вызов; если античит запретит и его, хвост будет помечен в отчёте.
            fl = run_tool([self.xperf, "-flush", KERNEL_LOGGER], timeout=60, check=False)
            ctx.log.info("xperf -flush: код %s %s", fl.returncode, (fl.stderr or fl.stdout or "").strip()[-200:])
            ctx.shared["etw_flushed"] = fl.returncode == 0
            if fl.returncode == 0:
                self._trace_end_mono = time.monotonic()
            r = run_tool([self.xperf, "-merge", self.raw, self.etl], timeout=300, check=False)
            if r.returncode != 0 or not self.etl.exists():
                raise RuntimeError(f"{exc}\nЛоггер не остановлен античитом, а живой файл прочитать не удалось: "
                                   f"{(r.stderr or r.stdout or '').strip()[-300:]}") from exc
            ctx.shared["etw_live_copy"] = True
            return                   # raw не удаляем: его держит работающий логгер
        self.raw.unlink(missing_ok=True)

    def analyze(self, ctx: SessionContext) -> dict:
        run_tool([self.xperf, "-i", self.etl, "-o", self.report, "-a", "dpcisr"], timeout=self.analyze_timeout_s)
        parsed = parse_dpcisr_file(self.report)
        if not parsed:
            raise RuntimeError(f"В {self.report.name} нет секций DPC/Interrupt, проверь флаги трассировки")
        summary = summarize(parsed)
        window = self._window_us(ctx, summary.get("trace_duration_s"))
        if window:
            # --arm: кольцевая трасса длиннее окна (меню, загрузка до F9, остановка после). Считаем только окно.
            full_s = summary.get("trace_duration_s")
            r = run_tool([self.xperf, "-i", self.etl, "-o", self.report, "-a", "dpcisr",
                          "-range", str(window[0]), str(window[1])], timeout=self.analyze_timeout_s, check=False)
            ranged = parse_dpcisr_file(self.report) if r.returncode == 0 else None
            if ranged:
                parsed, summary = ranged, summarize(ranged)
                summary["window_us"] = list(window)
                summary["trace_full_duration_s"] = full_s
                ctx.shared["etw"]["range_us"] = window
                ctx.log.info("ETW_TRACER: статистика по окну захвата %.1f–%.1f с из %.1f с трассы",
                             window[0] / 1e6, window[1] / 1e6, full_s or 0)
            else:
                ctx.log.warning("ETW_TRACER: xperf -range не сработал, статистика по всей трассе (%s)",
                                (r.stderr or r.stdout or "").strip()[-200:])
                run_tool([self.xperf, "-i", self.etl, "-o", self.report, "-a", "dpcisr"],
                         timeout=self.analyze_timeout_s)
        summary["etl_size_mb"] = round(self.etl.stat().st_size / 2**20, 1) if self.etl.exists() else None
        summary["deep_trace"] = ctx.deep_trace
        if self._circular:
            # кольцевой файл: трасса может начинаться раньше окна захвата (загрузка игры)
            summary["armed_circular_mb"] = ARM_MAX_FILE_MB
            full_s = summary.get("trace_full_duration_s") or summary.get("trace_duration_s")
            end = getattr(self, "_trace_end_mono", None)
            if self._armed_mono and end and full_s:
                lost = (end - self._armed_mono) - full_s
                if lost > RING_LOST_MIN_S:
                    # начало трассы (со списком драйверов) перезаписано: имена берутся из снимка модулей
                    summary["ring_lost_head_s"] = round(lost, 1)
                    ctx.log.info("ETW_TRACER: кольцо провернулось, начало трассы потеряно (%.1f с)", lost)
        if ctx.shared.get("etw_live_copy"):
            summary["logger_not_stopped"] = True
            summary["flushed"] = bool(ctx.shared.get("etw_flushed"))
            gaps = tail_gaps(parsed)
            if gaps:
                # у этих ядер последние буферы не попали в файл: нагрузка в конце окна занижена
                summary["tail_gaps_s"] = {str(c): s for c, s in sorted(gaps.items())}
                ctx.log.warning("ETW_TRACER: у ядер %s нет данных в конце окна (буферы логгера не сброшены)",
                                ", ".join(f"{c} (-{s} с)" for c, s in sorted(gaps.items())))
        summary["raw"] = parsed
        return summary
