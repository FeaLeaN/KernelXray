"""Сетевые пробы: расширенные настройки сетевых карт."""
from __future__ import annotations

from ..core.context import SessionContext
from ..core.probe import SnapshotProbe
from ..core.win import class_values, devices_of

NIC_KEYS = ["*InterruptModeration", "ITR", "*RSS", "*FlowControl", "*EEE", "EEELinkAdvertisement", "AdvancedEEE",
            "EnableGreenEthernet", "GigaLite", "PowerSavingMode", "*JumboPacket", "*SpeedDuplex",
            "*ReceiveBuffers", "*TransmitBuffers", "*LsoV2IPv4", "*LsoV2IPv6", "*WakeOnMagicPacket",
            "*SelectiveSuspend", "*DeviceSleepOnDisconnect"]


class NetworkEliteProbe(SnapshotProbe):
    name = "NETWORK_ELITE"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        adapters = []
        for d in devices_of("net"):
            v = class_values(d["driver_key"])
            settings = {k: v.get(k) for k in NIC_KEYS if v.get(k) is not None}
            adapters.append({
                "name": d["name"],
                "wireless": any(w in (d["name"] or "").lower() for w in ("wi-fi", "wifi", "wireless", "802.11")),
                "msi_supported": d["msi_supported"],
                "settings": settings,
                "power_saving_features_on": [k for k in ("*EEE", "EEELinkAdvertisement", "AdvancedEEE",
                                                         "EnableGreenEthernet", "GigaLite", "PowerSavingMode")
                                             if str(settings.get(k, "0")) not in ("0", "")],
                "interrupt_moderation": settings.get("*InterruptModeration"),
            })
        return {"adapters": adapters}
