"""Пробы настроек ОС: электропитание, планировщик, фоновые функции, службы."""
from __future__ import annotations

from ..core.context import SessionContext
from ..core.probe import SnapshotProbe
from ..core.win import (HKCU, HKLM, active_power_scheme, as_int, drivers, powercfg_ac_dc, reg_get, reg_values,
                        services)

MM_PROFILE = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"


def decode_priority_separation(v: int | None) -> dict | None:
    if v is None:
        return None
    return {
        "raw": v,
        "hex": hex(v),
        "quantum": {0: "default", 1: "long", 2: "short"}.get((v >> 4) & 3, "default"),
        "quantum_type": {0: "default", 1: "variable", 2: "fixed"}.get((v >> 2) & 3, "default"),
        "foreground_boost": {0: "1:1", 1: "2:1", 2: "3:1"}.get(v & 3, "3:1"),
        "is_default": v == 2,
    }


class OsConfigProbe(SnapshotProbe):
    name = "OS_CONFIG"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        cpmin = powercfg_ac_dc("SUB_PROCESSOR", "CPMINCORES")
        thr = powercfg_ac_dc("SUB_PROCESSOR", "PROCTHROTTLEMIN")
        boost = powercfg_ac_dc("SUB_PROCESSOR", "PERFBOOSTMODE")
        games = reg_values(HKLM, MM_PROFILE + r"\Tasks\Games")
        mmcss = drivers().get("mmcss")       # в Windows 10/11 MMCSS — драйвер ядра, а не обычная служба
        gm = as_int(reg_get(HKCU, r"Software\Microsoft\GameBar", "AutoGameModeEnabled"))
        return {
            "power_plan": active_power_scheme(),
            "core_parking_min_cores_percent_ac": cpmin[0],
            "min_processor_state_percent_ac": thr[0],
            "boost_mode_ac": boost[0],
            "game_mode": "off" if gm == 0 else "on",           # отсутствие ключа = включён по умолчанию
            "auto_game_mode_enabled": gm,                       # как есть в реестре (None = ключа нет)
            "win32_priority_separation": decode_priority_separation(
                as_int(reg_get(HKLM, r"SYSTEM\CurrentControlSet\Control\PriorityControl", "Win32PrioritySeparation"))),
            "system_responsiveness": as_int(reg_get(HKLM, MM_PROFILE, "SystemResponsiveness")),
            "network_throttling_index": as_int(reg_get(HKLM, MM_PROFILE, "NetworkThrottlingIndex")),
            "mmcss_games_task": {k: games.get(k) for k in ("GPU Priority", "Priority", "Scheduling Category",
                                                           "SFIO Priority")},
            "mmcss_service": mmcss["state"] if mmcss else None,
            "fullscreen_optimizations_disabled_globally": as_int(
                reg_get(HKCU, r"System\GameConfigStore", "GameDVR_FSEBehaviorMode")) == 2,
        }


class OsEntropyProbe(SnapshotProbe):
    """Фоновые функции Windows, которые что-то делают, пока ты играешь."""
    name = "OS_ENTROPY"
    timeout_s = 10.0

    def collect(self, ctx: SessionContext) -> dict:
        dvr_key = r"Software\Microsoft\Windows\CurrentVersion\GameDVR"
        run_keys = [
            (HKCU, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (HKLM, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
            (HKLM, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"),
        ]
        startup = sorted({name for hive, key in run_keys for name in reg_values(hive, key)})
        return {
            "game_dvr_enabled": as_int(reg_get(HKCU, r"System\GameConfigStore", "GameDVR_Enabled")),
            "app_capture_enabled": as_int(reg_get(HKCU, dvr_key, "AppCaptureEnabled")),
            "background_recording": as_int(reg_get(HKCU, dvr_key, "HistoricalCaptureEnabled")),
            "game_dvr_policy": as_int(reg_get(HKLM, r"SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR")),
            "telemetry_policy": as_int(reg_get(HKLM, r"SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                                               "AllowTelemetry")),
            "background_apps_disabled": as_int(reg_get(
                HKCU, r"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications", "GlobalUserDisabled")),
            "startup_items": startup,
            "startup_count": len(startup),
        }


# Не «мусор», а службы с заметной фоновой активностью. Безопасность (Defender, firewall) сюда не входит.
WATCHED_SERVICES = {
    "SysMain": "предзагрузка приложений в память (фоновые диск и память)",
    "WSearch": "индексирование файлов (фоновый диск)",
    "DiagTrack": "телеметрия",
    "dmwappushservice": "маршрутизация push-сообщений телеметрии",
    "MapsBroker": "загрузка офлайн-карт",
    "Spooler": "печать",
    "WerSvc": "отчёты об ошибках",
    "PcaSvc": "помощник совместимости программ",
}


class ServicesBloatProbe(SnapshotProbe):
    name = "SERVICES_BLOAT"
    timeout_s = 10.0

    def collect(self, ctx: SessionContext) -> dict:
        svc = services()
        watched = {}
        for name, why in WATCHED_SERVICES.items():
            s = svc.get(name.lower())
            watched[name] = {"state": s["state"] if s else "absent", "start": s["start"] if s else None, "what": why}
        return {
            "service_count_total": len(svc),
            "service_count_running": sum(1 for s in svc.values() if s["state"] == "running"),
            "watched": watched,
        }
