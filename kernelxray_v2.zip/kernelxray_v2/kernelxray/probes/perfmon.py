"""PERFMON: системные счётчики через PDH (pywin32).

Используем AddEnglishCounter: обычные пути счётчиков на русской Windows локализованы,
и английские имена там не находятся. English-API работает на любой локали.
"""
from __future__ import annotations

import threading
from datetime import datetime

from ..core.context import SessionContext
from ..core.probe import CaptureProbe, ProbeUnavailable
from ..parsers import perfmon as agg

COUNTERS = {
    "processor_queue_length": r"\System\Processor Queue Length",
    "context_switches_per_sec": r"\System\Context Switches/sec",
    "dpc_time_percent": r"\Processor(_Total)\% DPC Time",
    "interrupt_time_percent": r"\Processor(_Total)\% Interrupt Time",
    "interrupts_per_sec": r"\Processor(_Total)\Interrupts/sec",
    "cpu_usage_percent": r"\Processor(_Total)\% Processor Time",
    "disk_queue_depth": r"\PhysicalDisk(_Total)\Current Disk Queue Length",
    "disk_transfers_per_sec": r"\PhysicalDisk(_Total)\Disk Transfers/sec",
    "page_reads_per_sec": r"\Memory\Page Reads/sec",
    "pages_input_per_sec": r"\Memory\Pages Input/sec",
    "available_mbytes": r"\Memory\Available MBytes",
}
PER_CORE = {
    "interrupts": r"\Processor Information(*)\Interrupts/sec",
    "dpc_time": r"\Processor Information(*)\% DPC Time",
}
INTERVAL_S = 1.0


class PerfmonProbe(CaptureProbe):
    name = "PERFMON_ELITE"

    def prepare(self, ctx: SessionContext) -> None:
        try:
            import win32pdh  # noqa: F401
        except ImportError as exc:
            raise ProbeUnavailable("нужен pywin32: pip install pywin32") from exc
        self.samples: list[dict] = []
        self.skipped: list[str] = []
        self._stop = threading.Event()

    def start(self, ctx: SessionContext) -> None:
        self._thread = threading.Thread(target=self._loop, args=(ctx,), daemon=True, name="perfmon")
        self._thread.start()

    def stop(self, ctx: SessionContext) -> None:
        self._stop.set()
        self._thread.join(timeout=5)

    def analyze(self, ctx: SessionContext) -> dict:
        agg.write_csv(ctx.out_dir / "perfmon_raw_data.csv", self.samples)
        out = agg.aggregate(self.samples)
        if self.skipped:
            out["skipped_counters"] = self.skipped
        return out

    # ------------------------------------------------------------------
    def _loop(self, ctx: SessionContext) -> None:
        import win32pdh

        q = win32pdh.OpenQuery()
        handles, core_handles = {}, {}
        try:
            for key, path in COUNTERS.items():
                try:
                    handles[key] = win32pdh.AddEnglishCounter(q, path)
                except win32pdh.error:
                    self.skipped.append(path)
            for key, path in PER_CORE.items():
                try:
                    core_handles[key] = win32pdh.AddEnglishCounter(q, path)
                except win32pdh.error:
                    self.skipped.append(path)

            win32pdh.CollectQueryData(q)          # первый сбор: базовая точка для rate-счётчиков
            while not self._stop.wait(INTERVAL_S):
                win32pdh.CollectQueryData(q)
                s: dict = {"timestamp": datetime.now().astimezone().isoformat()}
                for key, h in handles.items():
                    try:
                        _, s[key] = win32pdh.GetFormattedCounterValue(h, win32pdh.PDH_FMT_DOUBLE)
                    except win32pdh.error:
                        s[key] = None
                s.update(self._per_core(win32pdh, core_handles))
                self.samples.append(s)
        except Exception as exc:  # поток не должен тихо умирать
            ctx.log.error("perfmon sampler crashed: %s", exc)
        finally:
            win32pdh.CloseQuery(q)

    @staticmethod
    def _per_core(win32pdh, core_handles: dict) -> dict:
        res = {"max_core_interrupts_per_sec": None, "max_core_interrupt_name": None, "max_core_dpc_time_percent": None}
        for key, h in core_handles.items():
            try:
                values = win32pdh.GetFormattedCounterArray(h, win32pdh.PDH_FMT_DOUBLE)
            except win32pdh.error:
                continue
            cores = {name: v for name, v in values.items() if "_Total" not in name}
            if not cores:
                continue
            name, v = max(cores.items(), key=lambda kv: kv[1])
            if key == "interrupts":
                res["max_core_interrupts_per_sec"] = round(v)
                res["max_core_interrupt_name"] = name     # формат "NUMA,ядро", например "0,6"
            else:
                res["max_core_dpc_time_percent"] = round(v, 2)
        return res
