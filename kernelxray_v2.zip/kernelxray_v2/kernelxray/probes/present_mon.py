"""PRESENT_MON: тайминги кадров через PresentMon 2.x (MIT, github.com/GameTechDev/PresentMon).

Как устроен захват, чтобы он работал с любой игрой:
  * PresentMon пишет кадры ВСЕХ процессов (без --process_name). Какой процесс игра, решает
    парсер уже после захвата, по самим кадрам. Имя exe заранее знать не нужно, а -p/--process
    остаётся только подсказкой.
  * CSV идёт в stdout PresentMon (--output_stdout), а файл открывает сам Python. Поэтому путь
    с кириллицей, пробелами или в OneDrive не может сломать запись, и файл существует всегда.
  * stderr PresentMon сохраняется в present_mon_console.log: если что-то пошло не так,
    в отчёте будет его собственный текст ошибки, а не догадка.

Защита от сбоя «PresentMon теряет все события» (github.com/GameTechDev/PresentMon/issues/423):
  * У каждой сессии уникальное имя (KernelXray_PM_<pid>_<n>), зависшие KernelXray_* гасятся
    перед запуском и перед повторной попыткой.
  * Если предпроверка видит сбой, она один раз чистит сессии и проверяет снова.
  * Если сбой остаётся (или кадры не пошли за FIRST_FRAME_TIMEOUT_S уже во время захвата),
    проба переходит в режим ETL: события пишет в файл сессия xperf, а PresentMon разбирает
    этот файл после захвата (--etl_file). Сбой 423 бьёт по доставке событий в реальном времени,
    файловая сессия её не использует.
  * Режим ETL можно включить и сразу: ключ --frames-etl.

Режим --arm (игры с EA AntiCheat, например Battlefield 6): после старта античита StartTrace падает
с ACCESS_DENIED, а EnableTraceEx2 в уже созданной сессии работает (PresentMon issue #573).
Поэтому пустая сессия создаётся до запуска игры (arm), а провайдеры включаются только в момент
захвата (start). Всё через ETW API напрямую (core/etw.py): `logman update -p` античит отклоняет.
"""
from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from pathlib import Path

from ..core.context import SessionContext
from ..core.etw import ERROR_ACCESS_DENIED, EtwError, FileSession, resolve_provider_guid
from ..core.probe import CaptureProbe, ProbeUnavailable
from ..core.win import processes
from ..core.tools import (OWN_SESSION_PREFIX, WPT_DIRS, app_dir, etw_block_hint, find_tool, list_etw_sessions,
                          run_tool, stop_etw_session, stop_own_etw_sessions)
from ..parsers.presentmon import count_frames, decode_console_bytes, parse_presentmon_csv

PREFLIGHT_S = 2           # пробный запуск до обратного отсчёта
LOST_HINT = ("Это известный сбой PresentMon/Windows (github.com/GameTechDev/PresentMon/issues/423): "
             "PresentMon время от времени начинает терять все события; сбой может пройти сам или после перезагрузки.")
STARTUP_CHECK_S = 1.5     # столько ждём после запуска, чтобы поймать мгновенное падение PresentMon
TIMED_MARGIN_S = 5        # PresentMon стартует раньше остальных проб: запас, чтобы он перекрыл всё окно
EXIT_WAIT_S = 60          # сколько ждать, пока PresentMon сам допишет CSV и закроет свою ETW-сессию
FIRST_FRAME_TIMEOUT_S = 8.0   # нет ни одного кадра за это время -> сессия реального времени считается мёртвой
MAX_REALTIME_ATTEMPTS = 2     # попыток реального времени, если xperf нет и перейти в ETL нельзя
WATCH_PERIOD_S = 0.5

# Провайдеры для режима ETL. Keywords подобраны по статистике реального захвата BF6 (xperf -a tracestats):
# оставлены биты событий, которые разбирает PresentMon (Present/Flip/IndependentFlip/MMIOFlip*/PresentHistory*/
# VSyncDPC*/QueuePacket/DmaPacket/Context/Device/HwQueue/AdapterAllocation, DXGI Present, Win32k Token*/ввод),
# и выброшены самые шумные группы, которых среди них нет:
#   DxgKrnl 0x2 Profiler/NotifyDpcCB/NotifyInterruptCB (~3,6 млн событий за 30 с, больше половины файла),
#   DxgKrnl 0x200 RuntimePowerManagement (~0,5 млн), Win32k UserCrit (~0,6 млн), DXGI IDXGISwapChain_* (~0,2 млн).
# Биты каналов (0x4000..., 0x8000...) в маску не входят: с ними под «любой из битов» попадало бы всё подряд.
# Если кадров станет меньше, чем с полным набором (--frames-full), значит, срезано нужное.
# Свой список: tools\presentmon_etl_providers.txt (одна строка = Провайдер:Keywords:Level, # = комментарий).
DEFAULT_ETL_PROVIDERS = [
    "Microsoft-Windows-DxgKrnl:0x08000841:5",
    "Microsoft-Windows-DXGI:0x2:5",
    "Microsoft-Windows-D3D9:0xFFFFFFFFFFFFFFFF:5",
    "Microsoft-Windows-Dwm-Core:0xFFFFFFFFFFFFFFFF:5",
    "Microsoft-Windows-Win32k:0x40001000:4",
]
FULL_ETL_PROVIDERS = [
    "Microsoft-Windows-DxgKrnl:0xFFFFFFFFFFFFFFFF:5",
    "Microsoft-Windows-DXGI:0xFFFFFFFFFFFFFFFF:5",
    "Microsoft-Windows-D3D9:0xFFFFFFFFFFFFFFFF:5",
    "Microsoft-Windows-Dwm-Core:0xFFFFFFFFFFFFFFFF:5",
    "Microsoft-Windows-Win32k:0xFFFFFFFFFFFFFFFF:4",
]
ETL_PROVIDERS_FILE = "presentmon_etl_providers.txt"


def _session(kind: str, n: int) -> str:
    return f"{OWN_SESSION_PREFIX}{kind}_{os.getpid()}_{n}"


def _lost_events(text: str) -> int:
    m = re.search(r"(\d+) ETW events were lost", text)
    return int(m.group(1)) if m else 0


def _etl_providers(full: bool = False) -> tuple[list[str], str]:
    if full:
        return FULL_ETL_PROVIDERS, "полный список (--frames-full)"
    custom = app_dir() / "tools" / ETL_PROVIDERS_FILE
    if custom.exists():
        lines = [ln.split("#", 1)[0].strip() for ln in custom.read_text(encoding="utf-8-sig").splitlines()]
        specs = [ln for ln in lines if ln]
        if specs:
            return specs, custom.name
    return DEFAULT_ETL_PROVIDERS, "встроенный список"


def _same_image(a: str, b: str) -> bool:
    """Одно и то же имя образа (регистр и обрезка длинных имён не в счёт)."""
    a, b = a.strip().lower(), b.strip().lower()
    return a == b or a.startswith(b) or b.startswith(a)


def postprocess_etl_csv(path: Path, pid_names: dict[int, str], window_ms: tuple[float, float] | None) -> dict:
    """CSV из --etl_file: имена по PID (снимок процессов в конце захвата) и обрезка по окну.

    Имя берётся из снимка не только вместо <unknown>, но и когда PresentMon назвал живой процесс иначе.
    PID переиспользуются: если за время ожидания F9 успел запуститься и закрыться, скажем, ping.exe, а потом
    игра получила тот же PID, PresentMon оставляет первое имя, и игра в отчёте становилась «PING.EXE».
    Снимок сделан, пока игра ещё идёт, поэтому для живых процессов он точнее.

    В режиме --arm сессия пишет и то, что было после окна: остановку остальных проб (слияние .etl, rundown
    DxgKrnl), от которой игра может подтормаживать. Эти кадры к окну захвата не относятся."""
    text = decode_console_bytes(path.read_bytes()).lstrip("\ufeff")
    start = text.find("Application,")
    if start < 0:
        return {"renamed": 0, "trimmed": 0}
    lines = text[start:].splitlines()
    cols = lines[0].split(",")
    i_pid, i_time = cols.index("ProcessID"), cols.index("TimeInMs") if "TimeInMs" in cols else None
    if window_ms and i_time is not None:
        # Страховка: если окно отсекает больше половины кадров, отсчёт TimeInMs не тот, что мы думали —
        # тогда не режем вовсе, лучше лишние кадры остановки, чем пустой результат.
        times = []
        for ln in lines[1:]:
            f = ln.split(",")
            try:
                times.append(float(f[i_time]))
            except (IndexError, ValueError):
                pass
        inside = sum(window_ms[0] <= t <= window_ms[1] for t in times)
        if times and inside < len(times) / 2:
            window_ms = None
    out, renamed, trimmed = [lines[0]], 0, 0
    fixes: dict[str, int] = {}
    for ln in lines[1:]:
        f = ln.split(",")
        if len(f) != len(cols):
            continue
        if window_ms and i_time is not None:
            try:
                t = float(f[i_time])
            except ValueError:
                t = None
            if t is not None and not (window_ms[0] <= t <= window_ms[1]):
                trimmed += 1
                continue
        if f[0] == "<unknown>":
            try:
                name = pid_names.get(int(f[i_pid]))
            except ValueError:
                name = None
            if not name:
                # Имени нет ни в трассе, ни в списке процессов (процесс уже закрыт): подписываем PID, чтобы кадры
                # не отбросились как «<unknown>» и игра всё равно выбралась по самим кадрам.
                name = f"pid {f[i_pid]}"
            f[0] = name
            renamed += 1
        else:
            try:
                live = pid_names.get(int(f[i_pid]))
            except ValueError:
                live = None
            if live and not _same_image(f[0], live):
                key = f"{f[0]} -> {live}"
                fixes[key] = fixes.get(key, 0) + 1
                f[0] = live
        out.append(",".join(f))
    path.write_text("\n".join(out) + "\n", encoding="utf-8-sig", newline="")
    res = {"renamed": renamed, "trimmed": trimmed}
    if fixes:
        res["name_fixes"] = fixes
    return res


def merge_csv_parts(parts: list[Path], out: Path) -> None:
    """Склеивает CSV нескольких попыток. Повторные заголовки и оборванные строки парсер пропускает сам."""
    chunks = []
    for p in parts:
        if p.exists():
            text = decode_console_bytes(p.read_bytes()).lstrip("\ufeff")
            if text.strip():
                chunks.append(text if text.endswith("\n") else text + "\n")
    out.write_text("".join(chunks), encoding="utf-8-sig", newline="")


def _split_spec(spec: str) -> list[str]:
    """"Провайдер:Keywords:Level" -> ["Провайдер", "Keywords", "Level"] для logman -p."""
    name, *rest = spec.split(":")
    return [name, *rest[:2]]


class PresentMonProbe(CaptureProbe):
    name = "PRESENT_MON"
    analyze_timeout_s = 120.0
    armable = True

    # --- предпроверка -------------------------------------------------------
    def preflight(self, ctx: SessionContext) -> None:
        """Пробный захват на пару секунд. Если PresentMon теряет события, чистим сессии и пробуем ещё раз;
        не помогло — заранее переключаем захват в режим ETL."""
        exe = find_tool(["PresentMon*.exe"])
        if not exe:
            return
        if ctx.shared.get("presentmon_mode") == "etl":
            ctx.log.info("PresentMon: режим ETL (--arm), предпроверка пропущена")
            return
        print(f"  Проверка PresentMon ({PREFLIGHT_S} с)...", flush=True)
        check = self._check(ctx, exe, 1)
        if check is None:
            return
        # Список сессий пишем всегда: сравнение прогонов «сбой / без сбоя» подскажет, кто мешает PresentMon
        sessions = list_etw_sessions()
        check["etw_sessions"] = sessions
        ctx.log.info("ETW-сессии перед захватом (%s): %s", len(sessions) if sessions is not None else "?",
                     ", ".join(sessions or []) or "(не удалось получить)")
        if check["lost_events"] and not check["frames"]:
            stopped = stop_own_etw_sessions()
            ctx.log.warning("PresentMon теряет события ETW и не видит кадров (потеряно %d). Остановлены сессии: %s. "
                            "Проверяю ещё раз.", check["lost_events"], ", ".join(stopped) or "нет")
            check = {**check, **(self._check(ctx, exe, 2) or {})}
        ctx.shared["presentmon_preflight"] = check
        if check["lost_events"] and not check["frames"]:
            if find_tool(["xperf.exe"], WPT_DIRS):
                ctx.shared["presentmon_mode"] = "etl"
                ctx.log.warning("PresentMon в реальном времени теряет все события (сбой PresentMon/Windows, "
                                "github.com/GameTechDev/PresentMon/issues/423). Кадры будут записаны в файл через "
                                "xperf и разобраны после захвата.")
            else:
                ctx.log.warning("PresentMon теряет события ETW и не видит ни одного кадра: кадры в этом прогоне, "
                                "скорее всего, не захватятся. %s Обходной режим (запись в файл) требует xperf.",
                                LOST_HINT)

    def _check(self, ctx: SessionContext, exe: Path, n: int) -> dict | None:
        csv_path = ctx.out_dir / f"present_mon_check{n}.csv"
        err_path = ctx.out_dir / f"present_mon_check{n}_console.log"
        session = _session("PMCheck", n)
        cmd = [str(exe), "--output_stdout", "--no_console_stats", "--timed", str(PREFLIGHT_S), "--terminate_after_timed",
               "--session_name", session, "--stop_existing_session"]
        try:
            with open(csv_path, "wb") as out, open(err_path, "wb") as err:
                subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=PREFLIGHT_S + 20,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except subprocess.TimeoutExpired:
            stop_etw_session(session)
            ctx.log.warning("Пробный запуск PresentMon завис и был остановлен")
            return None
        frames = count_frames(csv_path)
        console = " ".join(decode_console_bytes(err_path.read_bytes()).split())
        if not ctx.keep_raw:
            csv_path.unlink(missing_ok=True)
            err_path.unlink(missing_ok=True)
        return {"attempt": n, "frames": frames, "lost_events": _lost_events(console), "console": console[-300:]}

    # --- захват -------------------------------------------------------------
    def prepare(self, ctx: SessionContext) -> None:
        self.exe = find_tool(["PresentMon*.exe"])
        if not self.exe:
            raise ProbeUnavailable("PresentMon не найден: положи PresentMon-2.x-x64.exe в папку tools/")
        self.xperf = find_tool(["xperf.exe"], WPT_DIRS)
        if ctx.shared.get("presentmon_mode") == "etl" and not self.xperf:
            raise ProbeUnavailable("режим ETL для кадров требует xperf.exe (Windows Performance Toolkit)")
        self.csv = ctx.out_dir / "present_mon_raw_data.csv"
        self.console_log = ctx.out_dir / "present_mon_console.log"
        self.frames_etl = ctx.out_dir / "present_mon_frames.etl"
        self.proc: subprocess.Popen | None = None
        self.returncode = None
        self.killed = False
        self.cmd: list[str] = []
        self.parts: list[Path] = []           # CSV попыток реального времени
        self.console_parts: list[Path] = []
        self.segments: list[dict] = []        # что происходило: попытки, переходы, итоги
        self.etl_session: str | None = None
        self._lock = threading.Lock()
        self._stop_evt = threading.Event()
        self._watchdog: threading.Thread | None = None
        self._armed = False
        self._armed_providers: list[tuple[str, str, int, int]] = []
        self._providers_source = ""
        self._pid_names: dict[int, str] = {}
        self._window_ms: tuple[float, float] | None = None
        self._etl_left_running = False

    def arm(self, ctx: SessionContext) -> None:
        """Пустая файловая сессия без провайдеров: создаётся до запуска игры и ничего не пишет до start().
        GUID провайдеров выясняем тоже сейчас, пока античит не мешает."""
        specs, source = _etl_providers(bool(ctx.shared.get("frames_full")))
        self._armed_providers = []
        for spec in specs:
            name, *rest = spec.split(":")
            guid = resolve_provider_guid(name)
            if not guid:
                ctx.log.warning("PresentMon ETL: не найден GUID провайдера %s, пропускаю", name)
                continue
            keywords = int(rest[0], 0) if rest and rest[0] else 0xFFFFFFFFFFFFFFFF
            level = int(rest[1], 0) if len(rest) > 1 and rest[1] else 5
            self._armed_providers.append((name, guid, level, keywords))
        self._providers_source = source
        session = _session("PMFrames", 1)
        stop_etw_session(session)
        self.frames_etl.unlink(missing_ok=True)
        self._etw = FileSession(session, self.frames_etl, buffer_kb=1024, min_buf=64, max_buf=512, max_file_mb=2048)
        try:
            self._etw.start()
        except (EtwError, OSError) as exc:
            hint = etw_block_hint() if getattr(exc, "code", None) == ERROR_ACCESS_DENIED else None
            raise RuntimeError(f"сессия для кадров не создалась: {exc}" + (f" {hint}" if hint else "")) from exc
        self._arm_mono = time.monotonic()        # время 0 для TimeInMs в CSV из этого .etl
        self.etl_session = session
        self._armed = True
        self.analyze_timeout_s = 900.0
        ctx.log.info("PresentMon ETL (--arm): пустая сессия %s создана, провайдеров к включению: %d (%s)",
                     session, len(self._armed_providers), source)

    def _enable_armed(self, ctx: SessionContext) -> None:
        """Включает провайдеры в заранее созданной сессии одним вызовом EnableTraceEx2 на провайдер."""
        errors = []
        for name, guid, level, keywords in self._armed_providers:
            try:
                self._etw.enable(guid, level, keywords)
            except EtwError as exc:
                errors.append(f"{name}: {exc}")
        self.segments.append({"mode": "etl", "session": self.etl_session, "providers": self._providers_source,
                              "armed": True, "start_s": 0.0, "enable_errors": errors})
        for e in errors:
            ctx.log.warning("PresentMon ETL: провайдер не включился: %s", e)
        ok = len(self._armed_providers) - len(errors)
        ctx.log.info("PresentMon ETL (--arm): провайдеры включены (%d из %d)", ok, len(self._armed_providers))
        if ok == 0:
            raise RuntimeError("ни один провайдер кадров не включился: " + "; ".join(errors))
        # Rundown DxgKrnl СРАЗУ после включения: события Context/Device/HwQueue/Adapter DCStart связывают
        # пакеты GPU с процессом. Без них в начале файла PresentMon не может посчитать GPU busy/wait/latency
        # (в CSV были нули). Окно захвата открывается после этого, так что сам rundown в него не попадает.
        dxg = next((g for n, g, *_ in self._armed_providers if n.lower() == "microsoft-windows-dxgkrnl"), None)
        if dxg:
            rc = self._etw.capture_state(dxg)
            ctx.log.info("PresentMon ETL (--arm): rundown DxgKrnl в начале: код %s", rc)

    def start(self, ctx: SessionContext) -> None:
        self._t0 = time.monotonic()
        self._deadline = self._t0 + ctx.duration_s + TIMED_MARGIN_S
        if self._armed:
            self._enable_armed(ctx)
            begin = self._t0 - self._arm_mono
            self._window_ms = (begin * 1000, (begin + ctx.duration_s) * 1000)
            return
        if ctx.shared.get("presentmon_mode") == "etl":
            self._start_etl(ctx)
            return
        self._start_realtime(ctx, 1, fail_hard=True)
        self._watchdog = threading.Thread(target=self._watch, args=(ctx,), name="PRESENT_MON_watchdog", daemon=True)
        self._watchdog.start()

    def _start_realtime(self, ctx: SessionContext, n: int, fail_hard: bool) -> None:
        session = _session("PM", n)
        part = ctx.out_dir / f"present_mon_part{n}.csv"
        console = ctx.out_dir / f"present_mon_part{n}_console.log"
        timed = max(3, int(self._deadline - time.monotonic() + 0.999))
        cmd = [
            str(self.exe),
            "--output_stdout",                 # CSV в stdout -> в файл, который открыл Python
            "--no_console_stats",
            "--timed", str(timed),
            "--terminate_after_timed",
            "--session_name", session,
            "--stop_existing_session",
        ]
        # Намеренно без --process_name: фильтр по имени — главная причина «0 кадров»
        # (r5apex.exe vs r5apex_dx12.exe, лаунчеры, EAC-обёртки). Игра выбирается при анализе.
        out, err = open(part, "wb"), open(console, "wb")
        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError:
            out.close()
            err.close()
            raise
        with self._lock:
            self.proc, self._out, self._err, self.killed = proc, out, err, False
            self.cmd = cmd
            self.parts.append(part)
            self.console_parts.append(console)
            self.segments.append({"mode": "realtime", "attempt": n, "session": session,
                                  "start_s": round(time.monotonic() - self._t0, 1)})
        ctx.shared.setdefault("child_pids", set()).add(proc.pid)
        ctx.log.info("PresentMon cmd: %s", subprocess.list2cmdline(cmd))

        # Если сессия не поднялась (нет прав, конфликт имени, ошибка аргументов), PresentMon выходит сразу.
        deadline = time.monotonic() + STARTUP_CHECK_S
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                self._finish_realtime(ctx, "exited_at_start")
                msg = (f"PresentMon завершился при старте (код {proc.returncode}): "
                       f"{self._tail(console) or 'без сообщения'}")
                if "access denied" in msg.lower() and (hint := etw_block_hint()):
                    msg = f"{msg} {hint}"
                if fail_hard:
                    raise RuntimeError(msg)
                ctx.log.warning(msg)
                return
            time.sleep(0.1)

    def _watch(self, ctx: SessionContext) -> None:
        """Сторож: если кадры не пошли за FIRST_FRAME_TIMEOUT_S, сессия реального времени мертва —
        гасим её и переходим в ETL (или пробуем новую сессию, если xperf нет)."""
        try:
            while not self._stop_evt.wait(WATCH_PERIOD_S):
                with self._lock:
                    proc, part, seg = self.proc, self.parts[-1], self.segments[-1]
                if proc is None:
                    return
                if count_frames(part) > 0:
                    return                              # кадры идут: дальше PresentMon справится сам
                started = self._t0 + seg["start_s"]
                if proc.poll() is None and time.monotonic() - started < FIRST_FRAME_TIMEOUT_S:
                    continue
                if time.monotonic() > self._deadline - 3:
                    return                              # окно почти кончилось, перезапуск ничего не даст
                self._kill_current(ctx)
                self._finish_realtime(ctx, "no_frames")
                if self._stop_evt.is_set():
                    return
                if self.xperf:
                    ctx.log.warning("PresentMon за %.0f с не получил ни одного кадра. Перехожу на запись "
                                    "событий в файл (xperf) до конца захвата.", FIRST_FRAME_TIMEOUT_S)
                    self._start_etl(ctx)
                    return
                n = seg["attempt"] + 1
                if n > MAX_REALTIME_ATTEMPTS:
                    ctx.log.warning("PresentMon не получил кадров за %d попытки. %s", n - 1, LOST_HINT)
                    return
                stopped = stop_own_etw_sessions()
                ctx.log.warning("PresentMon без кадров, перезапуск с новой сессией. Остановлены: %s. "
                                "ETW-сессии в системе: %s", ", ".join(stopped) or "нет",
                                ", ".join(list_etw_sessions() or []) or "(не удалось получить)")
                self._start_realtime(ctx, n, fail_hard=False)
        except Exception as exc:                        # сторож не должен ронять захват
            ctx.log.error("PRESENT_MON watchdog: %s: %s", type(exc).__name__, exc)

    def _start_etl(self, ctx: SessionContext) -> None:
        specs, source = _etl_providers(bool(ctx.shared.get("frames_full")))
        self.analyze_timeout_s = 900.0       # merge + разбор .etl дольше, чем чтение готового CSV
        session = _session("PMFrames", 1)
        stop_etw_session(session)
        self.frames_etl.unlink(missing_ok=True)
        cmd = [self.xperf, "-start", session, "-on", "+".join(specs), "-f", self.frames_etl,
               "-BufferSize", "1024", "-MinBuffers", "64", "-MaxBuffers", "512",
               "-FileMode", "Sequential", "-MaxFile", "2048"]
        try:
            run_tool(cmd, timeout=30)
        except RuntimeError as exc:
            ctx.log.error("PresentMon ETL: сессия xperf не стартовала: %s", exc)
            self.segments.append({"mode": "etl", "session": session, "outcome": "start_failed", "error": str(exc)})
            return
        self.etl_session = session
        self.segments.append({"mode": "etl", "session": session, "providers": source,
                              "start_s": round(time.monotonic() - self._t0, 1)})
        # rundown DxgKrnl в начале файла: без него PresentMon не считает GPU-метрики (см. _enable_armed)
        run_tool([self.xperf, "-capturestate", session, "Microsoft-Windows-DxgKrnl"], timeout=30, check=False)
        ctx.log.info("PresentMon ETL: %s", subprocess.list2cmdline([str(c) for c in cmd]))

    def stop(self, ctx: SessionContext) -> None:
        self._stop_evt.set()
        if self._watchdog:
            self._watchdog.join(20)
        with self._lock:
            proc = self.proc
        if proc is not None:
            if ctx.interrupted.is_set() and proc.poll() is None:
                self._kill_current(ctx)
            try:
                proc.wait(timeout=EXIT_WAIT_S)
            except subprocess.TimeoutExpired:
                ctx.log.warning("PresentMon не завершился за %s с, принудительно останавливаю", EXIT_WAIT_S)
                self._kill_current(ctx)
                proc.wait()
            self._finish_realtime(ctx, "killed" if self.killed else "done")
        if self.etl_session:
            # rundown DxgKrnl (устройства, контексты) перед остановкой; не критично, если не выйдет
            if self._armed:
                try:                                  # игра ещё идёт: PID -> имя для кадров <unknown>
                    processes.cache_clear()           # processes() кэширован со снимка до запуска игры
                    self._pid_names = {p["pid"]: p["name"] for p in processes() if p.get("pid")}
                    processes.cache_clear()
                except Exception as exc:
                    ctx.log.warning("PresentMon ETL: список процессов не получен: %s", exc)
                dxg = next((g for n, g, *_ in self._armed_providers if n.lower() == "microsoft-windows-dxgkrnl"), None)
                if dxg:
                    self._etw.capture_state(dxg)
                # сначала выключаем провайдеры: это античит разрешает, и файл перестаёт расти, даже если
                # саму сессию остановить не дадут
                for _, guid, *_ in self._armed_providers:
                    self._etw.disable(guid)
                rc, lost = self._etw.stop()
                ctx.log.info("PresentMon ETL (--arm): остановка сессии: код %s, потеряно событий %s", rc, lost)
                if rc != 0 and not stop_etw_session(self.etl_session)[0]:
                    self._etl_left_running = True
                    ctx.log.warning("Сессия %s осталась открытой (античит не дал её закрыть), провайдеры выключены, "
                                    "запись не идёт. Она закроется при следующем запуске KernelXray без игры или "
                                    "после перезагрузки.", self.etl_session)
            else:
                run_tool([self.xperf, "-capturestate", self.etl_session, "Microsoft-Windows-DxgKrnl"],
                         timeout=30, check=False)
                r = run_tool([self.xperf, "-stop", self.etl_session], timeout=120, check=False)
                if r.returncode != 0:
                    stop_etw_session(self.etl_session)
            if not self.segments:        # --arm отменён до start(): сессия была, записи не было
                self.segments.append({"mode": "etl", "session": self.etl_session, "armed": True, "outcome": "cancelled"})
            self.segments[-1]["end_s"] = round(time.monotonic() - getattr(self, "_t0", time.monotonic()), 1)
            self.segments[-1]["etl_mb"] = (round(self.frames_etl.stat().st_size / 2**20, 1)
                                           if self.frames_etl.exists() else None)
            ctx.log.info("PresentMon ETL: сессия остановлена, файл %s МБ", self.segments[-1]["etl_mb"])

        merge_csv_parts(self.parts, self.csv)
        merge_csv_parts(self.console_parts, self.console_log)
        if not ctx.keep_raw:
            for p in self.parts + self.console_parts:
                p.unlink(missing_ok=True)
        ctx.log.info("PresentMon: попыток реального времени %d, режим ETL: %s, CSV %d байт",
                     sum(s["mode"] == "realtime" for s in self.segments), "да" if self.etl_session else "нет",
                     self.csv.stat().st_size)
        tail = self._tail(self.console_log)
        if tail:
            ctx.log.info("PresentMon console: %s", tail)
        if (not self.etl_session and self.returncode not in (0, None) and not self.killed
                and count_frames(self.csv) == 0):
            raise RuntimeError(f"PresentMon exit {self.returncode}: {tail or 'без сообщения'}")

    def analyze(self, ctx: SessionContext) -> dict:
        if self.etl_session:
            self._process_etl(ctx)
        out = parse_presentmon_csv(self.csv, ctx.target_process)
        console = self._tail(self.console_log)
        out["presentmon"] = {
            "exe": self.exe.name,
            "command": subprocess.list2cmdline([str(c) for c in self.cmd[1:]]),
            "mode": "etl" if self.etl_session else "realtime",
            "segments": self.segments,
            "exit_code": self.returncode,
            "killed": self.killed,
            "csv_bytes": self.csv.stat().st_size,
            "console": console,
            "preflight": ctx.shared.get("presentmon_preflight"),
        }
        lost = _lost_events(console)
        if lost:
            out["presentmon"]["lost_events"] = lost
        if not out.get("captured_frames") and lost:
            out["note"] = f"PresentMon потерял {lost} событий ETW и не собрал ни одного кадра. {LOST_HINT}"
        elif not out.get("captured_frames") and console:
            out["note"] = f'{out.get("note", "")} Сообщение PresentMon: {console}'.strip()
        switched = next((s for s in self.segments if s["mode"] == "etl"), None)
        if self.etl_session and switched and any(s["mode"] == "realtime" for s in self.segments):
            # переход случился посреди окна: начало захвата без кадров
            extra = (f"Первые {switched['start_s']:.0f} с захвата кадров нет: запись в файл включилась "
                     f"после сбоя PresentMon.")
            out["note"] = f'{out.get("note", "")} {extra}'.strip()
        return out

    def _process_etl(self, ctx: SessionContext) -> None:
        """Разбор .etl: слить с трассой ядра (имена процессов), прогнать PresentMon --etl_file, дописать в CSV."""
        if not self.frames_etl.exists():
            ctx.log.error("PresentMon ETL: файл %s не записался", self.frames_etl.name)
            return
        src = self.frames_etl
        kernel = (ctx.shared.get("etw") or {}).get("etl")
        merged = ctx.out_dir / "present_mon_merged.etl"
        if kernel and Path(kernel).exists():
            # В трассе ядра есть rundown процессов: без него PresentMon не знает имён уже запущенных игр.
            r = run_tool([self.xperf, "-merge", self.frames_etl, kernel, merged], timeout=300, check=False)
            if r.returncode == 0 and merged.exists():
                src = merged
            else:
                ctx.log.warning("PresentMon ETL: xperf -merge не удался (%s), имена процессов могут быть неизвестны",
                                (r.stderr or r.stdout or "").strip()[-200:])
        else:
            ctx.log.warning("PresentMon ETL: трассы ядра нет (ETW_TRACER выключен?), имена процессов могут быть "
                            "неизвестны")
        self._etl_stats(ctx)
        etl_csv = ctx.out_dir / "present_mon_etl.csv"
        etl_console = ctx.out_dir / "present_mon_etl_console.log"
        self.cmd = [str(self.exe), "--etl_file", str(src), "--output_stdout", "--no_console_stats"]
        with open(etl_csv, "wb") as out, open(etl_console, "wb") as err:
            r = subprocess.run(self.cmd, stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=600,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if self._armed:
            win = ctx.shared.get("window_mono")          # точное окно от раннера (после старта всех проб)
            if win:
                self._window_ms = ((win[0] - self._arm_mono) * 1000, (win[1] - self._arm_mono) * 1000)
            post = postprocess_etl_csv(etl_csv, self._pid_names, self._window_ms)
            if self._window_ms:
                post["window_ms"] = [round(x, 1) for x in self._window_ms]
                ctx.log.info("PresentMon ETL: окно в шкале .etl %.1f–%.1f мс", *self._window_ms)
            self.segments[-1].update(post)
            ctx.log.info("PresentMon ETL: имён восстановлено по PID %d, кадров вне окна захвата отброшено %d",
                         post["renamed"], post["trimmed"])
            for fix, n in (post.get("name_fixes") or {}).items():
                ctx.log.info("PresentMon ETL: имя процесса исправлено по живому PID (PID переиспользован): %s, "
                             "кадров %d", fix, n)
        frames = count_frames(etl_csv)
        ctx.log.info("PresentMon --etl_file: код %s, кадров %d%s", r.returncode, frames,
                     f", {self._tail(etl_console)}" if self._tail(etl_console) else "")
        self.segments[-1]["frames"] = frames
        self.returncode = r.returncode
        merge_csv_parts([self.csv, etl_csv], self.csv)
        merge_csv_parts([self.console_log, etl_console], self.console_log)
        if not ctx.keep_raw:
            for p in (etl_csv, etl_console, merged, self.frames_etl):
                try:
                    p.unlink(missing_ok=True)
                except OSError:              # файл держит сессия, которую античит не дал закрыть
                    ctx.log.info("PresentMon ETL: %s занят, не удалён", p.name)

    def _etl_stats(self, ctx: SessionContext) -> None:
        """Сколько событий дал каждый провайдер (xperf -a tracestats). Файл маленький и остаётся в папке
        отчёта: по нему видно, какой провайдер раздувает .etl и что можно урезать без потери кадров."""
        stats = ctx.out_dir / "present_mon_etl_stats.txt"
        for extra in (["-detail"], []):
            r = run_tool([self.xperf, "-i", self.frames_etl, "-o", stats, "-a", "tracestats", *extra],
                         timeout=300, check=False)
            if r.returncode == 0 and stats.exists():
                ctx.log.info("PresentMon ETL: статистика провайдеров -> %s", stats.name)
                return
        ctx.log.info("PresentMon ETL: xperf tracestats не сработал: %s", (r.stderr or r.stdout or "").strip()[-200:])

    # --- служебное ----------------------------------------------------------
    def _kill_current(self, ctx: SessionContext) -> None:
        """TerminateProcess не даёт PresentMon закрыть свою ETW-сессию, поэтому гасим её сами."""
        with self._lock:
            proc, seg = self.proc, self.segments[-1]
        if proc is None or proc.poll() is not None:
            return
        self.killed = True
        proc.kill()
        try:
            proc.wait(10)
        except subprocess.TimeoutExpired:
            ctx.log.error("PresentMon (pid %d) не завершился после kill", proc.pid)
        ok, out = stop_etw_session(seg["session"])
        ctx.log.info('logman stop "%s" -ets: %s', seg["session"], "stopped" if ok else out)

    def _finish_realtime(self, ctx: SessionContext, outcome: str) -> None:
        with self._lock:
            proc, seg = self.proc, self.segments[-1]
            if proc is None:
                return
            self.proc = None
            for f in (self._out, self._err):
                if not f.closed:
                    f.close()
        self.returncode = proc.poll()
        stop_etw_session(seg["session"])     # если PresentMon закрыл её сам, logman просто скажет «не найдена»
        seg.update(outcome=outcome, exit_code=self.returncode, end_s=round(time.monotonic() - self._t0, 1),
                   frames=count_frames(self.parts[-1]), lost_events=_lost_events(self._tail(self.console_parts[-1])))
        ctx.log.info("PresentMon попытка %d: %s, кадров %d, потеряно событий %d", seg["attempt"], outcome,
                     seg["frames"], seg["lost_events"])

    @staticmethod
    def _tail(path: Path, limit: int = 400) -> str:
        try:
            raw = path.read_bytes()
        except OSError:
            return ""
        return " ".join(decode_console_bytes(raw).split())[-limit:]
