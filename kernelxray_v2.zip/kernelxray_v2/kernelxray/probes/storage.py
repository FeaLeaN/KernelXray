"""Пробы накопителей: тип и шина дисков, TRIM, энергосбережение, контроллеры."""
from __future__ import annotations

import os
import re

from ..core.context import SessionContext
from ..core.probe import SnapshotProbe
from ..core.tools import run_tool
from ..core.win import HKLM, as_int, devices_of, powercfg_ac_dc, reg_values, wmi

MEDIA = {0: "unspecified", 3: "HDD", 4: "SSD", 5: "SCM"}
BUS = {1: "SCSI", 3: "ATA", 7: "USB", 8: "RAID", 10: "SAS", 11: "SATA", 12: "SD", 17: "NVMe"}
HEALTH = {0: "healthy", 1: "warning", 2: "unhealthy", 5: "unknown"}
STORAGE_NS = r"root\Microsoft\Windows\Storage"


class StorageEliteProbe(SnapshotProbe):
    name = "STORAGE_ELITE"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        disks = wmi("SELECT DeviceId, FriendlyName, MediaType, BusType, Size, HealthStatus FROM MSFT_PhysicalDisk",
                    STORAGE_NS)
        parts = wmi("SELECT DiskNumber, DriveLetter FROM MSFT_Partition", STORAGE_NS)
        sys_letter = os.environ.get("SystemDrive", "C:")[0].upper()
        sys_disk = None
        for p in parts:
            dl = p.get("DriveLetter")
            letter = chr(dl) if isinstance(dl, int) and dl else (str(dl or "").upper()[:1])
            if letter == sys_letter:
                sys_disk = str(p.get("DiskNumber"))
        out = []
        for d in disks:
            out.append({
                "disk": d.get("DeviceId"), "name": d.get("FriendlyName"),
                "media": MEDIA.get(d.get("MediaType"), d.get("MediaType")),
                "bus": BUS.get(d.get("BusType"), d.get("BusType")),
                "size_gb": round((as_int(d.get("Size")) or 0) / 1e9),
                "health": HEALTH.get(d.get("HealthStatus"), d.get("HealthStatus")),
                "system_disk": str(d.get("DeviceId")) == sys_disk,
            })
        system = next((d for d in out if d["system_disk"]), None)
        return {"disks": out, "system_disk": system}


class StorageGuideProbe(SnapshotProbe):
    name = "STORAGE_GUIDE"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        r = run_tool(["fsutil", "behavior", "query", "DisableDeleteNotify"], timeout=10, check=False)
        m = re.search(r"NTFS\s+DisableDeleteNotify\s*=\s*(\d)", r.stdout or "")
        la = run_tool(["fsutil", "behavior", "query", "disablelastaccess"], timeout=10, check=False)
        lm = re.search(r"=\s*(\d+)", la.stdout or "")
        idle = powercfg_ac_dc("SUB_DISK", "DISKIDLE")
        return {
            "trim_enabled": (m[1] == "0") if m else None,
            "last_access_updates": as_int(lm[1]) if lm else None,     # 0/2 = обновляются, 1/3 = нет
            "disk_idle_timeout_s_ac": idle[0],
            "controllers": [{"name": d["name"], "service": d["service"], "msi_supported": d["msi_supported"]}
                            for d in devices_of("storage") + devices_of("hdc")],
            "storport_overrides": reg_values(HKLM, r"SYSTEM\CurrentControlSet\Control\StorPort"),
            "stornvme_parameters": reg_values(HKLM, r"SYSTEM\CurrentControlSet\Services\stornvme\Parameters\Device"),
        }
