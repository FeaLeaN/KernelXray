"""Пробы железа и ядра: топология CPU, инвентарь, прошивка, таймеры, память, процессы."""
from __future__ import annotations

import ctypes
import functools
import os
import platform
import re
import struct
import time

from ..core.context import SessionContext
from ..core.probe import SnapshotProbe
from ..core.win import (HKLM, age_days, as_int, bcd_current, drivers, parse_us_date, processes, reg_get,
                        reg_values, services, wmi)
from ..parsers.stats import mean, percentile, r

KERNEL_KEY = r"SYSTEM\CurrentControlSet\Control\Session Manager\kernel"
MM_KEY = r"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"


@functools.lru_cache(maxsize=1)
def memory_modules() -> list[dict]:
    return wmi("SELECT Capacity, Speed, ConfiguredClockSpeed, Manufacturer, PartNumber, SMBIOSMemoryType, "
               "DeviceLocator FROM Win32_PhysicalMemory")


# ---------------------------------------------------------------------------
class CpuTopologyProbe(SnapshotProbe):
    name = "CPU_TOPOLOGY"

    def collect(self, ctx: SessionContext) -> dict:
        k32 = ctypes.windll.kernel32
        size = ctypes.c_ulong(0)
        k32.GetLogicalProcessorInformationEx(0xFFFF, None, ctypes.byref(size))
        buf = ctypes.create_string_buffer(size.value)
        if not k32.GetLogicalProcessorInformationEx(0xFFFF, buf, ctypes.byref(size)):
            raise ctypes.WinError()
        raw = buf.raw[: size.value]

        cores, l3_caches, packages, numa = [], [], 0, 0
        off = 0
        while off < len(raw):
            rel, sz = struct.unpack_from("<II", raw, off)
            body = off + 8
            if rel == 0:                       # RelationProcessorCore
                flags, eff = raw[body], raw[body + 1]
                groups = struct.unpack_from("<H", raw, body + 22)[0]
                threads = 0
                for g in range(groups):
                    mask = struct.unpack_from("<Q", raw, body + 24 + g * 16)[0]
                    threads += bin(mask).count("1")
                cores.append({"efficiency_class": eff, "smt": bool(flags & 1), "threads": threads})
            elif rel == 2 and raw[body] == 3:  # RelationCache, L3
                l3_caches.append(struct.unpack_from("<I", raw, body + 4)[0] // 1024)
            elif rel == 3:                     # RelationProcessorPackage
                packages += 1
            elif rel == 1:                     # RelationNumaNode
                numa += 1
            off += sz

        classes = sorted({c["efficiency_class"] for c in cores})
        hybrid = len(classes) > 1
        p_cores = [c for c in cores if c["efficiency_class"] == classes[-1]] if hybrid else cores
        e_cores = [c for c in cores if c["efficiency_class"] != classes[-1]] if hybrid else []
        proc = platform.processor()
        return {
            "total_cores": len(cores),
            "logical_processors": sum(c["threads"] for c in cores),
            "has_ecores": hybrid,
            "p_core_count": len(p_cores),
            "e_core_count": len(e_cores),
            "smt_enabled": any(c["smt"] for c in cores),
            "l3_cache_count": len(l3_caches),          # у AMD = число CCD/CCX со своим L3
            "l3_cache_kb": l3_caches,
            "packages": packages,
            "numa_nodes": numa,
            "architecture": "AMD" if "AMD" in proc else "Intel" if "Intel" in proc else proc,
            "processor_id": proc,
        }


# ---------------------------------------------------------------------------
class HardwareInfoProbe(SnapshotProbe):
    name = "HARDWARE_INFO"
    timeout_s = 20.0     # WMI на холодную бывает медленным; в старой версии здесь был таймаут

    def collect(self, ctx: SessionContext) -> dict:
        cpu = wmi("SELECT Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed FROM Win32_Processor")
        board = wmi("SELECT Manufacturer, Product FROM Win32_BaseBoard")
        bios = wmi("SELECT SMBIOSBIOSVersion, ReleaseDate FROM Win32_BIOS")
        gpus = wmi("SELECT Name, DriverVersion, CurrentHorizontalResolution, CurrentVerticalResolution, "
                   "CurrentRefreshRate FROM Win32_VideoController")
        os_ = wmi("SELECT Caption, Version, BuildNumber FROM Win32_OperatingSystem")
        mods = memory_modules()
        total_gb = sum(as_int(m.get("Capacity")) or 0 for m in mods) / 2**30
        c = cpu[0] if cpu else {}
        return {
            "cpu_name": (c.get("Name") or "").strip(),
            "cpu_cores": c.get("NumberOfCores"),
            "cpu_threads": c.get("NumberOfLogicalProcessors"),
            "cpu_max_mhz": c.get("MaxClockSpeed"),
            "motherboard": " ".join(filter(None, [board[0].get("Manufacturer"), board[0].get("Product")])) if board else None,
            "bios_version": bios[0].get("SMBIOSBIOSVersion") if bios else None,
            "ram_total_gb": round(total_gb, 1),
            "ram_modules": [{
                "slot": m.get("DeviceLocator"), "size_gb": round((as_int(m.get("Capacity")) or 0) / 2**30),
                "rated_mhz": m.get("Speed"), "configured_mhz": m.get("ConfiguredClockSpeed"),
                "vendor": (m.get("Manufacturer") or "").strip(), "part": (m.get("PartNumber") or "").strip(),
            } for m in mods],
            "gpus": [{"name": g.get("Name"), "driver": g.get("DriverVersion"),
                      "mode": f"{g.get('CurrentHorizontalResolution')}x{g.get('CurrentVerticalResolution')}"
                              f"@{g.get('CurrentRefreshRate')}Hz"} for g in gpus],
            "os": f"{os_[0].get('Caption')} ({os_[0].get('Version')})" if os_ else platform.platform(),
            "os_build": int(os_[0]["BuildNumber"]) if os_ and os_[0].get("BuildNumber") else None,
        }


# ---------------------------------------------------------------------------
DDR = {26: "DDR4", 34: "DDR5", 24: "DDR3"}


def _monitors() -> list[dict]:
    import win32api

    out, i = [], 0
    while i < 16:
        try:
            dev = win32api.EnumDisplayDevices(None, i)
        except Exception:
            break
        i += 1
        if not dev.StateFlags & 0x1:            # DISPLAY_DEVICE_ATTACHED_TO_DESKTOP
            continue
        try:
            cur = win32api.EnumDisplaySettings(dev.DeviceName, -1)   # ENUM_CURRENT_SETTINGS
        except Exception:
            continue
        max_hz, j = cur.DisplayFrequency, 0
        while j < 4000:
            try:
                m = win32api.EnumDisplaySettings(dev.DeviceName, j)
            except Exception:
                break
            if not m.PelsWidth:
                break
            if (m.PelsWidth, m.PelsHeight) == (cur.PelsWidth, cur.PelsHeight):
                max_hz = max(max_hz, m.DisplayFrequency)
            j += 1
        out.append({
            "device": dev.DeviceName, "adapter": dev.DeviceString, "primary": bool(dev.StateFlags & 0x4),
            "resolution": f"{cur.PelsWidth}x{cur.PelsHeight}",
            "current_hz": cur.DisplayFrequency, "max_hz_at_resolution": max_hz,
        })
    return out


def effective_ram_speed(configured: int | None, kit: int | None) -> tuple[int | None, bool]:
    """На части плат Windows отдаёт частоту памяти в МГц, а не в МТ/с (1600 вместо 3200 у DDR4-3200).
    Если удвоенное значение совпадает с маркировкой комплекта, считаем это той же частотой."""
    if configured and kit and abs(configured * 2 - kit) <= 100 and kit - configured >= 200:
        return configured * 2, True
    return configured, False


class HardwareMisconfigProbe(SnapshotProbe):
    name = "HARDWARE_MISCONFIG"
    timeout_s = 20.0

    def collect(self, ctx: SessionContext) -> dict:
        mods = memory_modules()
        configured = [m.get("ConfiguredClockSpeed") for m in mods if m.get("ConfiguredClockSpeed")]
        rated = [m.get("Speed") for m in mods if m.get("Speed")]
        # скорость из партномера: F5-6000J3038F16G -> 6000, CMK32GX5M2B6000C36 -> 6000
        part_speeds = []
        for m in mods:
            for s in re.findall(r"(?<!\d)(\d{4})(?!\d)", m.get("PartNumber") or ""):
                if 2133 <= int(s) <= 9600:
                    part_speeds.append(int(s))
        kit = max(part_speeds) if part_speeds else None
        cur, doubled = effective_ram_speed(min(configured) if configured else None, kit)
        monitors = _monitors()
        return {
            "ram_type": DDR.get(mods[0].get("SMBIOSMemoryType")) if mods else None,
            "ram_module_count": len(mods),
            "ram_speed_mhz": cur,
            "ram_speed_reported_halved": doubled,
            "ram_rated_mhz": max(rated) if rated else None,
            "ram_kit_speed_from_part": kit,
            "xmp_likely_disabled": bool(cur and kit and kit - cur >= 200),
            "single_module": len(mods) == 1,
            "monitors": monitors,
            "monitor_suboptimal": any(m["current_hz"] < m["max_hz_at_resolution"] for m in monitors),
        }


# ---------------------------------------------------------------------------
class BiosFirmwareProbe(SnapshotProbe):
    name = "BIOS_FIRMWARE"
    timeout_s = 15.0

    def collect(self, ctx: SessionContext) -> dict:
        out: dict = {"errors": []}
        bios = reg_values(HKLM, r"HARDWARE\DESCRIPTION\System\BIOS")
        rel = parse_us_date(bios.get("BIOSReleaseDate"))
        out.update({
            "bios_vendor": bios.get("BIOSVendor"),
            "bios_version": bios.get("BIOSVersion"),
            "bios_date": rel.isoformat() if rel else None,
            "bios_age_days": age_days(rel),
            "board": " ".join(filter(None, [bios.get("BaseBoardManufacturer"), bios.get("BaseBoardProduct")])),
        })
        fw = ctypes.c_uint(0)
        if ctypes.windll.kernel32.GetFirmwareType(ctypes.byref(fw)):
            out["firmware_type"] = {1: "Legacy BIOS", 2: "UEFI"}.get(fw.value, fw.value)
        out["secure_boot"] = as_int(reg_get(HKLM, r"SYSTEM\CurrentControlSet\Control\SecureBoot\State",
                                            "UEFISecureBootEnabled"))

        bcd = bcd_current()
        out["bcd"] = {k: bcd.get(k) for k in ("useplatformclock", "useplatformtick", "disabledynamictick",
                                               "tscsyncpolicy", "hypervisorlaunchtype", "nx", "x2apicpolicy")}
        out["forced_hpet_clock"] = (bcd.get("useplatformclock") or "").lower() in ("yes", "да", "on", "true")
        if not bcd:
            out["errors"].append("bcdedit не вернул данные")

        try:
            dg = wmi("SELECT VirtualizationBasedSecurityStatus, SecurityServicesRunning FROM Win32_DeviceGuard",
                     r"root\Microsoft\Windows\DeviceGuard")
            if dg:
                running = dg[0].get("SecurityServicesRunning") or []
                out["vbs_status"] = {0: "off", 1: "configured", 2: "running"}.get(
                    dg[0].get("VirtualizationBasedSecurityStatus"), dg[0].get("VirtualizationBasedSecurityStatus"))
                out["hvci_running"] = 2 in running
                out["credential_guard_running"] = 1 in running
        except Exception as exc:
            out["errors"].append(f"DeviceGuard: {exc}")
        try:
            cs = wmi("SELECT HypervisorPresent FROM Win32_ComputerSystem")
            out["hypervisor_present"] = cs[0].get("HypervisorPresent") if cs else None
        except Exception as exc:
            out["errors"].append(f"ComputerSystem: {exc}")

        mm = reg_values(HKLM, MM_KEY)
        out["spectre_override"] = as_int(mm.get("FeatureSettingsOverride"))
        return out


# ---------------------------------------------------------------------------
class SystemCoreProbe(SnapshotProbe):
    """Замер: насколько точно поток просыпается после Sleep(1) при разрешении таймера 1 мс."""
    name = "SYSTEM_CORE"
    timeout_s = 10.0
    SAMPLES = 250

    def collect(self, ctx: SessionContext) -> dict:
        winmm, k32 = ctypes.windll.winmm, ctypes.windll.kernel32
        samples = []
        winmm.timeBeginPeriod(1)
        try:
            for _ in range(self.SAMPLES):
                t0 = time.perf_counter_ns()
                k32.Sleep(1)
                samples.append((time.perf_counter_ns() - t0) / 1e6)
        finally:
            winmm.timeEndPeriod(1)
        s = sorted(samples)
        avg = mean(s)
        std = (sum((x - avg) ** 2 for x in s) / len(s)) ** 0.5
        kern = reg_values(HKLM, KERNEL_KEY)
        return {
            "wake_jitter_ms": {
                "requested": 1.0, "avg": r(avg, 3), "p50": r(percentile(s, 50), 3),
                "p99": r(percentile(s, 99), 3), "max": r(s[-1], 3), "stdev": r(std, 3),
            },
            "_jitter_samples": [round(x, 3) for x in samples],
            "kernel_registry": {k: as_int(kern.get(k)) for k in (
                "SerializeTimerExpiration", "ThreadDpcEnable", "GlobalTimerResolutionRequests",
                "DpcWatchdogProfileOffset", "DisableTsx")},
        }


# ---------------------------------------------------------------------------
class TimerResolutionProbe(SnapshotProbe):
    name = "TIMER_RESOLUTION"
    timeout_s = 5.0

    def collect(self, ctx: SessionContext) -> dict:
        ntdll = ctypes.windll.ntdll

        def query():
            lo, hi, cur = ctypes.c_ulong(), ctypes.c_ulong(), ctypes.c_ulong()
            st = ntdll.NtQueryTimerResolution(ctypes.byref(lo), ctypes.byref(hi), ctypes.byref(cur))
            if st != 0:
                raise RuntimeError(f"NtQueryTimerResolution NTSTATUS=0x{st & 0xFFFFFFFF:08X}")
            return lo.value / 10_000, hi.value / 10_000, cur.value / 10_000   # 100 нс -> мс

        coarsest, finest, _ = query()
        series = []
        for _ in range(20):
            series.append(query()[2])
            time.sleep(0.05)
        return {
            "current_resolution_ms": series[-1],
            "coarsest_resolution_ms": coarsest,
            "finest_resolution_ms": finest,
            "resolution_changed_during_sample": len(set(series)) > 1,
            "observed_values_ms": sorted(set(series)),
            "global_timer_resolution_requests": as_int(reg_get(HKLM, KERNEL_KEY, "GlobalTimerResolutionRequests")),
        }


# ---------------------------------------------------------------------------
class _MEMSTATUS(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


class MemoryManagementProbe(SnapshotProbe):
    name = "MEMORY_MANAGEMENT"
    timeout_s = 15.0

    def collect(self, ctx: SessionContext) -> dict:
        ms = _MEMSTATUS()
        ms.dwLength = ctypes.sizeof(ms)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
        mm = reg_values(HKLM, MM_KEY)
        paging = [p for p in (mm.get("PagingFiles") or []) if p.strip()]
        names = {p["name"].lower() for p in processes()}
        return {
            "total_gb": round(ms.ullTotalPhys / 2**30, 1),
            "available_gb": round(ms.ullAvailPhys / 2**30, 1),
            "memory_load_percent": ms.dwMemoryLoad,
            "commit_limit_gb": round(ms.ullTotalPageFile / 2**30, 1),
            "paging_files": paging,
            "pagefile_disabled": not paging,
            "disable_paging_executive": as_int(mm.get("DisablePagingExecutive")),
            "large_system_cache": as_int(mm.get("LargeSystemCache")),
            "memory_compression_process": "memory compression" in names,
        }


# ---------------------------------------------------------------------------
# Фоновые программы, которые часто всплывают при разборе задержек: оверлеи, опрос датчиков, RGB.
BACKGROUND_SOFTWARE = [
    ("rtss", "RivaTuner Statistics Server", "overlay"),
    ("msiafterburner", "MSI Afterburner", "sensors"),
    ("hwinfo", "HWiNFO", "sensors"),
    ("aida64", "AIDA64", "sensors"),
    ("icue", "Corsair iCUE", "rgb"),
    ("lghub", "Logitech G HUB", "peripherals"),
    ("razer", "Razer Synapse", "peripherals"),
    ("armourycrate", "ASUS Armoury Crate", "rgb"),
    ("signalrgb", "SignalRGB", "rgb"),
    ("openrgb", "OpenRGB", "rgb"),
    ("nzxt cam", "NZXT CAM", "sensors"),
    ("steelseriesgg", "SteelSeries GG", "peripherals"),
    ("wallpaper32", "Wallpaper Engine", "gpu_load"),
    ("wallpaper64", "Wallpaper Engine", "gpu_load"),
    ("gameoverlayui", "Steam overlay", "overlay"),
    ("nvidia overlay", "NVIDIA overlay", "overlay"),
    ("obs64", "OBS Studio", "capture"),
    ("fancontrol", "FanControl", "sensors"),
    ("ryzenmaster", "AMD Ryzen Master", "sensors"),
]


# Античиты уровня ядра: (название, процессы, службы/драйверы). Имена точные, без подстрок,
# чтобы не ловить посторонние программы. Список не исчерпывающий: самые распространённые.
ANTICHEATS = [
    ("Riot Vanguard", {"vgc.exe", "vgtray.exe"}, {"vgc", "vgk"}),
    ("Easy Anti-Cheat", {"easyanticheat.exe", "easyanticheat_eos.exe"},
     {"easyanticheat", "easyanticheat_eos", "easyanticheatsys"}),
    ("BattlEye", {"beservice.exe", "beservice_x64.exe"}, {"beservice", "bedaisy"}),
    ("EA AntiCheat", {"eaanticheat.gameservice.exe", "eaanticheat.gameservicelauncher.exe"},
     {"eaanticheatservice", "eaanticheat"}),
    ("FACEIT AC", {"faceit.exe", "faceitservice.exe"}, {"faceit", "faceitservice"}),
    ("ESEA", {"eseaclient.exe"}, {"esea", "eseadriver2"}),
    ("mhyprot (miHoYo)", set(), {"mhyprot2", "mhyprot3"}),
    ("XIGNCODE3", set(), {"xhunter1"}),
    ("nProtect GameGuard", set(), {"npggsvc"}),
]


def detect_anticheats(proc_names: set[str], svc: dict[str, dict]) -> list[dict]:
    """Какие античиты установлены и какие активны прямо сейчас (процесс запущен или служба/драйвер работает)."""
    found = []
    for title, procs, svcs in ANTICHEATS:
        hits = [f"процесс {p}" for p in sorted(procs & proc_names)]
        running = bool(hits)
        installed = bool(hits)
        for s in sorted(svcs):
            info = svc.get(s)
            if info:
                installed = True
                if info.get("state") == "running":
                    running = True
                    hits.append(f"{info.get('name') or s} работает")
        if installed:
            found.append({"title": title, "running": running, "evidence": hits})
    return found


class ProcessesProbe(SnapshotProbe):
    name = "PROCESSES"
    timeout_s = 15.0

    def collect(self, ctx: SessionContext) -> dict:
        procs = processes()
        try:
            svc = {**services(), **drivers()}
        except Exception:        # без pywin32 или прав: проверим хотя бы процессы
            svc = {}
        anticheats = detect_anticheats({p["name"].lower() for p in procs}, svc)
        found = {}
        for p in procs:
            low = p["name"].lower()
            for needle, title, kind in BACKGROUND_SOFTWARE:
                if needle in low:
                    found.setdefault(title, {"title": title, "kind": kind, "processes": []})["processes"].append(p["name"])
        top = sorted(procs, key=lambda p: p["mem_kb"] or 0, reverse=True)[:10]
        return {
            "process_count": len(procs),
            "top_memory": [{"name": p["name"], "mem_mb": round((p["mem_kb"] or 0) / 1024)} for p in top],
            "background_software": list(found.values()),
            "anticheats": anticheats,
            "self_pid": os.getpid(),
        }
