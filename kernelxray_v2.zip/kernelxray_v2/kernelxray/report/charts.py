"""Инлайн-SVG графики в стиле старого отчёта (янтарь / бордо на тёмном), без внешних библиотек."""
from __future__ import annotations

import math
from html import escape

AMBER, MAROON, RED, GREEN, INFO, CYAN = "#ffb300", "#800000", "#ff5c5c", "#3fb57a", "#78909c", "#4fc3f7"
MUTED, GRID = "#98a3ad", "rgba(255,255,255,0.08)"
MONO = "'Cascadia Code','Cascadia Mono',Consolas,monospace"


def _tick(v: float) -> str:
    if v >= 1_000_000:
        return f"{v / 1e6:.1f}M"
    if v >= 10_000:
        return f"{v / 1000:.0f}k"
    if v >= 100:
        return f"{v:.0f}"
    return f"{v:.2f}".rstrip("0").rstrip(".") or "0"


def area_chart(values: list[float], *, width: int = 1000, height: int = 300, unit: str = "",
               refs: list[tuple[float, str]] | None = None, color: str = AMBER, gid: str = "g1",
               marks: list[int] | None = None, mark_title: str = "") -> str:
    """marks: индексы точек, которые нужно выделить (кружок и тонкая вертикаль), mark_title — подсказка к ним."""
    vals = [v for v in values if v is not None]
    if len(vals) < 2:
        return ""
    pad_l, pad_b, pad_t, pad_r = 52, 24, 12, 10
    w, h = width - pad_l - pad_r, height - pad_b - pad_t
    vmax = max(vals + [r[0] for r in (refs or [])]) * 1.1 or 1
    n = len(vals)
    pts = [(pad_l + i * w / (n - 1), pad_t + h - v / vmax * h) for i, v in enumerate(vals)]
    line = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    area = f"{pad_l},{pad_t + h} {line} {pad_l + w},{pad_t + h}"
    grid = []
    for k in range(5):
        v = vmax * k / 4
        y = pad_t + h - v / vmax * h
        grid.append(f'<line x1="{pad_l}" x2="{pad_l + w}" y1="{y:.1f}" y2="{y:.1f}" stroke="{GRID}"/>'
                    f'<text x="{pad_l - 8}" y="{y + 4:.1f}" fill="{MUTED}" font-family="{MONO}" font-size="11" '
                    f'text-anchor="end">{_tick(v)}</text>')
    mark_svg = []
    for i in sorted(set(marks or [])):
        if 0 <= i < n:
            x, y = pts[i]
            tip = f"{mark_title}: {vals[i]:g} ms" if mark_title else f"{vals[i]:g} ms"
            mark_svg.append(f'<g><title>{escape(tip)}</title><line x1="{x:.1f}" x2="{x:.1f}" y1="{pad_t}" '
                            f'y2="{pad_t + h}" stroke="{CYAN}" stroke-opacity=".35" stroke-dasharray="2 4"/>'
                            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4.5" fill="none" stroke="{CYAN}" '
                            f'stroke-width="2"/></g>')
    ref_svg = []
    for v, label in refs or []:
        y = pad_t + h - v / vmax * h
        ref_svg.append(f'<line x1="{pad_l}" x2="{pad_l + w}" y1="{y:.1f}" y2="{y:.1f}" stroke="{RED}" '
                       f'stroke-dasharray="6 5"/><text x="{pad_l + w - 4}" y="{y - 6:.1f}" fill="{RED}" '
                       f'font-family="{MONO}" font-size="11" text-anchor="end">{escape(label)}</text>')
    return (f'<svg viewBox="0 0 {width} {height}" class="svgchart" role="img" aria-label="{escape(unit)}">'
            f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0" stop-color="{color}" stop-opacity=".35"/>'
            f'<stop offset="1" stop-color="{color}" stop-opacity="0"/></linearGradient></defs>'
            f'{"".join(grid)}<polygon points="{area}" fill="url(#{gid})"/>'
            f'<polyline points="{line}" fill="none" stroke="{color}" stroke-width="1.6" stroke-linejoin="round"/>'
            f'{"".join(ref_svg)}{"".join(mark_svg)}<text x="{pad_l + w}" y="{height - 4}" fill="{MUTED}" font-family="{MONO}" '
            f'font-size="11" text-anchor="end">{escape(unit)}</text></svg>')


def radar(labels: list[str], values: list[float], *, size: int = 360) -> str:
    n = len(labels)
    if n < 3:
        return ""
    margin = 90                     # место под подписи осей слева и справа
    cx, cy = size / 2 + margin, size / 2
    rad = size / 2 - 60
    def pt(i: int, frac: float) -> tuple[float, float]:
        a = -math.pi / 2 + 2 * math.pi * i / n
        return cx + math.cos(a) * rad * frac, cy + math.sin(a) * rad * frac
    rings = []
    for frac in (0.25, 0.5, 0.75, 1.0):
        rings.append('<polygon points="' + " ".join(f"{x:.1f},{y:.1f}" for x, y in (pt(i, frac) for i in range(n)))
                     + f'" fill="none" stroke="{GRID}"/>')
    axes, texts = [], []
    for i, label in enumerate(labels):
        x, y = pt(i, 1)
        axes.append(f'<line x1="{cx}" y1="{cy}" x2="{x:.1f}" y2="{y:.1f}" stroke="{GRID}"/>')
        lx, ly = pt(i, 1.2)
        anchor = "middle" if abs(lx - cx) < 10 else ("start" if lx > cx else "end")
        texts.append(f'<text x="{lx:.1f}" y="{ly + 4:.1f}" fill="{MUTED}" font-family="{MONO}" font-size="11" '
                     f'text-anchor="{anchor}">{escape(label)}</text>'
                     f'<text x="{lx:.1f}" y="{ly + 18:.1f}" fill="#e6eaee" font-family="{MONO}" font-size="12" '
                     f'font-weight="700" text-anchor="{anchor}">{values[i]:.0f}</text>')
    poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in (pt(i, v / 100) for i, v in enumerate(values)))
    dots = "".join(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.5" fill="{AMBER}"/>'
                   for x, y in (pt(i, v / 100) for i, v in enumerate(values)))
    return (f'<svg viewBox="0 0 {size + 2 * margin} {size}" class="svgchart radar" role="img" aria-label="Баланс подсистем">'
            f'{"".join(rings)}{"".join(axes)}<polygon points="{poly}" fill="rgba(255,179,0,.14)" '
            f'stroke="{AMBER}" stroke-width="2"/>{dots}{"".join(texts)}</svg>')


def donut(segments: list[tuple[str, float, str]], *, size: int = 240, center_label: str = "") -> str:
    total = sum(v for _, v, _ in segments)
    r, sw = 80, 28
    c = 2 * math.pi * r
    parts, offset = [], 0.0
    if total:
        for label, v, color in segments:
            if not v:
                continue
            ln = v / total * c
            parts.append(f'<circle r="{r}" cx="{size / 2}" cy="{size / 2}" fill="none" stroke="{color}" '
                         f'stroke-width="{sw}" stroke-dasharray="{ln:.2f} {c - ln:.2f}" '
                         f'stroke-dashoffset="{-offset:.2f}" transform="rotate(-90 {size / 2} {size / 2})">'
                         f'<title>{escape(label)}: {v:g}</title></circle>')
            offset += ln
    else:
        parts.append(f'<circle r="{r}" cx="{size / 2}" cy="{size / 2}" fill="none" stroke="{GREEN}" '
                     f'stroke-width="{sw}" opacity=".5"/>')
    return (f'<svg viewBox="0 0 {size} {size}" class="svgchart donut" role="img" aria-label="Распределение находок">'
            f'<circle r="{r}" cx="{size / 2}" cy="{size / 2}" fill="none" stroke="rgba(255,255,255,.05)" '
            f'stroke-width="{sw}"/>{"".join(parts)}'
            f'<text x="{size / 2}" y="{size / 2 + 4}" fill="#e6eaee" font-family="{MONO}" font-size="30" '
            f'font-weight="700" text-anchor="middle">{int(total)}</text>'
            f'<text x="{size / 2}" y="{size / 2 + 24}" fill="{MUTED}" font-family="{MONO}" font-size="10" '
            f'text-anchor="middle">{escape(center_label)}</text></svg>')


def histogram(buckets: list[list[int]], *, width: int = 1000, height: int = 220) -> str:
    """Корзины dpcisr [lo, hi, count]; высота в логарифмическом масштабе."""
    if not buckets:
        return ""
    pad_b, pad_t = 30, 20
    h = height - pad_b - pad_t
    n = len(buckets)
    bw = width / n
    top = max(math.log10(c + 1) for _, _, c in buckets) or 1
    bars = []
    for i, (lo, hi, cnt) in enumerate(buckets):
        bh = max(2, math.log10(cnt + 1) / top * h)
        x = i * bw + 5
        color = RED if lo >= 256 else AMBER if lo >= 64 else CYAN if lo >= 16 else GREEN
        bars.append(
            f'<rect x="{x:.1f}" y="{pad_t + h - bh:.1f}" width="{bw - 10:.1f}" height="{bh:.1f}" rx="6" '
            f'fill="{color}" opacity=".9"><title>{lo}–{hi} мкс: {cnt}</title></rect>'
            f'<text x="{x + (bw - 10) / 2:.1f}" y="{pad_t + h - bh - 6:.1f}" fill="#e6eaee" font-family="{MONO}" '
            f'font-size="11" text-anchor="middle">{cnt}</text>'
            f'<text x="{x + (bw - 10) / 2:.1f}" y="{height - 8}" fill="{MUTED}" font-family="{MONO}" '
            f'font-size="11" text-anchor="middle">≤{hi} μs</text>')
    return (f'<svg viewBox="0 0 {width} {height}" class="svgchart" role="img" '
            f'aria-label="Распределение длительности DPC">{"".join(bars)}</svg>')
