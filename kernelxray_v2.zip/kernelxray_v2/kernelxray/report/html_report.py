"""HTML-отчёт в визуальном стиле KernelXray 1.x: тёмные панели, янтарь и бордо, моноширинные метки.

Самодостаточный файл: без внешних скриптов и шрифтов, графики — инлайн-SVG.
"""
from __future__ import annotations

import json
from html import escape
from pathlib import Path

from ..analysis.rules import (COLLISION_MIN_SHARE_PCT, DPC_CRIT_US, DPC_MAX_MIN_EVENTS, DPC_WARN_US, KIND_LABEL,
                              core_map, dpc_max, dpc_state, find_collisions, fmt_us)
from .charts import AMBER, CYAN, GREEN, INFO, MAROON, RED, area_chart, donut, histogram, radar

SEV = {"critical": "Critical", "warning": "Warning", "info": "Info", "ok": "Clean"}
PROBE_TITLES = {
    "CPU_TOPOLOGY": "Топология процессора", "HARDWARE_INFO": "Железо", "HARDWARE_MISCONFIG": "Память и мониторы",
    "BIOS_FIRMWARE": "Прошивка и загрузка", "SYSTEM_CORE": "Точность пробуждения потоков",
    "TIMER_RESOLUTION": "Системный таймер", "MEMORY_MANAGEMENT": "Управление памятью",
    "PROCESSES": "Процессы", "OS_CONFIG": "Электропитание и планировщик", "OS_ENTROPY": "Фоновые функции Windows",
    "SERVICES_BLOAT": "Службы", "DRIVER_MANIFEST": "Драйверы", "GPU_ANALYSIS": "Видеокарта",
    "GPU_SCHEDULER": "Планирование GPU", "AUDIO_DPC": "Звук", "INPUT_ELITE": "Устройства ввода",
    "USB_POWER": "Питание USB и PCIe", "CORE_COLLISION": "Прерывания по ядрам",
    "NETWORK_ELITE": "Сетевые адаптеры", "STORAGE_ELITE": "Накопители", "STORAGE_GUIDE": "Настройки дисков",
    "PERFMON_ELITE": "Счётчики производительности", "PRESENT_MON": "Кадры", "ETW_TRACER": "Трасса ядра",
    "ETW_SONAR": "Поэвентный разбор трассы",
}

CSS = """
:root{--bg:#0b0d10;--panel:#12161b;--panel2:#171c22;--line:#2b333c;--text:#e6eaee;--muted:#98a3ad;
--critical:#800000;--critical-hi:#ff5c5c;--warning:#ffb300;--good:#3fb57a;--info:#78909c;--cyan:#4fc3f7;
--accent:#ffb300;--radius:24px;--radius-sm:18px;--shadow:0 18px 48px rgba(0,0,0,.42);
--mono:"Cascadia Code","Cascadia Mono",Consolas,monospace}
*{box-sizing:border-box}
html{color-scheme:dark}
body{margin:0;color:var(--text);font-family:"Segoe UI Variable","Segoe UI",system-ui,sans-serif;
background:radial-gradient(circle at top left,rgba(255,179,0,.07),transparent 26%),
radial-gradient(circle at top right,rgba(128,0,0,.14),transparent 30%),
radial-gradient(circle at 50% 120%,rgba(79,195,247,.05),transparent 40%),linear-gradient(180deg,#090b0e,#0b0d10);
min-height:100vh}
.wrap{width:min(1480px,calc(100vw - 40px));margin:0 auto;padding:24px 0 56px}
.hero,.panel,.card,.item,.heat,.cause,.story,.tele,.integ{background:linear-gradient(180deg,rgba(23,28,34,.97),rgba(14,17,21,.98));
border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}
.hero,.panel{padding:26px}
.hero{display:grid;grid-template-columns:1.3fr .9fr;gap:20px}
h1,h2,h3,h4,p{margin:0}
.mono,.eyebrow,.label,.value,.badge,.score,th,.tone,.penalty,.state{font-family:var(--mono)}
.eyebrow{display:inline-flex;padding:7px 11px;border-radius:999px;font-size:12px;letter-spacing:.08em;
text-transform:uppercase;color:var(--accent);border:1px solid rgba(255,179,0,.24);background:rgba(255,179,0,.08)}
h1{margin-top:16px;font-size:clamp(30px,3.6vw,52px);line-height:1.06;letter-spacing:-.03em}
.hero p.lead{margin-top:14px;max-width:72ch;font-size:15px;color:var(--muted);line-height:1.66}
.muted,.caption{color:var(--muted);line-height:1.62}
.grid4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:22px}
.grid2{display:grid;grid-template-columns:1.06fr .94fr;gap:20px}
.grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.card,.item,.cause,.story,.tele,.integ{padding:18px;border-radius:var(--radius-sm)}
.label,th{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
.value{margin-top:8px;font-size:22px;font-weight:700;line-height:1.15;word-break:break-word}
.card .value{font-size:18px;overflow-wrap:break-word}
.card .sub{margin-top:6px;color:var(--muted);font-size:13px}
.scorebox{border-radius:var(--radius);padding:26px;display:flex;flex-direction:column;justify-content:space-between;
border:1px solid rgba(255,255,255,.08);box-shadow:var(--shadow)}
.scorebox.tier-critical{background:linear-gradient(160deg,rgba(128,0,0,.95),rgba(46,12,12,.98))}
.scorebox.tier-warning{background:linear-gradient(160deg,rgba(150,92,0,.92),rgba(40,26,8,.98))}
.scorebox.tier-good{background:linear-gradient(160deg,rgba(31,110,72,.92),rgba(10,34,24,.98))}
.score{margin-top:10px;font-size:clamp(64px,7vw,96px);line-height:.94;font-weight:700}
.score small{font-size:22px;opacity:.6;font-weight:400}
.score-bar{margin-top:16px;height:10px;border-radius:999px;background:rgba(255,255,255,.12);overflow:hidden}
.score-bar i{display:block;height:100%;width:calc(var(--v)*.1%);background:linear-gradient(90deg,#fff,rgba(255,255,255,.55));border-radius:999px}
.score-row{display:flex;justify-content:space-between;gap:10px;margin-top:12px;color:rgba(255,255,255,.78);font-size:14px}
.tone{display:inline-flex;margin-top:14px;padding:8px 12px;border-radius:999px;font-size:12px;letter-spacing:.08em;
text-transform:uppercase;background:rgba(255,255,255,.1);align-self:flex-start}
.section{margin-top:20px}
.head{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;margin-bottom:18px;flex-wrap:wrap}
.head h2{font-family:var(--mono);font-size:17px;letter-spacing:.04em;text-transform:uppercase}
.head h2 span{color:var(--muted);font-weight:400}
.head p{margin-top:8px;color:var(--muted);font-size:14px;max-width:80ch;line-height:1.6}
.stories{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.story strong{display:block;font-family:var(--mono);font-size:13px;letter-spacing:.04em;margin-bottom:8px}
.story div{color:var(--muted);font-size:14px;line-height:1.6}
.story.critical{border-color:rgba(255,92,92,.45)}.story.warning{border-color:rgba(255,179,0,.4)}.story.clean{border-color:rgba(63,181,122,.4)}
.causes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.cause{position:relative;overflow:hidden}
.cause::before{content:"";position:absolute;inset:0 0 auto 0;height:3px;background:var(--c)}
.cause.critical{--c:var(--critical-hi)}.cause.warning{--c:var(--warning)}.cause.info{--c:var(--info)}
.cause .top{display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap}
.cause h3{margin:12px 0 10px;font-size:18px;line-height:1.28}
.cause p{color:var(--muted);font-size:13.5px;line-height:1.58;margin-top:8px}
.cause p b{color:var(--text);font-weight:600}
.penalty{display:inline-flex;padding:6px 10px;border-radius:999px;font-size:11px;letter-spacing:.08em;text-transform:uppercase;
background:rgba(255,179,0,.10);color:var(--accent)}
.fixable{display:inline-flex;padding:6px 10px;border-radius:999px;font-size:11px;letter-spacing:.06em;font-family:var(--mono);
background:rgba(79,195,247,.12);color:#a8e3fb}
.telemetry{display:grid;grid-template-columns:repeat(auto-fit,minmax(168px,1fr));gap:14px}
.tele{background:linear-gradient(180deg,rgba(31,31,31,.96),rgba(17,17,17,.98))}
.tele.critical{border-color:rgba(255,92,92,.5)}.tele.warning{border-color:rgba(255,179,0,.45)}.tele.clean{border-color:rgba(63,181,122,.4)}
.tele .value{font-size:28px}
.tele .state{margin-top:8px;font-size:11px;letter-spacing:.08em;text-transform:uppercase}
.tele.critical .state{color:var(--critical-hi)}.tele.warning .state{color:var(--warning)}.tele.clean .state{color:var(--good)}
.tele .sub{margin-top:8px;color:var(--muted);font-size:13px;line-height:1.5}
.integrity{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
.integ{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:14px 18px}
.integ strong{font-family:var(--mono);font-size:13px;letter-spacing:.04em}
.integ span{color:var(--muted);font-size:13px}
.dot{width:10px;height:10px;border-radius:50%;flex:none;box-shadow:0 0 12px currentColor}
.dot.ok{color:var(--good);background:var(--good)}.dot.miss{color:var(--critical-hi);background:var(--critical-hi)}
.dot.part{color:var(--warning);background:var(--warning)}
.chartbox{display:flex;align-items:center;justify-content:center}
.svgchart{width:100%;height:auto;display:block}
.radar{max-width:560px}.donut{max-width:260px}
.legend{display:flex;flex-wrap:wrap;gap:10px 18px;justify-content:center;margin-top:10px;font-family:var(--mono);font-size:12px;color:var(--muted)}
.legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.bar-chart{display:grid;gap:14px}
.bar-row{display:grid;gap:8px}
.bar-meta{display:flex;justify-content:space-between;align-items:baseline;gap:14px;font-family:var(--mono)}
.bar-label{font-size:13px;color:var(--text);letter-spacing:.04em}
.bar-value{font-size:12px;color:var(--muted);text-align:right}
.bar-track{position:relative;height:14px;border-radius:999px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.06);overflow:hidden}
.bar-fill{position:absolute;inset:0 auto 0 0;height:100%;border-radius:999px;width:calc(var(--w)*1%);min-width:6px}
.bar-row.info .bar-fill{background:linear-gradient(90deg,rgba(120,144,156,.95),rgba(120,144,156,.45))}
.bar-row.warning .bar-fill{background:linear-gradient(90deg,rgba(255,179,0,.98),rgba(255,179,0,.45))}
.bar-row.critical .bar-fill{background:linear-gradient(90deg,rgba(255,92,92,.95),rgba(128,0,0,.6))}
.bar-row.cyan .bar-fill{background:linear-gradient(90deg,rgba(79,195,247,.95),rgba(79,195,247,.4))}
.bar-row.good .bar-fill{background:linear-gradient(90deg,rgba(63,181,122,.95),rgba(63,181,122,.4))}
.wrap-x{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th,td{padding:13px 10px;text-align:left;border-bottom:1px solid rgba(255,255,255,.06);vertical-align:top}
td{font-size:14px;line-height:1.55}
td.n,th.n{text-align:right;font-family:var(--mono);white-space:nowrap}
td .impact{display:block;margin-top:4px;font-family:var(--mono);font-size:11.5px;color:var(--muted)}
.badge{display:inline-flex;align-items:center;justify-content:center;padding:6px 10px;border-radius:999px;font-size:11px;
letter-spacing:.08em;text-transform:uppercase;white-space:nowrap}
.badge.critical{background:rgba(255,92,92,.16);color:#ffc2c2}.badge.warning{background:rgba(255,179,0,.18);color:#ffd687}
.badge.info{background:rgba(120,144,156,.18);color:#ccdae0}.badge.ok{background:rgba(63,181,122,.16);color:#a9e6c6}
.windows{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px}
.win{padding:16px;border-radius:16px;border:1px solid var(--line);background:linear-gradient(180deg,rgba(128,0,0,.10),rgba(16,18,22,.98))}
.win.hot{background:linear-gradient(180deg,rgba(255,92,92,.18),rgba(16,18,22,.98));border-color:rgba(255,92,92,.35)}
.win strong{font-family:var(--mono);font-size:14px;color:var(--warning)}
.win div{margin-top:8px;color:var(--muted);font-size:13px;line-height:1.55}
.heatmap{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px}
.heat{padding:14px;min-height:130px;border-radius:16px}
.heat.low{background:linear-gradient(180deg,rgba(120,144,156,.14),rgba(18,18,18,.98))}
.heat.mid{background:linear-gradient(180deg,rgba(255,179,0,.20),rgba(18,18,18,.98));border-color:rgba(255,179,0,.35)}
.heat.high{background:linear-gradient(180deg,rgba(255,92,92,.30),rgba(128,0,0,.25) 40%,rgba(18,18,18,.98));border-color:rgba(255,92,92,.5)}
.heat .core{font-family:var(--mono);font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}
.heat .num{margin-top:8px;font:700 28px var(--mono)}
.heat.high .num{color:#ffb4b4}.heat.mid .num{color:#ffd687}
.heat .pressure{margin-top:4px;font-family:var(--mono);font-size:11.5px;color:var(--muted)}
.heat .drivers{margin-top:10px;display:grid;gap:4px;font-size:12px;line-height:1.35}
.heat .drv{display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.heat .drv .dn{overflow-wrap:anywhere}
.heat .drv .dt{margin-left:8px;font-family:var(--mono);font-size:11px;color:var(--muted);white-space:nowrap}
.heat .drv.minor{opacity:.42}
.heat .tag{display:inline-block;margin-left:5px;padding:0 6px;border-radius:999px;font:10.5px/1.6 var(--mono);
background:rgba(79,195,247,.14);color:#9fdcf7;white-space:nowrap}
.heat .clash{margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,179,0,.35);color:#ffd687;
font:11.5px/1.5 var(--mono)}
.lines{margin-top:12px;display:grid;gap:7px;color:var(--muted);font-size:13.5px;line-height:1.55}
.lines b{color:var(--text);font-weight:600}
.conclusion{margin-top:14px;padding-top:12px;border-top:1px solid var(--line);font-size:13.5px;line-height:1.6}
.impact-list{display:grid;gap:10px}
.impact-item{padding:14px 18px;border-radius:16px;background:rgba(255,255,255,.03);border:1px solid var(--line);
border-left:4px solid var(--c)}
.impact-item.critical{--c:var(--critical-hi)}.impact-item.warning{--c:var(--warning)}.impact-item.info{--c:var(--info)}
.impact-item strong{font-family:var(--mono);font-size:13.5px}
.impact-item div{margin-top:6px;color:var(--muted);font-size:13.5px;line-height:1.55}
details{border:1px solid var(--line);border-radius:16px;margin:10px 0;padding:0 18px;background:rgba(255,255,255,.02)}
summary{cursor:pointer;padding:14px 0;font-weight:600}
summary .mono{color:var(--muted);font-weight:400;margin-left:10px;font-size:12px}
details[open] summary{border-bottom:1px solid var(--line);margin-bottom:6px}
pre{font-family:var(--mono);font-size:12px;white-space:pre-wrap;word-break:break-word;margin:0;color:#cfd8dd}
.ok-text{color:var(--good)}.fail-text{color:var(--critical-hi)}
.footer{margin-top:26px;font-family:var(--mono);font-size:12px;line-height:1.8;color:var(--muted)}
.path{word-break:break-all}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
@media (max-width:1180px){.hero,.grid2,.grid3,.stories,.causes{grid-template-columns:1fr}.grid4{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:520px){.grid4{grid-template-columns:1fr}.hero,.panel{padding:18px}}
@media print{body{background:#fff;color:#000}}
"""


# ---------------------------------------------------------------------------
def _e(x) -> str:
    return escape("" if x is None else str(x))


def _core_label(name: str | None) -> str:
    """Экземпляр счётчика «Processor Information» вида «группа,ядро» -> «CPU 3» (или «CPU 3, группа 1»)."""
    g, sep, c = (name or "").partition(",")
    if not sep or not g.strip().isdigit() or not c.strip().isdigit():
        return name or "—"
    return f"CPU {int(c)}" if int(g) == 0 else f"CPU {int(c)}, группа {int(g)}"


def _plural(n: int, one: str, few: str, many: str) -> str:
    """1 пункт, 2 пункта, 5 пунктов."""
    n = abs(n) % 100
    if 11 <= n <= 14:
        return many
    return one if n % 10 == 1 else few if 2 <= n % 10 <= 4 else many


def _n(x, nd: int = 2, suffix: str = "") -> str:
    if x is None:
        return "—"
    if isinstance(x, float):
        x = round(x, nd)
    return f"{x:,}".replace(",", "\u202f") + suffix      # узкий неразрывный пробел: число не переносится


def _panel(title: str, sub: str, body: str, caption: str = "") -> str:
    cap = f"<p>{_e(caption)}</p>" if caption else ""
    return (f'<section class="panel section"><div class="head"><div><h2>{_e(title)} <span>// {_e(sub)}</span></h2>'
            f'{cap}</div></div>{body}</section>')


def _bar(label: str, value_text: str, pct: float, tone: str) -> str:
    return (f'<div class="bar-row {tone}"><div class="bar-meta"><span class="bar-label">{_e(label)}</span>'
            f'<span class="bar-value">{_e(value_text)}</span></div><div class="bar-track">'
            f'<div class="bar-fill" style="--w:{max(0.0, min(100.0, pct)):.1f}"></div></div></div>')


def _short_vendor(v: str | None) -> str | None:
    """'American Megatrends International, LLC.' -> 'American Megatrends'."""
    if not v:
        return v
    for junk in (", LLC.", ", LLC", " LLC", " Inc.", ", Inc.", " Co., Ltd.", " Corporation", " International"):
        v = v.replace(junk, "")
    return v.strip(" ,.")


def _tier(score: int) -> tuple[str, str]:
    if score >= 900:
        return "good", "Optimal"
    if score >= 750:
        return "warning", "Precision tuning"
    if score >= 500:
        return "warning", "Degraded"
    return "critical", "Critical"


def _state(value, clean_below, warn_below) -> str:
    if value is None:
        return "info"
    return "clean" if value < clean_below else "warning" if value < warn_below else "critical"


class _Data:
    """Удобный доступ к метрикам проб."""

    def __init__(self, results: list[dict], analysis: dict, meta: dict):
        self.results = results
        self.a = analysis
        self.meta = meta
        self.m = {r["probe"]: r["raw_metrics_json"] for r in results if r["success"]}
        self.hw = self.m.get("HARDWARE_INFO", {})
        self.tracer = self.m.get("ETW_TRACER", {})
        self.sonar = self.m.get("ETW_SONAR")
        self.pm = self.m.get("PRESENT_MON", {})
        # Источник метрик кадра для сводок: игра, а если её не было — рабочий стол (dwm.exe)
        dwm = self.pm.get("dwm") or {}
        if self.pm.get("captured_frames"):
            self.fs, self.fs_label = self.pm, ""
        elif dwm.get("captured_frames"):
            self.fs, self.fs_label = dwm, " (dwm.exe)"
        else:
            self.fs, self.fs_label = {}, ""
        self.pf = self.m.get("PERFMON_ELITE", {})
        self.findings = [f for f in analysis["findings"] if f["severity"] != "ok"]

    def dpc_max(self):
        # Та же функция, что в правилах: DPC самого ядра (ntoskrnl.exe) и драйверов с числом DPC
        # не больше DPC_MAX_MIN_EVENTS не учитываются, цифры совпадают.
        v, _, kind = dpc_max(self.sonar, self.tracer)
        return v, kind

    def isr_max(self):
        if self.sonar:
            return self.sonar["isr"]["max_us"], "точно"
        return (self.tracer.get("isr") or {}).get("max_latency_bucket_us"), "верхняя граница"


# ---------------------------------------------------------------------------
def _hero(d: _Data) -> str:
    hw, a = d.hw, d.a
    bios = d.m.get("BIOS_FIRMWARE", {})
    mem = d.m.get("MEMORY_MANAGEMENT", {})
    crit = [f for f in d.findings if f["severity"] == "critical"]
    warn = [f for f in d.findings if f["severity"] == "warning"]
    if crit:
        lead = (f"Найдено {len(crit)} {_plural(len(crit), 'серьёзный источник', 'серьёзных источника', 'серьёзных источников')} "
                f"задержек: " + "; ".join(f["title"] for f in crit[:3]) + ". Начни с них: остальные пункты вторичны.")
    elif warn:
        verb = "влияет" if len(warn) == 1 else "влияют"
        lead = (f"Система работает, но {len(warn)} {_plural(len(warn), 'пункт', 'пункта', 'пунктов')} заметно {verb} "
                f"на отклик. {'Главный' if len(warn) == 1 else 'Главные'}: "
                + "; ".join(f["title"] for f in warn[:2]) + ".")
    else:
        lead = "Критичных источников задержек не найдено. Оставшиеся пункты относятся к тонкой настройке."
    tier_cls, tier_name = _tier(a["spi_score"])
    tier_cls = {"good": "tier-good", "warning": "tier-warning", "critical": "tier-critical"}[tier_cls]
    headroom = round((1000 - a["spi_score"]) / 10, 1)
    os_txt = hw.get("os") or "—"
    cards = [
        ("RAM profile", f'{_n(hw.get("ram_total_gb") or mem.get("total_gb"))} GB',
         f'Загрузка памяти: {mem["memory_load_percent"]}%' if mem.get("memory_load_percent") is not None else "—"),
        ("OS layer", os_txt.split(" (")[0], f'Build {hw.get("os_build") or "—"}'),
        ("BIOS / UEFI", _short_vendor(bios.get("bios_vendor")) or "—",
         ", ".join(filter(None, [bios.get("bios_version") or hw.get("bios_version"), bios.get("bios_date")])) or "—"),
        ("Trace ID", (d.meta.get("scan_id") or "—").upper()[:8], f'{d.meta.get("started")}, захват {d.meta.get("duration_s")} с'),
    ]
    card_html = "".join(f'<div class="card"><div class="label">{_e(k)}</div><div class="value">{_e(v)}</div>'
                        f'<div class="sub">{_e(s)}</div></div>' for k, v, s in cards)
    sub = " / ".join(filter(None, [(hw.get("gpus") or [{}])[0].get("name"), hw.get("motherboard")]))
    return (f'<header class="hero"><div><span class="eyebrow">Kernel_level // deep system forensics</span>'
            f'<h1>{_e(hw.get("cpu_name") or "KernelXray report")}</h1>'
            f'<div class="muted mono" style="margin-top:8px;font-size:13px">{_e(sub)}</div>'
            f'<p class="lead">{_e(lead)}</p><div class="grid4">{card_html}</div></div>'
            f'<div class="scorebox {tier_cls}"><div><div class="label" style="color:rgba(255,255,255,.75)">'
            f'System performance index</div><div class="score">{a["spi_score"]}<small> / 1000</small></div>'
            f'<div class="score-bar" style="--v:{a["spi_score"]}"><i></i></div>'
            f'<div class="score-row"><span>Запас: {headroom}%</span><span>{len(d.findings)} {_plural(len(d.findings), "находка", "находки", "находок")}</span></div></div>'
            f'<div><span class="tone">{_e(tier_name)}</span><p style="margin-top:14px;color:rgba(255,255,255,.85);'
            f'line-height:1.6">{_e(a["verdict"])}</p></div></div></header>')


def _verdict(d: _Data) -> str:
    total_pen = sum(f["penalty"] for f in d.findings)
    counts = {s: sum(1 for f in d.findings if f["severity"] == s) for s in ("critical", "warning", "info")}
    disp = d.fs.get("avg_ms_until_displayed")
    dmax, dkind = d.dpc_max()
    stories = [
        ("warning" if total_pen >= 150 else "clean", f"ACCUMULATED PENALTY // {total_pen} SPI",
         f'{counts["critical"]} серьёзных, {counts["warning"]} стоит поправить, {counts["info"]} к сведению. '
         f'Каждый пункт ниже привязан к измеренному значению.'),
    ]
    if disp is not None:
        stories.append(("clean" if disp < 2 else "warning", f"DISPLAY PATH // {disp:.2f} ms",
                        "Кадр быстро доходит до экрана: задержка не в видеотракте." if disp < 2 else
                        "Кадр заметно ждёт вывода: проверь режим презентации, VSync и ограничитель FPS."))
    else:
        stories.append(("info", "DISPLAY PATH // нет данных", "Во время захвата не было активного 3D-приложения."))
    if dmax is not None:
        st = dpc_state(dmax)
        txt = {"clean": f"Ни один отдельный DPC не длится дольше {DPC_WARN_US} мкс.",
               "warning": f"Есть DPC дольше {DPC_WARN_US} мкс. Это первый кандидат при жалобах на микрорывки.",
               "critical": f"Есть DPC от {DPC_CRIT_US} мкс: такие задержки слышны и видны. "
                           f"Разбор драйверов ниже."}[st]
        if any(f.get("id") == "ETW_BURST" for f in d.findings):
            txt += " Но короткие DPC/ISR шли сериями подряд — см. находку «Всплеск»."
        stories.append((st, f"LONGEST DPC // {dmax} μs", f"{txt} Значение: {dkind}."))
    body = '<div class="stories">' + "".join(
        f'<div class="story {c}"><strong>{_e(t)}</strong><div>{_e(x)}</div></div>' for c, t, x in stories) + "</div>"
    return _panel("Verdict", "почему такой индекс", body)


def _causes(d: _Data) -> str:
    top = sorted((f for f in d.findings if f["penalty"] > 0), key=lambda f: -f["penalty"])[:6]
    if not top:
        return _panel("Root cause vectors", "источники, а не симптомы",
                      '<p class="muted">Источников задержек, влияющих на индекс, не найдено.</p>')
    cards = []
    for f in top:
        # Сама программа ничего не исправляет: id известного исправления уходит только в профиль kcore
        fix = '<span class="fixable">есть известное исправление</span>' if f.get("fix_id") else ""
        cards.append(f'<article class="cause {f["severity"]}"><div class="top"><span class="penalty">'
                     f'Impact // -{f["penalty"]} SPI</span>{fix}</div><h3>{_e(f["title"])}</h3>'
                     f'<p><b>Почему:</b> {_e(f["detail"])}</p><p><b>Измерено:</b> {_e(f["evidence"])}</p>'
                     f'<p class="mono" style="font-size:11.5px">{_e(f["category"])}</p></article>')
    return _panel("Root cause vectors", "источники, а не симптомы", f'<div class="causes">{"".join(cards)}</div>',
                  "Самые дорогие по штрафу находки: что именно тянет индекс вниз.")


def _snapshot(d: _Data) -> str:
    a, pm, pf = d.a, d.fs, d.pf
    dmax, _ = d.dpc_max()
    imax, _ = d.isr_max()
    queue = (pf.get("avg") or {}).get("processor_queue_length")
    jitter = (d.m.get("SYSTEM_CORE", {}).get("wake_jitter_ms") or {}).get("p99")
    median = pm.get("median_ms_frame_time")
    p95 = pm.get("p95_ms_between_presents")
    ratio = (p95 / median) if p95 and median else None
    spi_state = "clean" if a["spi_score"] >= 900 else "warning" if a["spi_score"] >= 500 else "critical"
    cards = [
        (spi_state, "System performance index", f'{a["spi_score"]}/1000', f'Запас до идеала: {round((1000 - a["spi_score"]) / 10, 1)}%.'),
        (_state(pm.get("avg_ms_until_displayed"), 2, 5), "Display latency", _n(pm.get("avg_ms_until_displayed"), 2, " ms"),
         f"От отправки кадра до появления на экране, среднее{d.fs_label}."),
        (_state(ratio, 1.2, 1.5), "Frame p95", _n(p95, 2, " ms"),
         f'Медиана {_n(median, 2, " ms")}{d.fs_label}. Хвост распределения — это и есть ощущение рывков.'),
        (dpc_state(dmax), "Longest DPC", _n(dmax, 0, " μs"), f"Самый длинный DPC среди драйверов, у которых больше {DPC_MAX_MIN_EVENTS} событий за захват (без ntoskrnl.exe)."),
        (_state(imax, 100, 500), "ISR front-end", _n(imax, 0, " μs"), "Самый длинный обработчик прерывания."),
        (_state(queue, 1, 4), "Scheduler queue", "IDLE / 0.00" if queue == 0 else _n(queue, 2),
         "Средняя очередь готовых потоков: сколько потоков ждали свободное ядро."),
        (_state(jitter, 2, 3), "Wake jitter p99", _n(jitter, 2, " ms"), "Во сколько на деле превращается запрос «проснуться через 1 мс»."),
    ]
    html = "".join(f'<div class="tele {s}"><div class="label">{_e(k)}</div><div class="value">{_e(v)}</div>'
                   f'<div class="state">{_e({"clean": "clean", "warning": "watch", "critical": "critical", "info": "no data"}[s])}'
                   f'</div><div class="sub">{_e(t)}</div></div>' for s, k, v, t in cards)
    return _panel("Measured snapshot", "инструментальный слепок", f'<div class="telemetry">{html}</div>',
                  "Только измеренные значения этого запуска.")


def _etw_notes(d: _Data) -> list[str]:
    """Что было не так с трассой ядра и чем это закрыто (имена по снимку, неполный хвост)."""
    t = d.tracer or {}
    notes = []
    if t.get("ring_lost_head_s"):
        notes.append(f"начало трассы перезаписано кольцом ({_n(t['ring_lost_head_s'], 1)} с до F9)")
    if t.get("driver_names_from"):
        notes.append("имена драйверов восстановлены по снимку модулей ядра")
    elif any(x.get("driver", "").strip('"').lower() == "unknown" for x in (t.get("dpc") or {}).get("top_drivers", [])):
        notes.append("имена драйверов не определились (в трассе нет списка образов)")
    gaps = t.get("tail_gaps_s") or {}
    if gaps:
        worst = sorted(gaps.items(), key=lambda kv: -kv[1])
        notes.append("логгер не остановлен античитом, нет данных в конце окна: "
                     + ", ".join(f"CPU {c} −{s} с" for c, s in worst[:6]))
    return notes


def _integrity(d: _Data) -> str:
    by = {r["probe"]: r for r in d.results}
    def row(name, probe, text, partial=False):
        r = by.get(probe)
        ok = bool(r and r["success"])
        detail = text if ok else ("не запускалась" if not r else (r["error"] or "ошибка"))[:90]
        dot = ("part" if partial else "ok") if ok else "miss"
        return (f'<div class="integ"><div><strong>{_e(name)}</strong><br><span>{_e(detail)}</span></div>'
                f'<i class="dot {dot}"></i></div>')
    events = None
    if d.sonar:
        events = d.sonar["dpc"]["count"] + d.sonar["isr"]["count"]
    elif d.tracer:
        events = (d.tracer.get("dpc") or {}).get("event_count", 0) + (d.tracer.get("isr") or {}).get("event_count", 0)
    snaps = [r for r in d.results if r["probe"] not in ("ETW_TRACER", "ETW_SONAR", "PRESENT_MON", "PERFMON_ELITE")]
    snaps_ok = sum(1 for r in snaps if r["success"])
    notes = _etw_notes(d)
    gaps = bool((d.tracer or {}).get("tail_gaps_s"))
    body = ('<div class="integrity">'
            + row("ETW trace", "ETW_TRACER", "; ".join([f"Событий: {_n(events, 0)}"] + notes), partial=gaps)
            + row("ETW sonar", "ETW_SONAR", "Поэвентный разбор выполнен")
            + row("PresentMon", "PRESENT_MON", f'Кадров: {_n(d.pm.get("captured_frames"), 0)}')
            + row("PerfMon", "PERFMON_ELITE", f'Сэмплов: {_n(d.pf.get("sample_count"), 0)}')
            + f'<div class="integ"><div><strong>Config probes</strong><br><span>{snaps_ok} из {len(snaps)} выполнено</span></div>'
            f'<i class="dot {"ok" if snaps_ok == len(snaps) else "miss"}"></i></div></div>')
    return _panel("Capture integrity", "прозрачность источников", body,
                  "Если источник был недоступен, это указано явно. Недоступные данные не домысливаются.")


def _balance(d: _Data) -> str:
    subs = d.a.get("subsystems") or {}
    measured = {k: v for k, v in subs.items() if v is not None}
    rad = radar(list(measured.keys()), list(measured.values()))
    missing = [k for k, v in subs.items() if v is None]
    if missing:
        rad += f'<p class="muted">Нет данных: {_e(", ".join(missing))}</p>'
    counts = [("Critical", sum(1 for f in d.findings if f["severity"] == "critical"), RED),
              ("Warning", sum(1 for f in d.findings if f["severity"] == "warning"), AMBER),
              ("Info", sum(1 for f in d.findings if f["severity"] == "info"), INFO)]
    don = donut(counts, center_label="находок")
    legend = "".join(f'<span><i style="background:{c}"></i>{_e(k)}: {v}</span>' for k, v, c in counts)
    left = _panel("Subsystem balance", "где утекает производительность", f'<div class="chartbox">{rad}</div>',
                  "Чем ближе к краю, тем лучше. Провал оси показывает, какая подсистема тянет индекс вниз.")
    right = _panel("Severity weight", "распределение находок",
                   f'<div class="chartbox">{don}</div><div class="legend">{legend}</div>',
                   "Сколько находок каждой серьёзности. Штраф по умолчанию: critical 150, warning 60, info 15; "
                   "у отдельных пунктов он свой (указан в таблице находок), пункты, не влияющие на задержки, "
                   "идут без штрафа.")
    return f'<div class="grid2">{left}{right}</div>'


def _frame_block(st: dict, name: str, gid: str) -> str:
    """График времени кадра и сводка (FPS, рывки, задержка вывода) для одного процесса."""
    chart = area_chart(st.get("frame_time_series") or [], unit="время кадра, ms",
                       refs=[(st.get("p99_ms_between_presents") or 0, "p99")], gid=gid,
                       marks=st.get("foreign_stall_series_idx"), mark_title="совпал со сторонним выводом")
    modes = ", ".join(f"{k}: {v}" for k, v in (st.get("present_modes") or {}).items())
    dropped = st.get("dropped_frames")
    info = (f'<div class="lines"><div><b>{_e(name)}</b>: {_n(st.get("avg_fps"), 1)} FPS, '
            f'1% low {_n(st.get("fps_1pct_low"), 1)} FPS, p99 {_n(st.get("p99_ms_between_presents"), 2)} ms, '
            f'рывков {_n(st.get("stutter_frames"), 0)} из {_n(st.get("captured_frames"), 0)} кадров'
            + (f', не показано на экране {dropped}' if dropped else "") + '</div>'
            f'<div>Задержка вывода: <b>{_n(st.get("avg_ms_until_displayed"), 2, " ms")}</b> в среднем, '
            f'p99 <b>{_n(st.get("p99_ms_until_displayed"), 2, " ms")}</b></div>'
            f'<div>Режим вывода: {_e(modes)}</div>{_foreign_line(st)}</div>')
    return chart + info


def _foreign_line(st: dict) -> str:
    """Рывки, совпавшие с выводом второй поверхности в процессе игры (оверлей, всплывающее окно)."""
    n = st.get("foreign_presents") or 0
    if not n:
        return ""
    at = st.get("foreign_present_at_s") or []
    span = (f"на {_n(at[0], 1)} с" if len(at) == 1 else f"на {_n(at[0], 1)}–{_n(at[-1], 1)} с") if at else ""
    stalls = st.get("foreign_stall_frames") or 0
    text = (f'<b style="color:var(--cyan)">Сторонний вывод в процессе игры:</b> {n} '
            f'{_plural(n, "раз", "раза", "раз")} {span} захвата')
    if stalls:
        text += (f', с ним совпали {stalls} {_plural(stalls, "растянутый кадр", "растянутых кадра", "растянутых кадров")} '
                 f'(до {_n(st.get("foreign_stall_max_ms"), 2, " ms")}, на графике отмечены кружками)')
    text += (". Это вторая поверхность, которую выводит что-то внутри процесса игры: оверлей (Steam, Discord, "
             "EA app, AMD Adrenalin, RTSS) или античит. Драйверы и DPC здесь ни при чём. Чтобы найти источник, "
             "отключай оверлеи по одному и сравнивай прогоны.")
    return f"<div>{text}</div>"


PROC_NEAR_STALL_S = 0.5      # запуск процесса «рядом с рывком», если между ними не больше стольких секунд


def _process_line(d: _Data) -> str:
    """Какие процессы запускались во время захвата (трасса ядра) и совпали ли запуски с медленными кадрами."""
    started = ((d.sonar or {}).get("processes") or {}).get("started") or []
    if not started:
        return ""
    slow = d.pm.get("slow_frame_at_s") or []
    by: dict[str, list[dict]] = {}
    for p in started:
        by.setdefault(p["name"], []).append(p)
    parts, any_hit = [], False
    for name, rows in sorted(by.items(), key=lambda kv: -len(kv[1]))[:8]:
        times = ", ".join(_n(x["at_ms"] / 1000, 1) for x in rows[:6]) + ("…" if len(rows) > 6 else "")
        parent = next((x.get("parent") for x in rows if x.get("parent")), None)
        hits = sum(1 for x in rows if any(abs(x["at_ms"] / 1000 - s) <= PROC_NEAR_STALL_S for s in slow))
        text = (f"{_e(name)} ×{len(rows)} (на {times} с" + (f", запускает {_e(parent)}" if parent else "") + ")")
        if hits:
            any_hit = True
            text = f'<b style="color:var(--warning)">{text}, рядом с рывками: {hits}</b>'
        parts.append(text)
    tail = (" Запуски, совпавшие с рывками, выделены: закрой программу-источник и сравни." if any_hit else "")
    return (f'<div class="lines"><div><b>Запускались во время захвата:</b> {"; ".join(parts)}.{tail}</div></div>')


def _frames(d: _Data) -> str:
    pm = d.pm
    dwm = pm.get("dwm") or {}
    dwm_html = ""
    if dwm.get("captured_frames"):
        dwm_html = ('<h4>Рабочий стол Windows (dwm.exe)</h4>'
                    + _frame_block(dwm, "dwm.exe", "frames_dwm")
                    + '<p class="muted">Композитор Windows: ровный ритм здесь означает, что система сама '
                      'выводит кадры без задержек. Для полноэкранной игры он почти не рисует, это нормально.</p>')
    note = f'<p class="muted">{_e(pm["note"])}</p>' if pm.get("note") else ""
    seen = pm.get("observed_processes") or {}
    seen_html = (f'<p class="muted">Процессы с кадрами: {_e(", ".join(f"{a} ({n})" for a, n in seen.items()))}</p>'
                 if seen else "")

    if not pm.get("captured_frames"):
        failed = next((r.get("error") for r in d.results if r["probe"] == "PRESENT_MON" and not r["success"]), None)
        if failed or not dwm_html:
            reason = failed or pm.get("note") or "PresentMon не запускался."
            return _panel("Frame pacing trace", "ритм доставки кадров",
                          f'<p class="muted">{_e(reason)}</p>{seen_html}')
        return _panel("Frame pacing trace", "ритм доставки кадров", note + dwm_html + seen_html,
                      "Каждый пик — кадр, который пришёл позже соседей. Ровная линия означает ровную картинку.")

    game_html = _frame_block(pm, pm.get("application") or "?", "frames") + _process_line(d)
    return _panel("Frame pacing trace", "ритм доставки кадров", game_html + note + dwm_html + seen_html,
                  "Каждый пик — кадр, который пришёл позже соседей. Ровная линия означает ровную картинку.")


def _pipeline(d: _Data) -> str:
    pm = d.fs
    def avg_ms(kind):
        src = d.sonar[kind] if d.sonar else None
        if src and src["count"]:
            return src["total_ms"] / src["count"]
        t = d.tracer.get(kind) or {}
        return (t["total_time_ms"] / t["event_count"]) if t.get("event_count") else None
    stages = [("ISR front-end", avg_ms("isr"), "critical"), ("DPC execution", avg_ms("dpc"), "critical"),
              ("CPU busy", pm.get("avg_ms_cpu_busy"), "warning"), ("CPU wait", pm.get("avg_ms_cpu_wait"), "warning"),
              ("GPU busy", pm.get("avg_ms_gpu_busy"), "cyan"), ("GPU wait", pm.get("avg_ms_gpu_wait"), "cyan"),
              ("GPU latency", pm.get("avg_ms_gpu_latency"), "cyan"),
              ("Display queue" + d.fs_label, pm.get("avg_ms_until_displayed"), "good")]
    stages = [s for s in stages if s[1] is not None]
    if not stages:
        return ""
    peak = max(v for _, v, _ in stages) or 1
    bars = "".join(_bar(k, f"{v:.3f} ms" if v < 0.1 else f"{v:.2f} ms", v / peak * 100, tone) for k, v, tone in stages)
    return _panel("Latency pipeline", "где накапливаются миллисекунды", f'<div class="bar-chart">{bars}</div>',
                  "Средняя длительность каждого этапа. ISR и DPC — на одно событие, остальное — на кадр.")


def _matrix(d: _Data) -> str:
    rows = []
    for f in d.a["findings"]:
        fix = " | есть известное исправление" if f.get("fix_id") else ""
        impact = f'Impact: -{f["penalty"]} / 1000 SPI' if f["penalty"] else "Не влияет на индекс"
        rows.append(f'<tr><td><span class="badge {f["severity"]}">{SEV[f["severity"]]}</span></td>'
                    f'<td><b>{_e(f["title"])}</b><span class="impact">{impact}{fix}</span></td>'
                    f'<td>{_e(f["detail"])}</td><td class="mono" style="font-size:12.5px">{_e(f["evidence"])}</td></tr>')
    body = ('<div class="wrap-x"><table><tr><th>Status</th><th>Node</th><th>Почему и что делать</th>'
            '<th>Measured fact</th></tr>' + "".join(rows) + "</table></div>")
    return _panel("Findings matrix", "полная диагностическая карта", body)


def _collisions(d: _Data) -> str:
    if not d.sonar:
        return ""
    wins = d.sonar.get("worst_system_windows_1ms") or []
    if not wins:
        return ""
    cards = []
    for w in wins[:10]:
        mods = ", ".join(f'{m["module"]} ({m["us"]} μs)' for m in w.get("modules", []))
        hot = " hot" if w["busy_us"] >= 500 else ""
        cards.append(f'<div class="win{hot}"><strong>{_n(w["at_ms"], 0)} ms // {w["busy_us"]} μs</strong>'
                     f'<div>{_e(mods)}</div></div>')
    return _panel("ETW collision windows", "столкновения драйверов во времени", f'<div class="windows">{"".join(cards)}</div>',
                  "Миллисекунды, в которые драйверы суммарно (по всем ядрам) заняли больше всего времени.")


def _noise(d: _Data) -> str:
    raw = d.tracer.get("raw") or {}
    dur = d.tracer.get("trace_duration_s") or 0
    merged: dict[str, list] = {}
    for kind in ("dpc", "isr"):
        for name, m in (raw.get(kind) or {}).get("modules", {}).items():
            acc = merged.setdefault(name, [0, 0])
            acc[0] += m.get("count", 0)
            acc[1] += m.get("total_us", 0)
    if not merged:
        return ""
    top = sorted(merged.items(), key=lambda kv: -kv[1][1])[:8]
    peak = max(t for _, (_, t) in top) or 1
    bars = []
    for name, (cnt, tot) in top:
        avg = tot / cnt if cnt else 0
        tone = "critical" if avg >= 20 else "warning" if avg >= 8 else "info"
        rate = cnt / dur if dur else 0
        bars.append(_bar(name, f"{_n(round(rate), 0)} hits/sec // avg {avg:.1f} μs // total {_n(tot, 0)} μs",
                         tot / peak * 100, tone))
    return _panel("Interrupt noise radar", "кто генерирует шум", f'<div class="bar-chart">{"".join(bars)}</div>',
                  "DPC и прерывания вместе. Длина полосы — суммарное время ядра; цвет — средняя длительность события.")


_TAG = {**KIND_LABEL, "gpu": "GPU"}      # короткие метки устройств на карте ядер


def _warzone(d: _Data) -> str:
    heat = d.tracer.get("heatmap") or {}
    if not heat:
        return ""
    # Те же функции, что в правиле CORE_COLLISION: карта и находка не могут разойтись.
    devices = (d.m.get("CORE_COLLISION") or {}).get("devices")
    cmap = core_map(d.tracer, devices)
    hits = {h["cpu"]: h for h in find_collisions(d.tracer, devices)}
    ncpu = max([int(k) for k in heat] + list(cmap)) + 1
    thr = f"{COLLISION_MIN_SHARE_PCT:g}".replace(".", ",")
    cards = []
    for cpu in range(ncpu):
        h = heat.get(str(cpu), {})
        pct = h.get("percent") or 0
        cls = "high" if pct >= 3 else "mid" if pct >= 1 else "low"
        rows = cmap.get(cpu) or [{"driver": n, "us": None, "share_pct": None, "kinds": [], "devices": [], "counts": True}
                                 for n in h.get("drivers", [])]
        lines = []
        for r in rows:
            tag = "/".join(_TAG[k] for k in r["kinds"])
            tip = r["driver"]
            if r["us"] is not None:
                tip += f": {fmt_us(r['us'])} за захват"
            if r["share_pct"] is not None:
                tip += f", {r['share_pct']:.3f}% времени ядра".replace(".", ",")
            if r["devices"]:
                tip += "; устройство: " + ", ".join(r["devices"])
            elif r["kinds"] == ["kmdf"]:
                tip += "; фреймворк KMDF, устройство за ним по трассе не определить"
            if not r["counts"]:
                tip += f"; меньше {thr}% — фон, в поиске столкновений не участвует"
            t = "" if r["us"] is None else (f'{_n(r["us"] / 1000, 1)} ms' if r["us"] >= 1000 else f'{r["us"]} μs')
            tag_html = f'<span class="tag">{_e(tag)}</span>' if tag else ""
            minor = "" if r["counts"] else " minor"
            lines.append(f'<div class="drv{minor}" title="{_e(tip)}"><span class="dn">{_e(r["driver"])}{tag_html}</span>'
                         f'<span class="dt">{t}</span></div>')
        hit = hits.get(cpu)
        clash = ""
        if hit:
            others = " + ".join(KIND_LABEL[k] for k in ("net", "usb", "audio", "kmdf") if k in hit["others"])
            clash = f'<div class="clash">столкновение: видеокарта + {_e(others)}</div>'
        cards.append(f'<div class="heat {cls}"><div class="core">CPU {cpu}</div><div class="num">{pct:.2f}%</div>'
                     f'<div class="pressure">Total pressure: {_n(h.get("usecs", 0), 0)} μs</div>'
                     f'<div class="drivers">{"".join(lines)}</div>{clash}</div>')
    return _panel("Thread warzone", "карта конфликтов по ядрам", f'<div class="heatmap">{"".join(cards)}</div>',
                  "Доля времени каждого ядра, ушедшая на DPC и прерывания, и все драйверы на нём с временем за захват. "
                  "Красное: больше 3%, янтарное: больше 1%. "
                  f"Бледным — драйверы с долей меньше {thr}%: это фон, в поиске столкновений они не участвуют. "
                  "Метка показывает устройство; у Wdf01000.sys — то, чьи прерывания закреплены за этим ядром.")


def _paths(d: _Data) -> str:
    pm, pf = d.fs, d.pf
    avg = pf.get("avg") or {}
    dmax, _ = d.dpc_max()
    imax, _ = d.isr_max()
    frame = pm.get("avg_ms_between_presents")
    if frame and pm.get("avg_ms_gpu_busy") and pm["avg_ms_gpu_busy"] >= 0.9 * frame:
        disp_c = "Видеокарта загружена почти полностью: кадр ограничен GPU."
    elif frame and pm.get("avg_ms_cpu_busy") and pm["avg_ms_cpu_busy"] >= 0.9 * frame:
        disp_c = "Процессор занят почти весь кадр: частота кадров упирается в CPU, а не в видеокарту."
    elif frame:
        disp_c = "Ни CPU, ни GPU не загружены полностью: кадр ограничен лимитом FPS или синхронизацией."
    else:
        disp_c = "Нет данных о кадрах."
    events = None
    if d.sonar:
        events = (d.sonar["dpc"]["count"], d.sonar["isr"]["count"])
    elif d.tracer:
        events = ((d.tracer.get("dpc") or {}).get("event_count"), (d.tracer.get("isr") or {}).get("event_count"))
    tops = ", ".join(x["driver"] for x in (d.tracer.get("dpc") or {}).get("top_drivers", [])[:3])
    kern_c = ("Длительность событий в норме: нагрузка ядра складывается из частоты, а не из отдельных длинных DPC."
              if dpc_state(dmax) in ("clean", "info") else "Есть длинные события: смотри драйвер в таблице ниже.")
    queue = avg.get("processor_queue_length")
    sched_c = ("Очереди готовых потоков почти нет: ядер хватает, игра не ждёт процессор."
               if (queue or 0) < 1 else "Потоки ждут свободное ядро: фоновая нагрузка конкурирует с игрой.")
    stories = [
        ("Display path" + d.fs_label, "что вы видите", [
            f'Средняя задержка вывода: <b>{_n(pm.get("avg_ms_until_displayed"), 2, " ms")}</b>',
            f'P99 задержки вывода: <b>{_n(pm.get("p99_ms_until_displayed"), 2, " ms")}</b>',
            f'CPU busy / GPU busy: <b>{_n(pm.get("avg_ms_cpu_busy"), 2)} / {_n(pm.get("avg_ms_gpu_busy"), 2)} ms</b> '
            f'при кадре {_n(frame, 2, " ms")}'], disp_c),
        ("Kernel path", "что происходит внутри", [
            f'Max DPC / ISR: <b>{_n(dmax, 0)} μs / {_n(imax, 0)} μs</b>',
            f'Событий: <b>DPC {_n(events[0] if events else None, 0)}, ISR {_n(events[1] if events else None, 0)}</b>',
            f'Главные драйверы: <b>{_e(tops or "—")}</b>'], kern_c),
        ("Scheduler path", "как ядро распределяет нагрузку", [
            f'Очередь процессора: <b>{"IDLE / 0.00" if queue == 0 else _n(queue, 2)}</b>',
            f'Прерывания / переключения контекста: <b>{_n(avg.get("interrupts_per_sec"), 1)} / '
            f'{_n(avg.get("context_switches_per_sec"), 1)} в секунду</b>',
            f'Горячее ядро по прерываниям: <b>{_e(_core_label(pf.get("hottest_core")))}</b>'], sched_c),
    ]
    cards = "".join(f'<div class="panel"><div class="head"><h2>{_e(t)} <span>// {_e(s)}</span></h2></div>'
                    f'<div class="lines">{"".join("<div>" + x + "</div>" for x in lines)}</div>'
                    f'<div class="conclusion">{_e(c)}</div></div>' for t, s, lines, c in stories)
    return f'<div class="grid3 section">{cards}</div>'


DPC_DIST_ATTR_FROM_US = 128   # начиная с этой длительности показываем, какие драйверы её дали
ISR_DIST_ATTR_FROM_US = 32    # для прерываний порог ниже: нормальный ISR — единицы μs


def _latency_distribution(raw: dict, kind: str, thr: int) -> str:
    """Полное распределение длительности (корзины 2^n, без изменений), а ниже —
    для длинных событий (от thr μs) какие драйверы дали такую задержку."""
    hist = raw.get("histogram") or []
    if not hist:
        return ""
    modules = raw.get("modules") or {}

    def drivers_in(lo: int, hi: int) -> list[tuple[str, int]]:
        agg: dict[str, int] = {}
        for name, m in modules.items():
            for blo, bhi, bc in m.get("histogram", []):
                if bc > 0 and blo >= lo and bhi <= hi:
                    agg[name] = agg.get(name, 0) + bc
        return sorted(agg.items(), key=lambda kv: -kv[1])

    rows = []
    for lo, hi, c in hist:
        if lo < thr or c == 0:
            continue
        who = drivers_in(lo, hi)[:3]
        who_txt = ", ".join(f"{_e(n)} ({_n(k, 0)})" for n, k in who) or "—"
        rows.append(f'<tr><td class="mono">{lo}–{hi} μs</td><td class="n">{_n(c, 0)}</td><td>{who_txt}</td></tr>')

    if rows:
        attr = (f'<div class="wrap-x" style="margin-top:14px"><table><tr><th>Длительность {kind}</th>'
                '<th class="n">Событий</th><th>Драйверы (число событий)</th></tr>' + "".join(rows) + "</table></div>")
    else:
        attr = (f'<p class="muted" style="margin-top:12px">{kind} длиннее {thr} μs не зафиксировано — '
                f'драйверов с такой задержкой нет.</p>')

    return (f'<div class="label" style="margin-top:26px">Распределение длительности {kind}</div>'
            + histogram(hist) + attr)


def _contrib_panel(d: _Data, key: str, title: str, subtitle: str, thr: int) -> str:
    sec = d.tracer.get(key) or {}
    top = sec.get("top_drivers") or []
    if not top:
        return ""
    peak = max(x["time_us"] for x in top) or 1
    bars = "".join(_bar(x["driver"], f'{x["time_us"] / 1000:.2f} ms kernel time', x["time_us"] / peak * 100,
                        "warning" if i == 0 else "info") for i, x in enumerate(top[:6]))
    exact = {m["module"]: m["max_us"] for m in ((d.sonar or {}).get(key) or {}).get("modules_by_max", [])}
    rows = "".join(
        f'<tr><td class="mono">{_e(x["driver"])}</td><td class="n">{_n(x["count"], 0)}</td><td class="n">{_n(x["avg_us"], 2)} μs</td>'
        f'<td class="n">{_e(exact.get(x["driver"], "≤" + str(x["max_latency_bucket_us"])))} μs</td>'
        f'<td class="n">{_e(", ".join(map(str, x["cpus"][:6])) + ("…" if len(x["cpus"]) > 6 else ""))}</td></tr>' for x in top)
    table = ('<div class="wrap-x" style="margin-top:22px"><table><tr><th>Driver</th><th class="n">Events</th>'
             '<th class="n">Avg latency</th><th class="n">Max</th><th class="n">CPU</th></tr>' + rows + "</table></div>")
    raw = (d.tracer.get("raw") or {}).get(key) or {}
    dist = _latency_distribution(raw, key.upper(), thr)
    return _panel(title, subtitle, f'<div class="bar-chart">{bars}</div>{table}{dist}',
                  "Доля времени ядра, которую забирает каждый драйвер. «≤» означает верхнюю границу корзины, "
                  "если поэвентного разбора нет.")


def _contributors(d: _Data) -> str:
    return _contrib_panel(d, "dpc", "Top DPC contributors", "кто забирает kernel time", DPC_DIST_ATTR_FROM_US)


def _isr_contributors(d: _Data) -> str:
    return _contrib_panel(d, "isr", "Top ISR contributors", "кто грузит ядро прерываниями", ISR_DIST_ATTR_FROM_US)


def _impact_map(d: _Data) -> str:
    top = sorted((f for f in d.findings if f["penalty"] > 0), key=lambda f: -f["penalty"])[:6]
    if not top:
        return ""
    items = "".join(f'<div class="impact-item {f["severity"]}"><strong>{_e(f["title"])} // -{f["penalty"]} SPI</strong>'
                    f'<div>{_e(f["detail"])}</div></div>' for f in top)
    return _panel("SPI impact map", "что снизило индекс", f'<div class="impact-list">{items}</div>')


def _fmt(v) -> str:
    if isinstance(v, bool):
        return "да" if v else "нет"
    if v is None:
        return '<span class="muted">—</span>'
    if isinstance(v, (dict, list)):
        text = json.dumps(v, ensure_ascii=False, indent=1)
        return "<pre>" + _e(text[:1500] + ("\n…" if len(text) > 1500 else "")) + "</pre>"
    return _e(v)


def _config(d: _Data) -> str:
    skip = {"ETW_TRACER", "ETW_SONAR", "PRESENT_MON", "PERFMON_ELITE"}
    out = []
    for r in d.results:
        if r["probe"] in skip:
            continue
        title = PROBE_TITLES.get(r["probe"], r["probe"])
        if not r["success"]:
            out.append(f'<details><summary>{_e(title)}<span class="mono">{_e(r["probe"])} // failed</span></summary>'
                       f'<p class="fail-text" style="padding-bottom:14px">{_e(r["error"])}</p></details>')
            continue
        rows = "".join(f'<tr><td class="mono" style="font-size:12.5px;width:34%">{_e(k)}</td><td>{_fmt(v)}</td></tr>'
                       for k, v in r["raw_metrics_json"].items() if not k.startswith("_") and k != "raw")
        out.append(f'<details><summary>{_e(title)}<span class="mono">{_e(r["probe"])}</span></summary>'
                   f'<div class="wrap-x"><table>{rows}</table></div></details>')
    return _panel("System configuration", "полный слепок конфигурации", "".join(out),
                  "Сырые значения всех проб конфигурации. Разверни нужный раздел.")


def _detect_anticheat(d: "_Data") -> tuple[str | None, str | None]:
    """Активный античит по данным пробы PROCESSES: полный список процессов, служб и драйверов."""
    acs = (d.m.get("PROCESSES") or {}).get("anticheats") or []
    active = next((a for a in acs if a.get("running")), None)
    if active:
        return active["title"], ", ".join(active.get("evidence") or []) or None
    return None, None


def _anticheat_notice(d: "_Data") -> str:
    """Плашка: если kernel ETW упал с access denied, а в системе активен kernel-античит —
    объясняем, что это ожидаемо, а не сбой программы."""
    r = next((x for x in d.results if x["probe"] == "ETW_TRACER"), None)
    if not r or r.get("success"):
        return ""
    err = (r.get("error") or "").lower()
    if not ("0x5" in err or "access denied" in err or "отказано в доступе" in err):
        return ""
    friendly, proc = _detect_anticheat(d)
    if not friendly:
        return ""
    return (
        '<section class="panel section" style="border-left:4px solid var(--warning)">'
        '<div class="head"><div><h2>Kernel-трассировка заблокирована античитом '
        '<span>// это ожидаемо, не сбой программы</span></h2>'
        f'<p>Во время захвата был активен античит уровня ядра — <b>{_e(friendly)}</b> '
        f'({_e(proc)}). Такие античиты не дают сторонним инструментам поднять '
        'kernel ETW-сессию, поэтому трасса ядра (DPC/ISR) вернула «отказано в доступе» (0x5). '
        'Остальные метрики в отчёте собраны штатно.</p></div></div>'
        '<p class="muted">Что делать: закрой игру и убедись, что сервис античита остановлен — '
        'он часто продолжает работать и после выхода из игры, — затем запусти KernelXray снова. '
        'Либо снимай латентность в игре без kernel-античита.</p>'
        '</section>'
    )


def render_report(path: Path, results: list[dict], analysis: dict, meta: dict) -> None:
    d = _Data(results, analysis, meta)
    body = "".join([
        _hero(d), _verdict(d), _anticheat_notice(d), _causes(d), _snapshot(d), _integrity(d), _balance(d), _frames(d), _pipeline(d),
        _matrix(d), _collisions(d), _noise(d), _warzone(d), _paths(d), _contributors(d), _isr_contributors(d),
        _impact_map(d),
        _config(d),
    ])
    footer = (f'<div class="footer">KernelXray {_e(meta.get("version"))} // generated {_e(meta.get("started"))}'
              f'<div class="path">{_e(meta.get("out_dir") or "")}</div></div>')
    title = _e(meta.get("started"))
    html = ('<!doctype html><html lang="ru"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>KernelXray // Kernel Level Report {title}</title><style>{CSS}</style></head>"
            f'<body><div class="wrap">{body}{footer}</div></body></html>')
    Path(path).write_text(html, encoding="utf-8")
