"""Точка входа для сборки в exe (Nuitka / PyInstaller).

Любая ошибка при запуске (включая ошибки импорта) пишется в kernelxray_crash.log
рядом с exe, а окно не закрывается, пока пользователь не нажмёт Enter.
"""
import sys
import os
import faulthandler

# --- Самое первое: сигнал, что Python стартовал, и перехват нативных падений ---
print("KernelXray: Python запущен", flush=True)
try:
    _fault_log = open(
        os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "kernelxray_fault.log"),
        "w", encoding="utf-8",
    )
except OSError:
    _fault_log = open(os.path.join(os.environ.get("TEMP", "."), "kernelxray_fault.log"),
                      "w", encoding="utf-8")
# При нативном падении (0xC0000005 и т.п.) стек всех потоков пишется в этот файл.
# faulthandler умеет писать только в одно место, поэтому выбран файл: он переживёт закрытие окна.
faulthandler.enable(file=_fault_log, all_threads=True)
print(f"KernelXray: лог нативных падений -> {_fault_log.name}", flush=True)

import traceback  # noqa: E402
import datetime  # noqa: E402


def _exe_dir():
    # sys.argv[0] указывает на настоящий exe и в PyInstaller, и в Nuitka onefile
    # (sys.executable в onefile может указывать во временную папку распаковки)
    return os.path.dirname(os.path.abspath(sys.argv[0]))


def _launched_by_double_click():
    # Консоль создана для нашего процесса (её открыл Проводник) и закроется вместе с программой.
    # Признаки: к консоли подключены только мы, либо окно консоли числится за нашим процессом
    # (при запуске с запросом прав или в терминале Windows к консоли бывает подключён ещё кто-то).
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        buf = (ctypes.c_uint * 4)()
        if k32.GetConsoleProcessList(buf, 4) <= 1:
            return True
        k32.GetConsoleWindow.restype = ctypes.c_void_p
        hwnd = k32.GetConsoleWindow()
        if not hwnd:
            return False
        pid = ctypes.c_ulong(0)
        ctypes.windll.user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid))
        return pid.value == os.getpid()
    except Exception:
        return False


def _pause():
    if _launched_by_double_click():
        try:
            input("\nНажми Enter для выхода...")
        except Exception:
            pass


def _write_crash_log():
    text = (
        f"Время: {datetime.datetime.now()}\n"
        f"Python: {sys.version}\n"
        f"Windows: {sys.getwindowsversion() if hasattr(sys, 'getwindowsversion') else '?'}\n"
        f"Аргументы: {sys.argv}\n\n"
        + traceback.format_exc()
    )
    for folder in (_exe_dir(), os.environ.get("TEMP", ".")):
        path = os.path.join(folder, "kernelxray_crash.log")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            return path
        except OSError:
            continue
    return None


if __name__ == "__main__":
    code = 1
    asked = False
    try:
        if sys.version_info < (3, 10):
            raise RuntimeError("KernelXray требует Python 3.10 или новее")
        # Импорт внутри try: ошибки вроде отсутствующего модуля pywin32 тоже попадут в лог
        from kernelxray.__main__ import main
        code = main() or 0
        import kernelxray.__main__ as _kx
        asked = _kx.FINAL_PROMPT_SHOWN      # выбор «открыть / закрыть» уже сделан, вторая пауза не нужна
    except KeyboardInterrupt:
        print("\nПрервано пользователем.")
        code = 130
    except SystemExit as e:
        # argparse и sys.exit() внутри программы: не считаем это падением
        code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        if e.code not in (None, 0) and not isinstance(e.code, int):
            print(e.code)
    except BaseException:
        traceback.print_exc()
        log_path = _write_crash_log()
        print("\nKernelXray завершился с ошибкой.")
        if log_path:
            print(f"Подробности записаны в {log_path}")
            print("Пришли этот файл разработчику.")
    if not asked:
        _pause()
    sys.exit(code)
