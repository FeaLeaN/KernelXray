@echo off
chcp 65001 >nul
setlocal
rem Проверка захвата кадров PresentMon без KernelXray. Положи рядом с exe KernelXray (там, где папка tools).
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  echo Запусти этот файл от имени администратора: правый клик - "Запуск от имени администратора".
  pause
  exit /b 1
)

set "PM="
for %%f in (tools\PresentMon*.exe) do set "PM=%%f"
if not defined PM (
  echo PresentMon не найден в папке tools\
  pause
  exit /b 1
)

set "XPERF="
if exist "tools\xperf.exe" set "XPERF=tools\xperf.exe"
if not defined XPERF if exist "%ProgramFiles(x86)%\Windows Kits\10\Windows Performance Toolkit\xperf.exe" set "XPERF=%ProgramFiles(x86)%\Windows Kits\10\Windows Performance Toolkit\xperf.exe"
if not defined XPERF if exist "%ProgramFiles%\Windows Kits\10\Windows Performance Toolkit\xperf.exe" set "XPERF=%ProgramFiles%\Windows Kits\10\Windows Performance Toolkit\xperf.exe"

set "OUT=frames_test"
if exist "%OUT%" rmdir /S /Q "%OUT%"
mkdir "%OUT%"

logman stop KX_Test -ets >nul 2>&1
if defined XPERF "%XPERF%" -stop >nul 2>&1

echo.
echo Включи видео в браузере или игру (в окне, чтобы видеть этот текст).
echo Три теста по 10 секунд, всего около 40 секунд. Старт через 5 с...
timeout /t 5 /nobreak >nul

echo.
echo [1/3] PresentMon один, запись в файл
"%PM%" --output_file "%OUT%\1_alone_file.csv" --timed 10 --terminate_after_timed --no_console_stats --session_name KX_Test --stop_existing_session 2> "%OUT%\1_alone_file_console.txt"
echo       код выхода %errorlevel%

echo [2/3] PresentMon один, запись через stdout (как в KernelXray)
"%PM%" --output_stdout --timed 10 --terminate_after_timed --no_console_stats --session_name KX_Test --stop_existing_session > "%OUT%\2_alone_stdout.csv" 2> "%OUT%\2_alone_stdout_console.txt"
echo       код выхода %errorlevel%

if not defined XPERF (
  echo [3/3] пропущен: xperf.exe не найден
  goto :summary
)
echo [3/3] PresentMon одновременно с xperf (трасса ядра, как в KernelXray)
"%XPERF%" -on PROC_THREAD+LOADER+DPC+INTERRUPT+HARD_FAULTS+FILENAME -f "%OUT%\kernel.etl" -BufferSize 512 -MinBuffers 64 -MaxBuffers 320 > "%OUT%\3_xperf_console.txt" 2>&1
"%PM%" --output_file "%OUT%\3_with_xperf.csv" --timed 10 --terminate_after_timed --no_console_stats --session_name KX_Test --stop_existing_session 2> "%OUT%\3_with_xperf_console.txt"
echo       код выхода %errorlevel%
"%XPERF%" -stop >> "%OUT%\3_xperf_console.txt" 2>&1
del /Q "%OUT%\kernel.etl" >nul 2>&1

:summary
logman stop KX_Test -ets >nul 2>&1
powershell -NoProfile -Command ^
  "$o = '%OUT%'; $r = @();" ^
  "foreach ($n in '1_alone_file','2_alone_stdout','3_with_xperf') {" ^
  "  $csv = Join-Path $o ($n + '.csv'); $con = Join-Path $o ($n + '_console.txt');" ^
  "  $rows = if (Test-Path $csv) { [Math]::Max(0, @(Get-Content $csv).Count - 1) } else { 'no file' };" ^
  "  $msg = if (Test-Path $con) { ((Get-Content $con) -join ' ').Trim() } else { '' };" ^
  "  $apps = if ((Test-Path $csv) -and $rows -gt 0) { (Import-Csv $csv | Group-Object Application | Sort-Object Count -Descending | Select-Object -First 5 | ForEach-Object { $_.Name + ' ' + $_.Count }) -join ', ' } else { '' };" ^
  "  $r += ('{0}: frames {1}. {2} {3}' -f $n, $rows, $apps, $msg) };" ^
  "$r | Tee-Object -FilePath (Join-Path $o 'summary.txt') | Write-Host"

echo.
echo Итог сохранён в %OUT%\summary.txt. Пришли эту папку целиком.
pause
