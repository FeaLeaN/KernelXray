"""Режим --arm под античитом: имена драйверов без rundown, неполный хвост трассы, сторонний вывод в игре,
фиксированный запуск и версия сборки."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import build_version  # noqa: E402
from kernelxray.analysis.attribution import backfill_driver_names  # noqa: E402
from kernelxray.analysis.rules import evaluate  # noqa: E402
from kernelxray.core.kmodules import ModuleMap, parse_address  # noqa: E402
from kernelxray.core.probe import ProbeResult  # noqa: E402
from kernelxray.parsers.dpcisr import parse_dpcisr_file, summarize, tail_gaps  # noqa: E402
from kernelxray.parsers.dumper import parse_dumper  # noqa: E402
from kernelxray.parsers.presentmon import parse_presentmon_csv  # noqa: E402
from kernelxray.report.html_report import render_report  # noqa: E402
from test_pipeline import ok, sample_results  # noqa: E402

FX = ROOT / "tests" / "fixtures"

MODS = [(0xFFFFF80210000000, 0x200000, "ntoskrnl.exe"),
        (0xFFFFF80230000000, 0x1000000, "amdkmdag.sys"),
        (0xFFFFF80250000000, 0x100000, "Wdf01000.sys")]

# Дамп xperf без rundown: вместо имени драйвера Unknown, адрес процедуры есть
DUMP_UNKNOWN = """BeginHeader
                    DPC,  TimeStamp, ElapsedTime, CPU,        ServiceAddr,            Image!Function
              Interrupt,  TimeStamp, ElapsedTime, CPU, Vector, MessageIndex,     Status,        ServiceAddr,            Image!Function
              HardFault,  TimeStamp,     Process Name ( PID),   ThreadID,     VirtualAddress,  ByteOffset,     IOSize, ElapsedTime,          FileObject, FileName
EndHeader
                    DPC,          0,        40,   0, 0xfffff80230001234,     Unknown
                    DPC,       1000,       300,   0, 0xfffff80230001234,     Unknown
                    DPC,       2000,         3,   6, 0xfffff80250000100,     "Unknown"
              Interrupt,       2100,         2,   6,   0xa0,          0,          1, 0xfffff80250000200,     Unknown
                    DPC,       3000,         7,   2, 0xfffff80299999999,     Unknown
                    DPC,       4000,         5,   0, 0xfffff80210000500,     Unknown
              HardFault,       4500,  "Unknown" ( 4100),       200, 0x00007ff600001000,  0x00001000,     0x8000,        150, 0xffffc00000000001, \\Device\\HarddiskVolume3\\pagefile.sys
"""


def test_module_map_lookup():
    m = ModuleMap(MODS)
    assert m.lookup(0xFFFFF80230001234) == "amdkmdag.sys"
    assert m.lookup(0xFFFFF80210000000) == "ntoskrnl.exe"          # первый байт образа
    assert m.lookup(0xFFFFF80210200000) is None                     # сразу за концом ntoskrnl
    assert m.lookup(0x1000) is None and m.lookup(None) is None
    m.add([(0xFFFFF80260000000, 0x1000, "EasyAntiCheat_EOS.sys")])  # второй снимок: драйвер пришёл с игрой
    assert m.lookup(0xFFFFF80260000010) == "EasyAntiCheat_EOS.sys" and len(m) == 4
    assert parse_address("0xfffff80230001234") == 0xFFFFF80230001234
    assert parse_address("Unknown") is None and parse_address("0x0") is None


def test_dumper_resolves_unknown_by_address():
    d = parse_dumper(DUMP_UNKNOWN.splitlines(), resolve=ModuleMap(MODS).lookup, pid_names={4100: "r5apex_dx12.exe"})
    by = {m["module"]: m for m in d["dpc"]["modules_by_max"]}
    assert by["amdkmdag.sys"]["max_us"] == 300 and by["amdkmdag.sys"]["count"] == 2
    assert by["Wdf01000.sys"]["count"] == 1 and by["ntoskrnl.exe"]["count"] == 1
    assert by["Unknown"]["count"] == 1                              # адрес вне всех модулей так и остался
    assert d["isr"]["modules_by_max"][0]["module"] == "Wdf01000.sys"
    nr = d["name_resolution"]
    assert nr["resolved_events"] == 5 and nr["unresolved_events"] == 1
    det = d["modules_detail"]["dpc"]["amdkmdag.sys"]
    assert det["per_cpu_us"][0] == 340 and det["count"] == 2
    assert det["histogram"] == [[32, 64, 1], [256, 512, 1]]         # корзины как у xperf -a dpcisr
    assert d["hard_faults"]["top_processes"][0]["process"] == "r5apex_dx12.exe"


def test_dumper_without_resolver_is_unchanged():
    d = parse_dumper(DUMP_UNKNOWN.splitlines())
    assert {m["module"] for m in d["dpc"]["modules_by_max"]} == {"Unknown"}
    assert "modules_detail" not in d and "name_resolution" not in d


def _unknown_tracer() -> dict:
    parsed = parse_dpcisr_file(FX / "dpcisr_sample.txt")
    for key in ("dpc", "isr"):                                      # как в трассе без rundown: всё в Unknown
        mods = parsed[key]["modules"]
        ncpu = parsed[key]["cpu_count"]
        merged = {"per_cpu_us": [sum(m["per_cpu_us"][i] if i < len(m["per_cpu_us"]) else 0 for m in mods.values())
                                 for i in range(ncpu)],
                  "total_us": sum(m["total_us"] for m in mods.values()),
                  "count": sum(m["count"] for m in mods.values()), "histogram": parsed[key]["histogram"]}
        parsed[key]["modules"] = {'"Unknown"': merged}
    t = summarize(parsed)
    t["raw"] = parsed
    return t


def test_backfill_replaces_unknown_in_tracer():
    tracer = _unknown_tracer()
    assert tracer["dpc"]["top_drivers"][0]["driver"] == '"Unknown"'
    sonar = parse_dumper(DUMP_UNKNOWN.splitlines(), resolve=ModuleMap(MODS).lookup)
    results = [ProbeResult("ETW_TRACER", True, None, 1.0, tracer), ProbeResult("ETW_SONAR", True, None, 1.0, sonar)]
    assert backfill_driver_names(results)
    t = results[0].raw_metrics_json
    names = [x["driver"] for x in t["dpc"]["top_drivers"]]
    assert names[0] == "amdkmdag.sys" and '"Unknown"' not in names
    assert "amdkmdag.sys" in t["heatmap"]["0"]["drivers"] and "Wdf01000.sys" in t["heatmap"]["6"]["drivers"]
    assert t["driver_names_from"] and t["dpc"]["event_count"] == tracer["dpc"]["event_count"]
    # отчёт рисуется с настоящими именами и говорит, откуда они
    res = [r for r in sample_results() if r["probe"] not in ("ETW_TRACER", "ETW_SONAR")] + [x.to_dict() for x in results]
    out = ROOT / "tests" / "_tmp_report.html"
    try:
        render_report(out, res, evaluate(res), {"started": "2026-09-30 05:09", "duration_s": 30, "version": "t"})
        html = out.read_text(encoding="utf-8")
        assert "имена драйверов восстановлены по снимку модулей ядра" in html
    finally:
        out.unlink(missing_ok=True)


def test_backfill_keeps_xperf_names_when_resolved():
    parsed = parse_dpcisr_file(FX / "dpcisr_sample.txt")
    tracer = summarize(parsed)
    tracer["raw"] = parsed
    before = [x["driver"] for x in tracer["dpc"]["top_drivers"]]
    sonar = parse_dumper(DUMP_UNKNOWN.splitlines(), resolve=ModuleMap(MODS).lookup)
    results = [ProbeResult("ETW_TRACER", True, None, 1.0, tracer), ProbeResult("ETW_SONAR", True, None, 1.0, sonar)]
    assert not backfill_driver_names(results)                       # xperf сам всё назвал: не трогаем
    assert [x["driver"] for x in results[0].raw_metrics_json["dpc"]["top_drivers"]] == before


def _timeline(per_cpu_rows):
    return {"dpc": {"timeline": [{"start_ms": i * 1000, "end_ms": (i + 1) * 1000, "per_cpu_us": row}
                                 for i, row in enumerate(per_cpu_rows)]}}


def test_tail_gaps():
    rows = [[100, 50, 0, 7] for _ in range(20)] + [[100, 0, 0, 7] for _ in range(5)] + [[100, 0, 0, 0]] * 1
    # CPU 1 замолчал на 6 последних секунд; CPU 3 — только на последнюю (меньше порога); CPU 2 не работал вовсе
    assert tail_gaps(_timeline(rows)) == {1: 6}
    sparse = [[0, 30, 0, 0] if i % 5 == 0 else [0, 0, 0, 0] for i in range(20)] + [[0, 0, 0, 0]] * 4
    assert tail_gaps(_timeline(sparse)) == {}                       # редкие события — не обрыв буфера
    assert tail_gaps(parse_dpcisr_file(FX / "dpcisr_sample.txt")) == {}


PM_HEADER = ("Application,ProcessID,SwapChainAddress,PresentRuntime,SyncInterval,PresentFlags,PresentMode,"
             "TimeInMs,MsBetweenPresents,MsCPUBusy\n")


def test_foreign_presents_mark_stretched_frames(tmp_path):
    rows, t = [], 1000.0
    for i in range(3000):
        ft = 3.45
        if i in (2500, 2700):
            ft = 6.9 if i == 2500 else 17.1                           # эти кадры растянуты сторонним выводом
        if i == 1200:
            ft = 10.0                                                 # обычный рывок без стороннего вывода
        t += ft
        rows.append(f"game.exe,10,0xBCAF8590,DXGI,0,512,Hardware: Independent Flip,{t:.4f},{ft},{ft - 0.1}\n")
        if i == 2500:
            rows.append(f"game.exe,10,0x0,Other,0,0,Hardware: Independent Flip,{t - 2:.4f},300.0,300.0\n")
        if i == 2700:
            rows.append(f"game.exe,10,0x0,Other,0,0,Hardware: Independent Flip,{t - 5:.4f},600.0,600.0\n")
    p = tmp_path / "pm.csv"
    p.write_text(PM_HEADER + "".join(rows), encoding="utf-8")
    pm = parse_presentmon_csv(p)
    assert pm["captured_frames"] == 3000 and pm["excluded_null_swapchain_frames"] == 2
    assert pm["foreign_presents"] == 4                              # 2 строки + 2 предыдущих вывода по интервалу
    assert pm["foreign_stall_frames"] == 2 and pm["foreign_stall_max_ms"] == 17.1
    assert pm["foreign_stall_series_idx"] == [2500, 2700]           # рывок на 1200 сюда не попал


def test_cli_accepts_old_flags_and_fixed_duration():
    from kernelxray import __main__ as kx
    assert kx.CAPTURE_SECONDS == 30
    # На не-Windows main() выходит с кодом 2 уже после разбора аргументов: старые ключи не ломают запуск
    if sys.platform != "win32":
        assert kx.main(["--arm", "-d", "60", "--delay", "5", "--frames-etl"]) == 2
    assert kx.main(["--list"]) == 0


def test_version_bump():
    assert build_version.bump("2.5.5") == "2.5.6"
    assert build_version.bump("2.5.9") == "2.5.10"
    assert build_version.bump("3") == "3.0.1"


def test_report_prompt_not_tied_to_isatty(monkeypatch):
    # exe, запущенный двойным щелчком с UAC: stdin «не терминал», но окно консоли есть — вопрос показываем
    from kernelxray import __main__ as kx

    class NoTty:
        def isatty(self):
            return False
    monkeypatch.setattr(kx.sys, "stdin", NoTty())
    monkeypatch.setattr(kx, "_console_window", lambda: True)
    assert kx._can_prompt() is True
    monkeypatch.setattr(kx, "_console_window", lambda: False)
    assert kx._can_prompt() is False


def test_final_prompt_does_not_depend_on_isatty(monkeypatch):
    # окно после отчёта должно ждать Enter/Esc при любом способе запуска
    from kernelxray import __main__ as kx
    calls = []

    class NoTty:
        def isatty(self):
            return False
    monkeypatch.setattr(kx.sys, "stdin", NoTty())
    monkeypatch.setattr(kx, "_console_window", lambda: False)
    monkeypatch.setattr(kx, "_ask_open_report", lambda report: calls.append(("ask", report)))
    kx._finish(Path("r.html"), open_now=False, no_prompt=False)
    assert calls == [("ask", Path("r.html"))]
    calls.clear()
    kx._finish(Path("r.html"), open_now=False, no_prompt=True)       # скрипты: без вопроса
    assert calls == []


# --- клавиши в консоли: Enter/Esc, лишние нажатия не закрывают окно -------------------------------------
from kernelxray.core import console as kcon  # noqa: E402


def _rec(vk=0, down=True, event=kcon.KEY_EVENT, ch=0):
    r = kcon.INPUT_RECORD()
    r.EventType = event
    r.Event.KeyEvent.bKeyDown = int(down)
    r.Event.KeyEvent.wVirtualKeyCode = vk
    r.Event.KeyEvent.UnicodeChar = ch
    return r


def test_input_record_layout_matches_windows():
    import ctypes
    assert ctypes.sizeof(kcon.INPUT_RECORD) == 20 and kcon.INPUT_RECORD.Event.offset == 4
    assert ctypes.sizeof(kcon._KeyEvent) == 16


def test_key_of_only_enter_and_esc():
    assert kcon.key_of(_rec(0x78)) is None                     # F9 со старта захвата
    assert kcon.key_of(_rec(0x0D, down=False)) is None         # отпускание Enter
    assert kcon.key_of(_rec(0x0D)) == "enter" and kcon.key_of(_rec(0, ch=0x0D)) == "enter"
    assert kcon.key_of(_rec(0x1B)) == "esc"
    assert kcon.key_of(_rec(0x0D, event=0x0010)) is None       # FOCUS_EVENT, не клавиша


class _FakeK32:
    """Буфер ввода консоли: список событий, как их отдал бы ReadConsoleInputW."""

    def __init__(self, events):
        self.events = list(events)
        self.flushed = 0

    def WaitForSingleObject(self, h, ms):
        return 0 if self.events else 0x102                     # WAIT_TIMEOUT

    def GetNumberOfConsoleInputEvents(self, h, n):
        n._obj.value = len(self.events)
        return 1

    def ReadConsoleInputW(self, h, rec, count, got):
        e = self.events.pop(0)
        ctypes_rec = rec._obj
        ctypes_rec.EventType = e.EventType
        ctypes_rec.Event.KeyEvent.bKeyDown = e.Event.KeyEvent.bKeyDown
        ctypes_rec.Event.KeyEvent.wVirtualKeyCode = e.Event.KeyEvent.wVirtualKeyCode
        ctypes_rec.Event.KeyEvent.UnicodeChar = e.Event.KeyEvent.UnicodeChar
        got._obj.value = 1
        return 1

    def FlushConsoleInputBuffer(self, h):
        self.flushed += 1
        self.events.clear()
        return 1

    def CloseHandle(self, h):
        return 1


def test_console_poll_skips_stray_keys():
    k = _FakeK32([_rec(0x78), _rec(0x78, down=False), _rec(0x0D, down=False), _rec(0x41), _rec(0x1B)])
    con = kcon.ConsoleKeys(k, 1)
    assert con.poll(10) == "esc"                                # F9, отпускание Enter и «A» пропущены
    assert con.poll(10) is None                                 # буфер пуст: ждём дальше, а не «закрыть»


def test_final_prompt_flushes_leftovers_before_waiting(monkeypatch):
    # ровно тот случай из лога: в буфере лежит F9 со старта, окно закрывалось само
    from kernelxray import __main__ as kx
    k = _FakeK32([_rec(0x78), _rec(0x78, down=False)])
    con = kcon.ConsoleKeys(k, 1)
    arrived = [_rec(0x0D)]

    def wait():
        assert k.flushed == 1 and not k.events                  # сначала буфер очищен
        k.events.extend(arrived)                                 # потом пользователь жмёт Enter
        return kcon.ConsoleKeys.wait(con)
    monkeypatch.setattr(con, "wait", wait)
    monkeypatch.setattr(kx.ConsoleKeys, "open", classmethod(lambda cls: con))
    assert kx._wait_enter_or_esc() == ("enter", "консоль")


DUMP_PROCS = """BeginHeader
                    DPC,  TimeStamp, ElapsedTime, CPU,        ServiceAddr,            Image!Function
                P-Start,  TimeStamp,     Process Name ( PID),  ParentPID,  SessionID,  UniqueKey,            UserSid,  Command Line
                  P-End,  TimeStamp,     Process Name ( PID),  ParentPID,  SessionID,  UniqueKey,         ExitStatus
EndHeader
                    DPC, 110000000,         5,   1, 0xfffff80212345678,     amdkmdag.sys!0x1234
                P-Start, 112000000,     PING.EXE ( 5000),       4200,          1, 0xffff8001,  S-1-5-21-1, "ping -n 1 1.1.1.1"
                  P-End, 112040000,     PING.EXE ( 5000),       4200,          1, 0xffff8001,          0
                P-Start, 137300000,     PING.EXE ( 5010),       4200,          1, 0xffff8002,  S-1-5-21-1, "ping -n 1 1.1.1.1"
                P-Start, 138000000,    xperf.exe ( 6000),       4100,          1, 0xffff8003,  S-1-5-21-1, "xperf -stop"
                    DPC, 140000000,         5,   1, 0xfffff80212345678,     amdkmdag.sys!0x1234
"""


def test_dumper_process_starts_in_window():
    d = parse_dumper(DUMP_PROCS.splitlines(), start_us=110_000_000, pid_names={4200: "NetMonitor.exe"})
    p = d["processes"]
    assert [(x["name"], x["at_ms"], x["parent"]) for x in p["started"]] == [
        ("PING.EXE", 2000.0, "NetMonitor.exe"), ("PING.EXE", 27300.0, "NetMonitor.exe")]   # xperf.exe — свой
    assert p["started_by_name"] == {"PING.EXE": 2} and len(p["ended"]) == 1
    assert "ping -n" not in str(p)                                    # командные строки не сохраняются
    assert d["dpc"]["count"] == 2                                     # остальной разбор не сломан
    with open(FX / "dumper_sample.txt") as f:
        assert parse_dumper(f)["processes"] is None


def test_report_marks_process_started_near_stall():
    from kernelxray.report.html_report import _Data, _process_line
    res = sample_results()
    sonar = next(r for r in res if r["probe"] == "ETW_SONAR")["raw_metrics_json"]
    sonar["processes"] = parse_dumper(DUMP_PROCS.splitlines(), start_us=110_000_000,
                                      pid_names={4200: "NetMonitor.exe"})["processes"]
    pm = next(r for r in res if r["probe"] == "PRESENT_MON")["raw_metrics_json"]
    pm["slow_frame_at_s"] = [27.07, 29.65]
    html = _process_line(_Data(res, evaluate(res), {}))
    assert "PING.EXE ×2" in html and "запускает NetMonitor.exe" in html and "рядом с рывками: 1" in html
    pm["slow_frame_at_s"] = [5.0]
    assert "рядом с рывками" not in _process_line(_Data(res, evaluate(res), {}))


def test_slow_frame_times_recorded(tmp_path):
    rows, t = [], 1000.0
    for i in range(400):
        ft = 10.0 if i == 300 else 3.45
        t += ft
        rows.append(f"game.exe,10,0xBCAF8590,DXGI,0,512,Hardware: Independent Flip,{t:.4f},{ft},{ft - 0.1}\n")
    p = tmp_path / "pm.csv"
    p.write_text(PM_HEADER + "".join(rows), encoding="utf-8")
    pm = parse_presentmon_csv(p)
    assert len(pm["slow_frame_at_s"]) == 1 and abs(pm["slow_frame_at_s"][0] - 1.04) < 0.02


def test_diag_window_flag_is_accepted():
    from kernelxray import __main__ as kx
    if sys.platform != "win32":
        assert kx.main(["--diag-window", "60"]) == 2
