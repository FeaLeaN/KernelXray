"""Проверка парсеров на эталонных файлах из старой версии KernelXray.

Запуск: python -m pytest tests  или  python tests/test_parsers.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
FX = ROOT / "tests" / "fixtures"

from kernelxray.parsers import perfmon  # noqa: E402
from kernelxray.parsers.dpcisr import parse_dpcisr_file, summarize  # noqa: E402
from kernelxray.parsers.dumper import parse_dumper  # noqa: E402
from kernelxray.parsers.presentmon import parse_presentmon_csv  # noqa: E402


def test_dpcisr_counts_match_xperf_totals():
    p = parse_dpcisr_file(FX / "dpcisr_sample.txt")
    for key, total in (("dpc", 149537), ("isr", 88364)):
        sec = p[key]
        assert sec["total_count"] == total
        assert sum(m["count"] for m in sec["modules"].values()) == total  # xperf: "EQUAL"
        assert sec["cpu_count"] == 16
        assert len(sec["timeline"]) == 16


def test_dpcisr_summary():
    s = summarize(parse_dpcisr_file(FX / "dpcisr_sample.txt"))
    top = s["dpc"]["top_drivers"][0]
    assert top["driver"] == "Wdf01000.sys" and top["time_us"] == 370429
    assert s["dpc"]["max_latency_bucket_us"] == 128
    assert s["dpc"]["events_over_64us"] == 507
    assert s["isr"]["top_drivers"][0]["driver"] == "dxgkrnl.sys"
    assert max(s["heatmap"], key=lambda c: s["heatmap"][c]["usecs"]) == "1"
    for cell in s["heatmap"].values():                  # время по драйверам сходится с суммой по ядру
        assert sum(cell["driver_us"].values()) == cell["usecs"]
        assert list(cell["driver_us"]) == cell["drivers"]


def test_presentmon_matches_old_version():
    pm = parse_presentmon_csv(FX / "presentmon_sample.csv")
    assert pm["application"] == "r5apex_dx12.exe"
    assert pm["captured_frames"] == 4349
    expected = {  # значения из etw_debug.log старой версии
        "avg_ms_between_presents": 3.45, "p95_ms_between_presents": 3.54, "p99_ms_between_presents": 3.6,
        "avg_ms_until_displayed": 1.0, "p95_ms_until_displayed": 1.19, "p99_ms_until_displayed": 1.28,
        "avg_ms_gpu_busy": 2.06, "p99_ms_gpu_busy": 2.56, "avg_ms_gpu_wait": 1.39,
        "p95_ms_gpu_wait": 1.65, "p99_ms_gpu_wait": 1.73, "avg_ms_cpu_wait": 0.19,
        "p95_ms_cpu_wait": 0.22, "p99_ms_cpu_wait": 0.24,
    }
    for k, v in expected.items():
        assert pm[k] == v, (k, pm[k], v)


def test_perfmon_matches_old_version():
    a = perfmon.aggregate(perfmon.read_csv(FX / "perfmon_sample.csv"))
    assert a["sample_count"] == 5
    assert a["avg"]["interrupts_per_sec"] == 69770.6
    assert a["peak"]["interrupts_per_sec"] == 72534.0
    assert a["avg"]["context_switches_per_sec"] == 133072.2
    assert a["avg"]["cpu_usage_percent"] == 20.8
    assert a["avg"]["available_mbytes"] == 19976.8
    assert a["hottest_core"] == "0,6"


def test_dumper_exact_events():
    with open(FX / "dumper_sample.txt") as f:        # синтетический дамп в формате xperf dumper
        d = parse_dumper(f)
    assert d["dpc"]["max_us"] == 612 and d["dpc"]["over_500us"] == 1
    assert d["longest_events"][0]["module"] == "amdkmdag.sys"
    w = d["worst_cpu_windows_1ms"][0]
    assert (w["cpu"], w["at_ms"], w["top_module"], w["top_event_us"]) == (1, 2500, "amdkmdag.sys", 612)
    # 8 + 15 + [123..780): HDAudBus начался внутри DPC amdkmdag — пересечение считается один раз
    assert w["busy_us"] == 680
    assert d["cswitch"]["count"] == 1667


def test_dumper_windows_count_real_time():
    # ISR внутри DPC на том же ядре не считается дважды, событие на стыке делится между окнами,
    # главный в окне — кто занял больше времени, а не у кого самое длинное событие
    lines = [
        "DPC, 0, 100, 3, 0x0, nvlddmkm.sys!0x1",
        "Interrupt, 30, 20, 3, 0xa0, 0, 1, 0x0, dxgkrnl.sys!0x1",
        "DPC, 200, 60, 3, 0x0, dxgkrnl.sys!0x1",
        "Interrupt, 300, 10, 3, 0xa0, 0, 1, 0x0, dxgkrnl.sys!0x1",
        "DPC, 900, 400, 3, 0x0, nvlddmkm.sys!0x1",
        "Interrupt, 950, 30, 3, 0xa0, 0, 1, 0x0, dxgkrnl.sys!0x1",
    ]
    d = parse_dumper(lines)
    w = {x["at_ms"]: x for x in d["worst_cpu_windows_1ms"]}
    assert w[0]["busy_us"] == 100 + 60 + 10 + 100          # DPC 0..100 с ISR внутри, 200..260, 300..310, 900..1000
    assert w[1]["busy_us"] == 300                            # хвост DPC 1000..1300
    assert all(x["busy_us"] <= 1000 for x in d["worst_cpu_windows_1ms"])
    assert w[0]["top_module"] == "nvlddmkm.sys" and w[0]["top_event_us"] == 400
    assert w[1]["top_event_us"] is None
    sysw = {x["at_ms"]: {m["module"]: m["us"] for m in x["modules"]} for x in d["worst_system_windows_1ms"]}
    assert sysw[0] == {"nvlddmkm.sys": 80 + 100 - 30, "dxgkrnl.sys": 20 + 60 + 10 + 30}


def test_dumper_hard_faults():
    with open(FX / "dumper_hardfault_sample.txt") as f:     # синтетический, колонки берутся из заголовка
        d = parse_dumper(f, exclude_pids={9000, 9100})
    hf = d["hard_faults"]
    assert hf["count"] == 6 and hf["excluded_self"] == 3            # KernelXray, PresentMon, xperf отброшены
    assert hf["pagefile_count"] == 2 and hf["pagefile_io_mb"] == 0.06
    assert hf["top_files"][0]["file"].endswith("pagefile.sys")
    files = [x["file"] for x in hf["top_files"]]
    assert any(f.endswith("data, part 1.pak") for f in files)       # запятая в пути без кавычек
    # Хвостовые колонки новых WPT (Image!Function, N/A) не попадают в имя файла, адрес вместо файла = unknown
    assert any(f.endswith("System32\\audiosrv.dll") for f in files)
    assert any(f.endswith("$UsnJrnl:$J") for f in files)
    assert "unknown" in files and not any("!0x" in f for f in files)
    procs = {x["process"]: x["count"] for x in hf["top_processes"]}
    assert procs["game.exe"] == 3 and procs["svchost.exe"] == 2 and procs["<ядро / прерывание>"] == 1
    assert hf["parse_quality"] == 0.83
    with open(FX / "dumper_sample.txt") as f:                  # трасса без HARD_FAULTS
        assert parse_dumper(f)["hard_faults"] is None




# --- выбор игры без знания её имени ---------------------------------------------------------------
HEADER = "Application,ProcessID,SwapChainAddress,PresentRuntime,SyncInterval,PresentFlags,PresentMode,MsBetweenPresents\n"


def _csv(tmp_path, rows, name="pm.csv", encoding="utf-8", header=HEADER, prefix=""):
    p = tmp_path / name
    p.write_bytes((prefix + header + "".join(rows)).encode(encoding))
    return p


def _rows(app, n, mode="Hardware: Independent Flip", ft=3.0, pid=100):
    return [f"{app},{pid},0x1,DXGI,0,0,{mode},{ft}\n" for _ in range(n)]


def test_presentmon_auto_picks_game_among_noise(tmp_path):
    rows = (_rows("dwm.exe", 5000, "Composed: Flip", 2.7) + _rows("chrome.exe", 900, "Composed: Flip")
            + _rows("Discord.exe", 300, "Composed: Flip") + _rows("SomeNewGame-Win64-Shipping.exe", 800))
    pm = parse_presentmon_csv(_csv(tmp_path, rows))
    assert pm["application"] == "SomeNewGame-Win64-Shipping.exe"
    assert pm["selection"] == "auto" and pm["captured_frames"] == 800


def test_presentmon_target_is_only_a_hint(tmp_path):
    rows = _rows("dwm.exe", 100, "Composed: Flip") + _rows("r5apex_dx12.exe", 500)
    p = _csv(tmp_path, rows)
    assert parse_presentmon_csv(p, "r5apex.exe")["application"] == "r5apex_dx12.exe"      # частичное имя
    assert parse_presentmon_csv(p, "R5APEX_DX12")["application"] == "r5apex_dx12.exe"     # регистр, без .exe
    pm = parse_presentmon_csv(p, "cs2.exe")                                                # чужое имя
    assert pm["application"] == "r5apex_dx12.exe" and "cs2.exe" in pm["note"]


def test_presentmon_game_names_that_look_like_apps(tmp_path):
    rows = _rows("chrome.exe", 900, "Composed: Flip") + _rows("ACOrigins.exe", 400) + _rows("OperationTango.exe", 10)
    assert parse_presentmon_csv(_csv(tmp_path, rows))["application"] == "ACOrigins.exe"


def test_presentmon_desktop_only_explains_why(tmp_path):
    pm = parse_presentmon_csv(_csv(tmp_path, _rows("dwm.exe", 3000, "Composed: Flip")))
    assert pm["captured_frames"] == 0 and "dwm.exe" in pm["note"] and pm["observed_processes"]["dwm.exe"] == 3000


def test_presentmon_empty_and_garbage(tmp_path):
    assert parse_presentmon_csv(_csv(tmp_path, [], header=""))["captured_frames"] == 0
    rows = _rows("game.exe", 50) + ["game.exe,100,0x1,DX"]                     # оборванная последняя строка
    pm = parse_presentmon_csv(_csv(tmp_path, rows, prefix="warning: something\r\n"))
    assert pm["captured_frames"] == 50


def test_presentmon_cyrillic_and_v2_columns(tmp_path):
    header = "Application,ProcessID,SwapChainAddress,PresentRuntime,SyncInterval,PresentFlags,PresentMode,FrameTime,CPUBusy\n"
    rows = [f"Моя Игра.exe,7,0x1,DXGI,0,0,Hardware: Independent Flip,4.0,1.5\n" for _ in range(20)]
    pm = parse_presentmon_csv(_csv(tmp_path, rows, encoding="cp1251", header=header))
    assert pm["application"] == "Моя Игра.exe" and pm["avg_fps"] == 250.0 and pm["avg_ms_cpu_busy"] == 1.5


def test_presentmon_utf16_stdout(tmp_path):
    """Реальный вывод PresentMon 2.6 в перенаправленный stdout: UTF-16LE с BOM."""
    rows = _rows("dwm.exe", 10, "Composed: Flip") + _rows("Моя Игра.exe", 30)
    p = tmp_path / "u16.csv"
    p.write_bytes("\ufeff".encode("utf-16-le") + (HEADER + "".join(rows)).encode("utf-16-le"))
    pm = parse_presentmon_csv(p)
    assert pm["application"] == "Моя Игра.exe" and pm["captured_frames"] == 30
    only_bom = tmp_path / "bom.csv"
    only_bom.write_bytes(b"\xff\xfe")
    assert parse_presentmon_csv(only_bom)["captured_frames"] == 0


def test_presentmon_dwm_always_reported(tmp_path):
    rows = _rows("dwm.exe", 360, "Composed: Flip", 2.78) + _rows("game.exe", 200, ft=5.0)
    pm = parse_presentmon_csv(_csv(tmp_path, rows))
    assert pm["application"] == "game.exe" and pm["captured_frames"] == 200
    assert pm["dwm"]["captured_frames"] == 360 and pm["dwm"]["avg_fps"] == 359.7
    only = parse_presentmon_csv(_csv(tmp_path, _rows("dwm.exe", 100, "Composed: Flip"), name="d.csv"))
    assert only["captured_frames"] == 0 and only["dwm"]["captured_frames"] == 100


if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__, "-q"]))
