"""Сквозной тест без Windows: результаты проб из эталонных файлов + типичные снапшоты -> правила -> kcore -> отчёт."""
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
FX = ROOT / "tests" / "fixtures"

from kernelxray.analysis.kcore import build_kcore, read_kcore, write_kcore  # noqa: E402
from kernelxray.analysis.rules import evaluate  # noqa: E402
from kernelxray.parsers import perfmon  # noqa: E402
from kernelxray.parsers.dpcisr import parse_dpcisr_file, summarize  # noqa: E402
from kernelxray.parsers.dumper import parse_dumper  # noqa: E402
from kernelxray.parsers.presentmon import parse_presentmon_csv  # noqa: E402
from kernelxray.report.html_report import render_report  # noqa: E402


def ok(probe, data, ms=100.0):
    return {"probe": probe, "success": True, "error": None, "duration_ms": ms, "raw_metrics_json": data}


def sample_results() -> list[dict]:
    parsed = parse_dpcisr_file(FX / "dpcisr_sample.txt")
    tracer = summarize(parsed)
    tracer["raw"] = parsed
    with open(FX / "dumper_sample.txt") as f:
        sonar = parse_dumper(f)
    return [
        ok("CPU_TOPOLOGY", {"total_cores": 8, "logical_processors": 16, "has_ecores": False, "architecture": "AMD"}),
        ok("HARDWARE_INFO", {"cpu_name": "AMD Ryzen 7 7800X3D 8-Core Processor", "ram_total_gb": 32.0,
                             "gpus": [{"name": "AMD Radeon RX 7900 XTX"}], "motherboard": "ASUS TUF B650", "os_build": 28000,
                             "os": "Windows 11 Pro Insider Preview (10.0.28000)"}),
        ok("MEMORY_MANAGEMENT", {"total_gb": 31.7, "memory_load_percent": 38}),
        ok("HARDWARE_MISCONFIG", {"ram_speed_mhz": 4800, "ram_kit_speed_from_part": 6000, "xmp_likely_disabled": True,
                                  "single_module": False, "ram_module_count": 2,
                                  "monitors": [{"device": r"\\.\DISPLAY1", "resolution": "2560x1440", "current_hz": 144,
                                                "max_hz_at_resolution": 240}]}),
        ok("BIOS_FIRMWARE", {"forced_hpet_clock": False, "hvci_running": True, "bios_age_days": 200,
                             "bios_vendor": "American Megatrends International, LLC.", "bios_version": "1.91",
                             "bios_date": "2025-03-12"}),
        ok("SYSTEM_CORE", {"wake_jitter_ms": {"avg": 1.05, "p99": 1.4, "max": 2.1}}),
        ok("OS_CONFIG", {"game_mode": "on", "power_plan": {"known_as": "Balanced", "name": "Сбалансированная"},
                         "win32_priority_separation": {"hex": "0x26", "is_default": False}}),
        ok("OS_ENTROPY", {"background_recording": 1}),
        ok("PROCESSES", {"process_count": 230, "background_software": [
            {"title": "HWiNFO", "kind": "sensors", "processes": ["HWiNFO64.EXE"]}]}),
        ok("USB_POWER", {"usb_selective_suspend_ac": "enabled", "pcie_aspm_ac": "off"}),
        ok("INPUT_ELITE", {"pointer_precision": False, "power_managed_input_devices": 0}),
        {"probe": "HARDWARE_INFO_EXTRA", "success": False, "error": "TIMEOUT: Probe exceeded 5.0s threshold",
         "duration_ms": 5000.0, "raw_metrics_json": {}},
        ok("PERFMON_ELITE", perfmon.aggregate(perfmon.read_csv(FX / "perfmon_sample.csv"))),
        ok("PRESENT_MON", parse_presentmon_csv(FX / "presentmon_sample.csv")),
        ok("ETW_TRACER", tracer, 30000.0),
        ok("ETW_SONAR", sonar, 9000.0),
    ]


def test_pipeline(out_dir: Path | None = None):
    results = sample_results()
    a = evaluate(results)
    ids = {f["id"] for f in a["findings"]}
    # в эталонной трассе самый длинный DPC 612 мкс: от 500 мкс это красный, -150
    assert "ETW_DPC_MAX" in ids and next(f for f in a["findings"] if f["id"] == "ETW_DPC_MAX")["severity"] == "critical"
    assert {"HW_XMP", "HW_REFRESH", "OS_BACKGROUND_RECORDING", "PROC_POLLING", "SEC_HVCI"} <= ids
    assert "SEC_HVCI" not in {f["id"] for f in a["findings"] if f.get("fix_id")}   # защиту не «чиним»
    assert 0 <= a["spi_score"] <= 1000
    assert not any(i.startswith("RULE_ERROR") for i in ids), ids

    out_dir = out_dir or Path(tempfile.mkdtemp())
    metrics = {r["probe"]: r["raw_metrics_json"] for r in results if r["success"]}
    write_kcore(out_dir / "xray_profile.kcore", build_kcore(a, metrics))
    k = read_kcore(out_dir / "xray_profile.kcore")
    assert k["spi_score"] == a["spi_score"] and k["target_fixes"] == a["target_fixes"]

    render_report(out_dir / "kernel_xray_report.html", results, a,
                  {"started": "2026-09-20 22:04", "duration_s": 30, "version": "2.0.0", "scan_id": k["scan_id"],
                   "out_dir": r"C:\\Users\\FeaLeaN\\xray_reports\\20260920_220431",
                   "overhead": {"user_ms": 812.5, "kernel_ms": 140.6, "total_duration_ms": 61000}})
    html = (out_dir / "kernel_xray_report.html").read_text(encoding="utf-8")
    assert "amdkmdag.sys" in html and "<script" not in html
    return a, out_dir


if __name__ == "__main__":
    a, d = test_pipeline(Path(sys.argv[1]) if len(sys.argv) > 1 else None)
    print("OK  test_pipeline", a["spi_score"], a["target_fixes"], d)
