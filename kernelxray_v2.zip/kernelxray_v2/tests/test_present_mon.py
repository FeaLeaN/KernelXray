"""Логика пробы PRESENT_MON без Windows: PresentMon, xperf и logman подменены заглушками.

Проверяется: сторож перезапускает мёртвую сессию, переходит в режим ETL, предпроверка включает ETL заранее,
куски CSV склеиваются. Сам сбой ETW так, конечно, не воспроизвести — только реакцию на него.
"""
import logging
import os
import stat
import sys
import threading
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from kernelxray.core.context import SessionContext  # noqa: E402
from kernelxray.core.tools import parse_logman_query  # noqa: E402
from kernelxray.parsers.presentmon import count_frames, parse_presentmon_csv  # noqa: E402
from kernelxray.probes import present_mon as pm  # noqa: E402

HEADER = ("Application,ProcessID,SwapChainAddress,PresentRuntime,SyncInterval,PresentFlags,AllowsTearing,"
          "PresentMode,TimeInMs,MsBetweenPresents,MsBetweenDisplayChange,MsInPresentAPI,MsUntilDisplayed\n")

# Заглушка PresentMon: поведение каждого запуска берётся по очереди из файла сценария.
FAKE = r'''#!/usr/bin/env python3
import sys, time, os
script = os.environ["FAKE_PM_SCRIPT"]
lines = open(script).read().split()
mode, rest = (lines[0], lines[1:]) if lines else ("good", [])
open(script, "w").write(" ".join(rest))
out = sys.stdout.buffer
def w(s): out.write(s.encode("utf-16-le")); out.flush()
out.write(b"\xff\xfe")
if "--etl_file" in sys.argv:
    w(HEADER)
    for i in range(50): w(f"r5apex_dx12.exe,7708,0x1,DXGI,0,512,1,Hardware: Independent Flip,{100+i*3.4},3.4,3.4,0.1,1.0\n")
    sys.exit(0)
timed = int(sys.argv[sys.argv.index("--timed") + 1])
end = time.time() + timed
if mode == "dead":
    while time.time() < end: time.sleep(0.05)
    sys.stderr.write("warning: 469542 ETW events were lost.\n"); sys.exit(0)
w(HEADER)
t = 0.0
while time.time() < end:
    t += 3.4
    w(f"r5apex_dx12.exe,7708,0x1,DXGI,0,512,1,Hardware: Independent Flip,{t},3.4,3.4,0.1,1.0\n")
    time.sleep(0.01)
'''.replace("HEADER", repr(HEADER))


@pytest.fixture
def env(tmp_path, monkeypatch):
    exe = tmp_path / "PresentMon-fake.exe"
    exe.write_text(FAKE)
    exe.chmod(exe.stat().st_mode | stat.S_IEXEC)
    script = tmp_path / "script.txt"
    monkeypatch.setenv("FAKE_PM_SCRIPT", str(script))
    calls = []

    class R:
        def __init__(self, rc=0):
            self.returncode, self.stdout, self.stderr = rc, "", ""

    def fake_run_tool(cmd, timeout, check=True):
        cmd = [str(c) for c in cmd]
        calls.append(cmd)
        if "-start" in cmd:
            Path(cmd[cmd.index("-f") + 1]).write_bytes(b"etl")
        if cmd[:2] == ["logman", "start"]:
            Path(cmd[cmd.index("-o") + 1]).write_bytes(b"etl")
        if "-merge" in cmd:
            Path(cmd[-1]).write_bytes(b"merged")
        return R()

    state = {"xperf": Path("/fake/xperf.exe")}

    class FakeSession:
        def __init__(self, name, log_file, **buffers):
            self.name, self.log_file = name, Path(log_file)
        def start(self):
            calls.append(["StartTrace", self.name]); self.log_file.write_bytes(b"etl")
        def enable(self, guid, level, keywords):
            calls.append(["EnableTraceEx2", guid, level, keywords])
        def disable(self, guid):
            calls.append(["Disable", guid]); return 0
        def capture_state(self, guid, *a):
            calls.append(["CaptureState", guid]); return 0
        def stop(self):
            calls.append(["ControlTrace stop", self.name]); return 0, 0

    monkeypatch.setattr(pm, "FileSession", FakeSession)
    monkeypatch.setattr(pm, "resolve_provider_guid", lambda name: {"microsoft-windows-dxgkrnl": "802ec45a-1e99-4b83-9920-87c98277ba9d"}.get(name.lower(), "00000000-0000-0000-0000-000000000001"))
    monkeypatch.setattr(pm, "run_tool", fake_run_tool)
    monkeypatch.setattr(pm, "stop_etw_session", lambda name: (calls.append(["logman stop", name]), (True, ""))[1])
    monkeypatch.setattr(pm, "stop_own_etw_sessions", lambda exclude=None: [])
    monkeypatch.setattr(pm, "list_etw_sessions", lambda: [])
    monkeypatch.setattr(pm, "find_tool", lambda pats, extra=None: exe if "PresentMon" in pats[0] else state["xperf"])
    monkeypatch.setattr(pm, "FIRST_FRAME_TIMEOUT_S", 1.5)
    monkeypatch.setattr(pm, "STARTUP_CHECK_S", 0.3)
    monkeypatch.setattr(pm, "TIMED_MARGIN_S", 1)
    monkeypatch.setattr(pm, "PREFLIGHT_S", 1)
    ctx = SessionContext(out_dir=tmp_path / "run", duration_s=5, log=logging.getLogger("test"))
    ctx.out_dir.mkdir()
    return {"ctx": ctx, "script": script, "calls": calls, "state": state}


def _run(env, script: str, preflight=False):
    env["script"].write_text(script)
    p, ctx = pm.PresentMonProbe(), env["ctx"]
    if preflight:
        p.preflight(ctx)
    p.prepare(ctx)
    p.start(ctx)
    threading.Event().wait(ctx.duration_s)
    p.stop(ctx)
    return p, p.analyze(ctx)


def test_realtime_ok(env):
    p, out = _run(env, "good")
    assert out["captured_frames"] > 50 and out["presentmon"]["mode"] == "realtime"
    assert [s["outcome"] for s in p.segments] == ["done"]
    assert p.segments[0]["session"].startswith("KernelXray_PM_")


def test_dead_session_switches_to_etl(env):
    p, out = _run(env, "dead")
    assert [s["mode"] for s in p.segments] == ["realtime", "etl"]
    assert p.segments[0]["outcome"] == "no_frames"
    assert out["captured_frames"] == 50 and out["presentmon"]["mode"] == "etl"
    assert "запись в файл включилась" in out["note"]
    assert any(c[0] == "logman stop" and c[1] == p.segments[0]["session"] for c in env["calls"])


def test_dead_session_without_xperf_retries_realtime(env):
    env["state"]["xperf"] = None
    p, out = _run(env, "dead good")
    assert [(s["mode"], s["outcome"]) for s in p.segments] == [("realtime", "no_frames"), ("realtime", "done")]
    assert p.segments[0]["session"] != p.segments[1]["session"]
    assert out["captured_frames"] > 20


def test_preflight_enables_etl(env):
    p, out = _run(env, "dead dead", preflight=True)
    assert env["ctx"].shared["presentmon_mode"] == "etl"
    assert [s["mode"] for s in p.segments] == ["etl"]
    assert out["captured_frames"] == 50 and "note" not in out


def test_armed_creates_empty_session_then_enables_providers(env):
    env["script"].write_text("")
    p, ctx = pm.PresentMonProbe(), env["ctx"]
    ctx.shared["presentmon_mode"] = "etl"
    p.prepare(ctx)
    p.arm(ctx)
    calls = env["calls"]
    assert [c[0] for c in calls if c[0] in ("StartTrace", "EnableTraceEx2")] == ["StartTrace"]   # до игры: пусто
    p.start(ctx)
    enables = [c for c in calls if c[0] == "EnableTraceEx2"]
    assert len(enables) == len(pm.DEFAULT_ETL_PROVIDERS)
    assert enables[0][1:] == ["802ec45a-1e99-4b83-9920-87c98277ba9d", 5, 0x08000841]
    assert not any(c[0] == "logman" for c in calls)          # logman update античит отклоняет
    names = [c[0] for c in calls]
    assert "CaptureState" in names[names.index("EnableTraceEx2"):]     # rundown сразу после включения (GPU-метрики)
    p.stop(ctx)
    names = [c[0] for c in calls]
    assert names.index("Disable") < names.index("ControlTrace stop")   # файл перестаёт расти до попытки стопа
    assert ["ControlTrace stop", p.etl_session] in calls
    out = p.analyze(ctx)
    assert out["captured_frames"] == 50 and out["presentmon"]["segments"][0]["armed"]


def test_runner_arm_flow(tmp_path, monkeypatch):
    from kernelxray.core.runner import Runner
    from kernelxray.core.probe import CaptureProbe
    log = []

    class Armable(CaptureProbe):
        name, armable = "A", True
        def prepare(self, ctx): log.append("A.prepare")
        def arm(self, ctx): log.append("A.arm")
        def start(self, ctx): log.append("A.start")
        def stop(self, ctx): log.append("A.stop")
        def analyze(self, ctx): return {}

    class Plain(Armable):
        name, armable = "B", False
        def prepare(self, ctx): log.append("B.prepare")
        def start(self, ctx): log.append("B.start")
        def stop(self, ctx): log.append("B.stop")

    ctx = SessionContext(out_dir=tmp_path, duration_s=0, arm=True, log=logging.getLogger("test"))
    r = Runner(ctx, [], [Armable(), Plain()])
    monkeypatch.setattr(r, "_wait_trigger", lambda: (log.append("trigger"), True)[1])
    res = r.run()
    assert log == ["A.prepare", "A.arm", "trigger", "A.start", "B.prepare", "B.start", "B.stop", "A.stop"]
    assert all(x.success for x in res)
    log.clear()
    monkeypatch.setattr(r, "_wait_trigger", lambda: False)
    res = r.run()
    assert log == ["A.prepare", "A.arm", "A.stop"] and not any(x.success for x in res)


def test_postprocess_etl_csv_names_and_window(tmp_path):
    csv = tmp_path / "etl.csv"
    rows = [f"<unknown>,11848,0x1,DXGI,0,0,1,Hardware: Independent Flip,{t},3.4,3.4,0.1,1.0"
            for t in (900.0, 1000.0, 1500.0, 31000.0)] + \
           ["<unknown>,1860,0x0,Other,-1,0,0,Hardware: Legacy Flip,1200.0,500,500,0,1.4"]
    csv.write_bytes(b"\xff\xfe" + (HEADER + "\n".join(rows) + "\n").encode("utf-16-le"))
    post = pm.postprocess_etl_csv(csv, {11848: "bf6.exe", 1860: "dwm.exe"}, (1000.0, 31000.0))
    assert post == {"renamed": 4, "trimmed": 1}
    pmr = parse_presentmon_csv(csv)
    assert pmr["application"] == "bf6.exe" and pmr["captured_frames"] == 3
    assert pmr["dwm"]["captured_frames"] == 1


def test_merge_parts_and_logman_parser(tmp_path):
    a, b = tmp_path / "a.csv", tmp_path / "b.csv"
    row = "game.exe,1,0x1,DXGI,0,0,1,Hardware: Independent Flip,1.0,3.4,3.4,0.1,1.0\n"
    a.write_bytes(b"\xff\xfe" + (HEADER + row * 3 + "game.exe,1,0x1,DX").encode("utf-16-le"))   # оборван на kill
    b.write_bytes((HEADER + row * 4).encode("utf-8"))
    out = tmp_path / "out.csv"
    pm.merge_csv_parts([a, b, tmp_path / "missing.csv"], out)
    assert count_frames(out) == 7 and parse_presentmon_csv(out)["captured_frames"] == 7
    text = ("Набор сборщиков данных                Тип                           Состояние\n"
            "-------------------------------------------------------------------------------\n"
            "NT Kernel Logger                      Трассировка                   Выполняется\n"
            "KernelXray_PM_1234_1                  Трассировка                   Выполняется\n\n"
            "Команда выполнена успешно.\n")
    assert parse_logman_query(text) == ["NT Kernel Logger", "KernelXray_PM_1234_1"]



def test_kernel_window_from_trace_end(tmp_path):
    """--arm: окно захвата внутри кольцевой трассы ядра отсчитывается от момента её остановки."""
    from kernelxray.probes.etw_tracer import EtwTracerProbe
    t = EtwTracerProbe()
    t._circular, t._trace_end_mono = True, 131.2
    ctx = SessionContext(out_dir=tmp_path, duration_s=30, arm=True, log=logging.getLogger("test"))
    ctx.shared["window_mono"] = (100.0, 130.0)
    assert t._window_us(ctx, 62.3) == (31100000, 61100000)
    assert t._window_us(ctx, 30.5) == (0, 29300000)       # трасса короче окна: отрезается только остановка
    assert t._window_us(ctx, 1.0) is None                  # окно вне трассы: не режем
    t._circular = False
    assert t._window_us(ctx, 62.3) is None                 # обычный режим: трасса и так совпадает с окном



def test_null_swapchain_frames_excluded(tmp_path):
    """Редкие present без цепочки буферов (0x0), приписанные игре, не должны портить 1% low."""
    good = [f"bf6.exe,10,0x1EC489240,DXGI,0,512,1,Hardware: Independent Flip,{i*3.4},3.4,3.4,0.1,4.1" for i in range(500)]
    ghost = [f"bf6.exe,10,0x0,Other,0,0,0,Hardware: Independent Flip,{i*300.0},280,280,0,4.1" for i in range(5)]
    p = tmp_path / "g.csv"
    p.write_text(HEADER + "\n".join(good + ghost) + "\n", encoding="utf-8")
    r = parse_presentmon_csv(p)
    assert r["captured_frames"] == 500 and r["excluded_null_swapchain_frames"] == 5
    assert r["max_ms_between_presents"] < 4



def test_unknown_pid_without_name_gets_pid_label(tmp_path):
    csv = tmp_path / "u.csv"
    rows = [f"<unknown>,14664,0x1,DXGI,0,512,1,Hardware: Independent Flip,{1000 + i * 3.4},3.4,3.4,0.1,4.1" for i in range(300)]
    csv.write_text(HEADER + "\n".join(rows) + "\n", encoding="utf-8")
    pm.postprocess_etl_csv(csv, {}, None)
    r = parse_presentmon_csv(csv)
    assert r["application"] == "pid 14664" and r["captured_frames"] == 300


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))


def test_postprocess_fixes_reused_pid_name(tmp_path):
    # PID 7144 сначала был у ping.exe, потом его получила игра: PresentMon оставил «PING.EXE»
    csv = tmp_path / "etl.csv"
    rows = [f"PING.EXE,7144,0x1,DXGI,0,0,1,Hardware: Independent Flip,{1000 + i * 3.4},3.4,3.4,0.1,1.0"
            for i in range(50)] + \
           ["Discord.exe,900,0x2,DXGI,0,0,1,Composed: Flip,1100.0,16.6,16.6,0.1,1.0",
            "dwm.exe,1860,0x0,Other,-1,0,0,Composed: Flip,1200.0,16.6,16.6,0,1.4"]
    csv.write_bytes(b"\xff\xfe" + (HEADER + "\n".join(rows) + "\n").encode("utf-16-le"))
    post = pm.postprocess_etl_csv(csv, {7144: "r5apex_dx12.exe", 900: "discord.exe", 1860: "dwm.exe"}, None)
    assert post["name_fixes"] == {"PING.EXE -> r5apex_dx12.exe": 50}      # регистр Discord — не ошибка
    pmr = parse_presentmon_csv(csv)
    assert pmr["application"] == "r5apex_dx12.exe" and "PING.EXE" not in pmr["observed_processes"]
