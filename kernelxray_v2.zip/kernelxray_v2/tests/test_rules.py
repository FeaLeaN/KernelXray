"""Правила и вспомогательная логика, которую нельзя проверить на Windows-данных без Windows."""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from kernelxray.analysis.rules import core_map, dpc_max, evaluate  # noqa: E402
from kernelxray.core.privacy import anonymize_text  # noqa: E402
from kernelxray.probes.devices import is_audio_enhancer  # noqa: E402
from kernelxray.probes.system import detect_anticheats, effective_ram_speed  # noqa: E402
from test_pipeline import ok, sample_results  # noqa: E402


def _replace(results, probe, data):
    return [r for r in results if r["probe"] != probe] + [ok(probe, data)]


def _finding(a, fid):
    return next((f for f in a["findings"] if f["id"] == fid), None)


def test_dpc_max_ignores_kernel_in_rules_and_report():
    sonar = {"dpc": {"max_us": 1500, "modules_by_max": [
        {"module": "ntoskrnl.exe", "max_us": 1500, "count": 5000},
        {"module": "amdkmdag.sys", "max_us": 300, "count": 5000}]},
        "isr": {"max_us": 20, "modules_by_max": [{"module": "dxgkrnl.sys", "max_us": 20}]}}
    assert dpc_max(sonar, None) == (300, "amdkmdag.sys", "точно")
    res = [r for r in sample_results() if r["probe"] != "ETW_SONAR"] + [ok("ETW_SONAR", sonar)]
    f = _finding(evaluate(res), "ETW_DPC_MAX")
    # ntoskrnl (1500 мкс) не делает находку критической: пик — amdkmdag.sys, 300 мкс = жёлтая зона, -60
    assert f["severity"] == "warning" and f["penalty"] == 60 and "300" in f["evidence"]


def test_dpc_max_thresholds():
    def sev(us):
        sonar = {"dpc": {"max_us": us, "modules_by_max": [{"module": "amdkmdag.sys", "max_us": us, "count": 5000}]},
                 "isr": {"max_us": 20, "modules_by_max": [{"module": "dxgkrnl.sys", "max_us": 20}]}}
        res = [r for r in sample_results() if r["probe"] != "ETW_SONAR"] + [ok("ETW_SONAR", sonar)]
        f = _finding(evaluate(res), "ETW_DPC_MAX")
        return f["severity"], f["penalty"]
    assert sev(82) == ("ok", 0) and sev(250) == ("ok", 0)          # до 250 мкс — норма
    assert sev(251) == ("warning", 60) and sev(499) == ("warning", 60)   # 250–500 мкс — жёлтый, -60
    assert sev(500) == ("critical", 150) and sev(1200) == ("critical", 150)  # от 500 мкс — красный, -150


def test_dpc_max_needs_more_than_100_events():
    # единичный длинный DPC (ACPI.sys, 8 событий) не становится пиком; ровно 100 событий — тоже мало
    sonar = {"dpc": {"max_us": 109, "modules_by_max": [
        {"module": "ACPI.sys", "max_us": 109, "count": 8},
        {"module": "foo.sys", "max_us": 95, "count": 100},
        {"module": "tcpip.sys", "max_us": 89, "count": 542},
        {"module": "amdkmdag.sys", "max_us": 79, "count": 52997}]}}
    assert dpc_max(sonar, None) == (89, "tcpip.sys", "точно")
    only_rare = {"dpc": {"max_us": 109, "modules_by_max": [{"module": "ACPI.sys", "max_us": 109, "count": 8}]}}
    assert dpc_max(only_rare, None) == (None, "?", "точно")
    tracer = {"raw": {"dpc": {"modules": {
        "ACPI.sys": {"count": 8, "histogram": [[64, 128, 1]]},
        "amdkmdag.sys": {"count": 53001, "histogram": [[32, 64, 19972]]}}}}}
    assert dpc_max(None, tracer) == (64, "amdkmdag.sys", "верхняя граница")


def test_unchecked_fields_are_reported_not_hidden():
    res = _replace(sample_results(), "USB_POWER", {"usb_selective_suspend_ac": None, "pcie_aspm_ac": None})
    res.append({"probe": "STORAGE_GUIDE", "success": False, "error": "TIMEOUT", "duration_ms": 1, "raw_metrics_json": {}})
    f = _finding(evaluate(res), "CHECK_INCOMPLETE")
    assert f and f["penalty"] == 0
    assert "выборочная приостановка USB" in f["evidence"] and "STORAGE_GUIDE" in f["evidence"]


def test_extra_rules_without_penalty():
    res = _replace(sample_results(), "TIMER_RESOLUTION", {"current_resolution_ms": 0.5, "finest_resolution_ms": 0.5})
    res = _replace(res, "GPU_SCHEDULER", {"mpo_disabled": True})
    res = _replace(res, "CORE_COLLISION", {"devices": [
        {"name": "AMD Radeon RX 7900 XTX", "affinity_policy": "specified", "affinity_mask": "0x14"}]})
    a = evaluate(res)
    assert _finding(a, "TIMER_HIGH_RES")["penalty"] == 0
    assert _finding(a, "GPU_MPO_OFF")["penalty"] == 0
    assert _finding(a, "CORE_AFFINITY_CUSTOM") is None           # ручная привязка — только на карте ядер
    assert _finding(a, "TIMER_HIGH_RES")["title"].endswith("0,5 мс")


def test_hard_faults_with_bad_parse_fall_back_to_counters():
    res = sample_results()
    sonar = next(r for r in res if r["probe"] == "ETW_SONAR")["raw_metrics_json"]
    sonar["hard_faults"] = {"count": 100, "per_sec": 60, "pagefile_per_sec": 55, "pagefile_io_mb": 5,
                            "top_files": [{"file": "unknown", "count": 100}], "parse_quality": 0.1}
    a = evaluate(res)
    assert _finding(a, "PERF_PAGEFILE_READS") is None      # мусорному разбору не верим


def test_anticheat_detection_uses_full_lists():
    found = detect_anticheats({"chrome.exe", "vgtray.exe"}, {"vgk": {"name": "vgk", "state": "running"}})
    assert found and found[0]["title"] == "Riot Vanguard" and found[0]["running"]
    idle = detect_anticheats(set(), {"easyanticheat": {"name": "EasyAntiCheat", "state": "stopped"}})
    assert idle[0]["title"] == "Easy Anti-Cheat" and not idle[0]["running"]
    assert detect_anticheats({"svgconvert.exe"}, {}) == []                # никаких подстрок


def test_ram_speed_reported_in_mhz():
    assert effective_ram_speed(1600, 3200) == (3200, True)
    assert effective_ram_speed(4800, 6000) == (4800, False)                 # это и правда выключенный XMP
    assert effective_ram_speed(6000, 6000) == (6000, False)


def test_audio_enhancers_no_substring_false_positives():
    assert is_audio_enhancer("NahimicService Nahimic service")
    assert is_audio_enhancer("SteelSeriesSonar.exe")
    assert not is_audio_enhancer("sonarr.exe") and not is_audio_enhancer("hdts.exe")
    assert not is_audio_enhancer("RtkAudUService Realtek Audio Universal Service")


def test_anonymize():
    pairs = [(r"C:\Users\FeaLeaN", r"C:\Users\<user>"), ("FeaLeaN", "<user>"), ("DESKTOP-01", "<pc>")]
    t = anonymize_text(r'C:\Users\FeaLeaN\x "C:\\Users\\FeaLeaN\\y" desktop-01', pairs)
    assert "FeaLeaN" not in t and "<pc>" in t and r"C:\\Users\\<user>\\y" in t


def test_runner_reports_own_probe_time(tmp_path):
    import kernelxray.core.runner as rn
    from kernelxray.core.context import SessionContext
    from kernelxray.core.probe import CaptureProbe

    class P(CaptureProbe):
        def __init__(self, name, stop_s, analyze_s):
            self.name, self.stop_s, self.analyze_s = name, stop_s, analyze_s

        def start(self, ctx):
            pass

        def stop(self, ctx):
            time.sleep(self.stop_s)

        def analyze(self, ctx):
            time.sleep(self.analyze_s)
            return {}

    rn.beep = lambda *a, **k: None
    ctx = SessionContext(out_dir=tmp_path, duration_s=1, start_delay_s=0)
    res = {r.probe: r.duration_ms for r in rn.Runner(ctx, [], [P("A", 0.1, 0.4), P("B", 0.6, 0.0)]).run()}
    assert 1400 <= res["A"] <= 1700 and 1500 <= res["B"] <= 1800     # чужая остановка и анализ не входят


# --------------------------------------------------------------------------
# Столкновения на ядре и карта ядер
# --------------------------------------------------------------------------
def _tracer(mods: dict[str, list[int]], dur_s: float = 30.0) -> dict:
    """ETW_TRACER из времён DPC по ядрам (мкс): {драйвер: [cpu0, cpu1, ...]}."""
    ncpu = max(len(v) for v in mods.values())
    heat = {}
    for cpu in range(ncpu):
        us = sum(v[cpu] for v in mods.values() if cpu < len(v))
        if us:
            heat[str(cpu)] = {"usecs": us, "percent": round(us / (dur_s * 1e6) * 100, 3),
                              "drivers": sorted((n for n, v in mods.items() if cpu < len(v) and v[cpu]),
                                                key=lambda n: -mods[n][cpu])}
    return {"raw": {"dpc": {"modules": {n: {"per_cpu_us": v} for n, v in mods.items()}}},
            "heatmap": heat, "trace_duration_s": dur_s}


GPU_ON_0 = {"dxgkrnl.sys": [800_000, 0, 0], "amdkmdag.sys": [510_000, 0, 0]}
USB0 = {"name": "USB 3.20", "class": "usb", "service": "USBXHCI", "affinity_policy": "specified", "affinity_mask": "0x1"}
NIC2 = {"name": "Realtek 2.5GbE", "class": "net", "service": "rt25cx21", "affinity_policy": "specified",
        "affinity_mask": "0x4"}
GPU24 = {"name": "RX 7900 XTX", "class": "display", "service": "amdwddmg", "affinity_policy": "specified",
         "affinity_mask": "0x14"}


def _collision(mods, devices=()):
    res = _replace(sample_results(), "ETW_TRACER", _tracer(mods))
    res = _replace(res, "CORE_COLLISION", {"devices": list(devices)})
    return _finding(evaluate(res), "CORE_COLLISION")


def test_collision_ignores_background_dpcs_on_gpu_core():
    # Реальный случай: на ядре 0 только видеокарта, tcpip.sys и symcryptk.dll — единицы-десятки мкс за захват.
    mods = {**GPU_ON_0, "tcpip.sys": [73, 30, 20], "symcryptk.dll": [105, 90, 80], "ntoskrnl.exe": [16_000, 3000, 3000]}
    assert _collision(mods) is None
    # Фоновый DPC звука тоже не делает столкновения (старый эталон: 98 мкс ShanlingUsbAudio.sys за 15 с)
    assert _collision({**GPU_ON_0, "ShanlingUsbAudio.sys": [98, 0, 0]}) is None


def test_collision_real_usb_on_gpu_core():
    f = _collision({**GPU_ON_0, "Wdf01000.sys": [120_000, 0, 0]}, [USB0, NIC2, GPU24])
    assert f and f["title"] == "На ядре 0 прерывания видеокарты делят ядро с USB"
    assert "Wdf01000.sys (USB)" in f["evidence"] and "dxgkrnl.sys (видеокарта) 800.0 мс" in f["evidence"]
    assert f["fix_id"] == "CORE_AFFINITY"


def test_collision_wdf_resolved_to_network_by_affinity():
    # Сетевая карта на NetAdapterCx закреплена за ядром 2: её прерывания в трассе — Wdf01000.sys на ядре 2
    mods = {"dxgkrnl.sys": [0, 0, 700_000], "Wdf01000.sys": [0, 0, 40_000]}
    f = _collision(mods, [USB0, NIC2])
    assert f and f["title"] == "На ядре 2 прерывания видеокарты делят ядро с сетью"
    # ...а если модуль самой карты уже виден на этом ядре, Wdf01000.sys на нём — не она
    rows = core_map(_tracer({**mods, "rt25cx21x64.sys": [0, 0, 9000]}), [USB0, NIC2])[2]
    wdf = next(r for r in rows if r["driver"] == "Wdf01000.sys")
    nic = next(r for r in rows if r["driver"] == "rt25cx21x64.sys")
    assert wdf["kinds"] == ["kmdf"] and nic["kinds"] == ["net"]


def test_collision_unknown_kmdf_is_named_honestly():
    f = _collision({**GPU_ON_0, "Wdf01000.sys": [120_000, 0, 0]})
    assert f and "устройствами на KMDF" in f["title"]
    assert "KMDF, устройство не определено" in f["evidence"]


def test_collision_several_cores_one_finding():
    mods = {"dxgkrnl.sys": [700_000, 0, 700_000], "Wdf01000.sys": [100_000, 0, 0], "ShanlingUsbAudio.sys": [0, 0, 60_000]}
    a = evaluate(_replace(_replace(sample_results(), "ETW_TRACER", _tracer(mods)), "CORE_COLLISION", {"devices": [USB0]}))
    found = [f for f in a["findings"] if f["id"] == "CORE_COLLISION"]
    assert len(found) == 1 and found[0]["penalty"] == 15
    assert found[0]["title"] == "На ядрах 0 и 2 прерывания видеокарты делят ядро с USB и звуком"


def test_core_map_lists_every_driver_with_time(tmp_path):
    from kernelxray.report.html_report import _Data, _warzone
    mods = {**GPU_ON_0, "Wdf01000.sys": [120_000, 0, 0], "ntoskrnl.exe": [16_000, 0, 0], "storport.sys": [55, 0, 0],
            "symcryptk.dll": [105, 0, 0], "tcpip.sys": [73, 0, 0], "pdc.sys": [1, 0, 0]}
    res = _replace(_replace(sample_results(), "ETW_TRACER", _tracer(mods)), "CORE_COLLISION", {"devices": [USB0]})
    html = _warzone(_Data(res, evaluate(res), {}))
    for name in mods:                                    # все, а не первые пять
        assert name in html, name
    assert 'class="drv minor"' in html and "столкновение: видеокарта + USB" in html
    assert '<span class="tag">USB</span>' in html and "800" in html


def test_game_mode_on_is_warning_minus_30():
    base = next(r for r in sample_results() if r["probe"] == "OS_CONFIG")["raw_metrics_json"]
    on = evaluate(_replace(sample_results(), "OS_CONFIG", {**base, "game_mode": "on", "auto_game_mode_enabled": None}))
    off = evaluate(_replace(sample_results(), "OS_CONFIG", {**base, "game_mode": "off", "auto_game_mode_enabled": 0}))
    f = _finding(on, "OS_GAME_MODE")
    assert f["severity"] == "warning" and f["penalty"] == 30 and f["title"] == "Игровой режим Windows включён"
    assert "по умолчанию включён" in f["evidence"]
    assert _finding(off, "OS_GAME_MODE") is None                    # выключенный — без находки и штрафа
    assert off["spi_score"] - on["spi_score"] == 30
    assert "OS_CONFIG_GAME_MODE" in on["target_fixes"] and "OS_CONFIG_GAME_MODE" not in off["target_fixes"]


def test_delayed_ack_is_not_reported():
    # даже со старыми данными пробы NETWORK_CONFIG (telemetry прошлых версий) находки больше нет
    res = sample_results() + [ok("NETWORK_CONFIG", {"interfaces": [{"ip": "192.168.1.5", "tcp_ack_frequency": None}],
                                                    "delayed_ack_disabled_on_all": False})]
    a = evaluate(res)
    assert _finding(a, "NET_NAGLE") is None and "NETWORK_NAGLE_DELAY" not in a["target_fixes"]
