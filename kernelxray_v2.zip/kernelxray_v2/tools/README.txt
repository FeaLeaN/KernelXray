Сюда кладутся внешние утилиты (эта папка tools должна лежать рядом с exe KernelXray):

  PresentMon-2.x-x64.exe   https://github.com/GameTechDev/PresentMon/releases
  xperf.exe                необязательно, если установлен Windows Performance Toolkit (Windows ADK)

  presentmon_etl_providers.txt   необязательно. Список ETW-провайдеров для режима ETL кадров
                                 (кадры всегда пишутся в .etl).
                                 Одна строка = Провайдер:Keywords:Level, # = комментарий.
                                 Эталон: Tools\start_etl_collection.cmd в репозитории PresentMon.
